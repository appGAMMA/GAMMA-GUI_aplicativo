% Armazena e imprimi o novo v�rtice
function [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,x,f,rede)

n = size(M,1);
% Armazenamento
vert = vert + 1;
M(:,end) = x;
rv(end) = f;
ma(vert,1:n) = x';
ma(vert,n+1) = sinal*f;

saida = ma(vert,:);
save simplex.txt saida -append -ascii
y_d = rede.y';
save respostas.txt y_d -append -ascii  

%Sa�da com as coordenadas e resposta do novo v�rtice
disp(['V�rtice ' int2str(vert)])
for j = 1:n
    disp(['X' int2str(j) ' = ' num2str(x(j))])
end
    disp(['Resposta = ' num2str(sinal*f)])
end