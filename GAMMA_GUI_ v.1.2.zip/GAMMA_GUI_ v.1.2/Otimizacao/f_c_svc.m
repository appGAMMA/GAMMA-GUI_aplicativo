function saida = f_c_svc(x,samples,opt,param,kfold)
%% M�quina de vetor suporte para classifica��o - Simplex
%% Vers�o: 26/05/2017
% Rotinas do pacote libsvm 3.2
% Multiclasses: one-against-all
% Fun��o para otimiza��o simplex
% Valida��o cruzada no conjunto de treinamento
% Sa�da: AUC (m�dia geom�trica) das amostras de valida��o cruzada
% Pesos por classe: Luts et al. (2010)
% Valida��o cruzada: leve-one-out ou kfold
%% Op��es
C = 10^param(1);
gamma = 10^param(2);
opt1 = [opt ' -g ' num2str(gamma) ' -c ' num2str(C)];
%% Prepara��o dos dados
% X
x = sparse(x);
ntreina = size(x,1); % quantidade de amostras de calibra��o
% Y
[G,GN] = grp2idx(samples);
classes = size(GN,1);
y = G;
%% Loop para a constru��o de k-SVC
rede.acc_vc = zeros(classes,1);
for ii = 1:classes
    % Classe ii = +1 e as outras = -1
    idx = y == ii;
    yb = -1*ones(size(y));
    yb(idx) = 1;
    % Pesos para as classes desbalanceadas
    % amostras 1
    cont = sum(yb == 1);
    wp = ntreina/(2*cont);
    % amostras -1
    cont = sum(yb == -1);
    wn = ntreina/(2*cont);
    opt2 = [opt1 ' -w1 ' num2str(wp) ' -w-1 ' num2str(wn)];
    % Valida��o cruzada da SVM ii
    rede.acc_vc(ii) = do_binary_cross_validation(yb,x,opt2,kfold);
end
%% Sa�da para o simplex
%saida.DS = geomean(rede.acc_vc);
% Penaliza��o para modelos complexos
saida.DS = geomean(rede.acc_vc)-1e-7*C;
saida.y = rede.acc_vc;
saida.C = C;
saida.gamma = gamma;
clc % Limpeza das sa�das do LIBSVM
