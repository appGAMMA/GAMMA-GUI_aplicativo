function saida = pswarm_gamma(fun,sinal,lb,ub,opt,x,y,opt_svm,kfold)
%% Particle Swarm - Para otimizar SVM
% Vers�o: 26/05/2017 - Desenvolvido por Evandro Bona
% Entradas
%         fun: fun��o a ser otimizada (colocar @ antes do nome da fun��o)
%         sinal: 1 para minimizar e -1 para maximizar
%         lb: vetor com o limite inferior de x (opcional - vetor vazio)
%         ub: vetor com o limite superior de x (opcional - vetor vazio)
%         opt: estrutura contendo as op��es (opcional - n�o usar)
%
% Para testar a rotina use @fexemplo como fun para otimizar a fun��o
% interna peaks do Matlab. Digite peaks(50) para ver o gr�fico da fun��o.
clc
%% Par�metros
ni = length(lb);
if isempty(opt) % Op��es default do PS
    opt = optimoptions('particleswarm','SwarmSize',20,'TolFun',1e-3,'Display','iter');
    %'PlotFcns',{@saplotbestf,@saplotbestx}
    %'PlotFcns',@saplotbestf, 
end
%% Otimiza��o
[param,fval,~,output] = particleswarm(@fps,ni,lb,ub,opt);
%% Sa�da dos resultados
saida.lb = lb;
saida.ub = ub;
saida.potm = param;
saida.fval = sinal*fval;
saida.output = output;
saida.options = opt;
%% Nested function
function z = fps(param)
    z = sinal*feval(fun,x,y,opt_svm,param,kfold);
end
end