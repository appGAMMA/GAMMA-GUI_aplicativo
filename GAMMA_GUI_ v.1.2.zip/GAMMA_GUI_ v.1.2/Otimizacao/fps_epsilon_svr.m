function z = fps_epsilon_svr(x,y,opt,param,kfold)
%% Fun��o para otimiza��o no simplex
% Valida��o cruzada no conjunto de treinamento
%% Vers�o: 13/08/2016

yo = y;
ymin = min(yo);
ymax = max(yo);
delta = ymax - ymin;
y = 2*(y - ymin)/delta - 1;

% ym = mean(y);
% yo = y;
% y = y - ym;

acal = size(x,1);
C = 10^param(1);
gamma = 10^param(2);
epsilon = 10^param(3);
opt = [opt ' -g ' num2str(gamma) ' -c ' num2str(C) ' -p ' num2str(epsilon)];
%% Leitura dos dados
x = sparse(x);
%% Treinamento da SVM
ypcv = zeros(acal,1);
% Valida��o cruzada
if kfold < acal
    % K-fold
    cvidx = crossvalind('Kfold',acal,kfold);
else
    % Leave-one-out
    cvidx = 1:acal;
end
for kk = 1:kfold  % Loop da valida��o cruzada
    % Separa��o das amostras
    idx = cvidx ~= kk;
    xcv_treina = x(idx,:);
    ycv_treina = y(idx);
    idx = cvidx == kk;
    xcv_teste = x(idx,:);
    ycv_teste = y(idx);
    svr = svmtrain(ycv_treina,xcv_treina,opt);
    ypcv(idx,:) = svmpredict(ycv_teste,xcv_teste,svr);
    %clc
end
%fom_cv = fom(y,ypcv);

ypcv = ((ypcv + 1)/2)*delta + ymin;
fom_cv = fom(yo,ypcv);

%% Sa�da para o simplex
rede.DS = fom_cv.RMSE;
rede.y = fom_cv.RMSE;
rede.C = C;
rede.gamma = gamma;
rede.epsilon = epsilon;
z = rede.DS;
