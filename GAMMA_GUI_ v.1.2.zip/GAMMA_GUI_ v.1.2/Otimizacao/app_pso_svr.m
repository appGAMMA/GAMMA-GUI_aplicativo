%% Otimização PSO para SVR - versão app
% Versão: 29/04/2023
function saida = app_pso_svr(p,x,y,kfold,tipo,kernel,otm,v)
%% Definição das opções da SVR
% Tipo de SVR
cont = 1;
switch tipo
    case 'epsilon-SVR'
        opt = '-s 3';
        if otm(1) == 1
            opt = [opt ' -c ' num2str(p(cont))];
            cont = cont + 1;
        else
            opt = [opt ' -c ' num2str(v(1))];
        end
        if otm(2) == 1
            opt = [opt ' -p ' num2str(p(cont))];
            cont = cont + 1;
        else
            opt = [opt ' -p ' num2str(v(2))];
        end
    case 'nu-SVR'
        opt = '-s 4';
        if otm(1) == 1
            opt = [opt ' -c ' num2str(p(cont))];
            cont = cont + 1;
        else
            opt = [opt ' -c ' num2str(v(1))];
        end
        if otm(2) == 1
            opt = [opt ' -n ' num2str(p(cont))];
            cont = cont + 1;
        else
            opt = [opt ' -n ' num2str(v(2))];
        end
end
% Tipo de kernel
switch kernel
    case 'linear'
        opt = [opt ' -t 0 -q'];
    case 'polinomial'
        opt = [opt ' -t 1'];
        if otm(3) == 1
            opt = [opt ' -g ' num2str(p(cont))];
            cont = cont + 1;
        else
            opt = [opt ' -g ' num2str(v(3))];
        end
        if otm(4) == 1
            opt = [opt ' -r ' num2str(p(cont))];
            cont = cont + 1;
        else
            opt = [opt ' -r ' num2str(v(4))];
        end
        if otm(5) == 1
            opt = [opt ' -d ' num2str(round(p(cont)))];
        else
            opt = [opt ' -d ' num2str(v(5))];
        end
        opt = [opt ' -q'];
    case 'base radial'
        opt = [opt ' -t 2'];
        if otm(3) == 1
            opt = [opt ' -g ' num2str(p(cont))];
        else
            opt = [opt ' -g ' num2str(v(3))];
        end
        opt = [opt ' -q'];
    case 'sigmoide'
        opt = [opt ' -t 3'];
        if otm(3) == 1
            opt = [opt ' -g ' num2str(p(cont))];
            cont = cont + 1;
        else
            opt = [opt ' -g ' num2str(v(3))];
        end
        if otm(4) == 1
            opt = [opt ' -r ' num2str(p(cont))];
        else
            opt = [opt ' -r ' num2str(v(4))];
        end
        opt = [opt ' -q'];
end
%% Validação cruzada
ntreina = length(y);
ypcv = zeros(ntreina,1);
if kfold < ntreina
    % K-fold
    cvidx = crossvalind('Kfold',ntreina,kfold);
else
    % Leave-one-out
    cvidx = 1:ntreina;
end
for kk = 1:kfold  % Loop da validação cruzada
    % Separação das amostras
    idx = cvidx ~= kk;
    xcv_treina = x(idx,:);
    ycv_treina = y(idx,:);
    idx = cvidx == kk;
    xcv_teste = x(idx,:);
    ycv_teste = y(idx);
    svm = svmtrain(ycv_treina,xcv_treina,opt);
    ypcv(idx) = svmpredict(ycv_teste,xcv_teste,svm);
end
clc
% FOM
FOM = fom(y,ypcv);
saida = FOM.RMSE;