function otm_simplex = simplex_gamma(sinal,mix_var,f_otm,L,U,opt_simplex,x,y,opt_svm,tipo,kfold)
%% Simplex Sequencial para otimizar SVM
%% Vers�o: 08/08/2017
% sinal: -1 maximiza��o e +1 para minimiza��o
% mix_var: quantidade de vari�veis de mistura (0 para ignorar)
% f_otm: fun��o otimizada
% L: vetor com o limite inferior de cada vari�vel
% U: vetor com o limite superior de cada vari�vel
% Inicializa��o por grid search - central composto rotacional
%% Checa op��es
if isempty(opt_simplex)   % Default
    opt.itr = 200;
    opt.eta = 0.001;
    opt.tol = 0.001;
end
% Salva na sa�da as op��es da entrada
otm_simplex.opt = opt;
%% Par�metros do algoritmo
max_itr = opt.itr;  % Quantidade m�xima de itera��es
eta = opt.eta;      % Toler�ncia para os limites superiores e inferiores
tol = opt.tol;      % Crit�rio de parada
% Determina��o do n�mero de vari�veis
n = length(L); 
% Par�metros adaptativos do algoritmo
alfa = 1;
beta = 1 + 2/n;
gama = 0.75 - 1/(2*n);
delta = 1 - 1/n;
%% Inicializa��o - Grid search
% switch tipo
%     case 'SVR'
%         res = ini_grid_svr(f_otm,L,U,x,y,opt_svm,kfold);
%         [~,idx] = sort(res.perf);
%         rede.epsilon = 10^res.dcc(idx(1),3);
%     case 'SVC'
%         res = ini_grid_svc(f_otm,L,U,x,y,opt_svm,kfold);
%         [~,idx] = sort(res.perf,'descend');
% end
% M = res.dcc(idx(1:n+1),:)'; % Simplex inicial
% rv = sinal*res.perf(idx(1:n+1));
% saida = res.perf(idx(1:n+1)); % Rever para respostas combinadas
% D_perf = sinal*res.perf(idx(1)); % Melhor modelo
% rede.DS = res.perf(idx(1));
% rede.y = res.perf(idx(1));
% rede.C = 10^res.dcc(idx(1),1);
% rede.gamma = 10^res.dcc(idx(1),2);
% b_net = rede;
% for ii = 1:n+1
%     sim_reg{ii,1} = 'Simplex Inicial';
% end
%% Inicializa��o autom�tica tradicional
p = (sqrt(n+1)+n-1)/(n*sqrt(2));
q = (sqrt(n+1)-1)/(n*sqrt(2));
% Constru��o da matriz M - Simplex inicial
disp('Montando o simplex inicial...')
M = zeros(n,n+1);
% Estabelece o primeiro ponto no m�nimo
M(:,1) = L;
for j = 2:n+1
    for i = 1:n
        if (j - 1) == i
            M(i,j) = L(i) + p*(U(i) - L(i));
        else
            M(i,j) = L(i) + q*(U(i) - L(i));
        end
    end
end
% C�lculo dos valores de f para o simplex inicial
% As repostas ser�o armazenadas no vetor rv
D_perf = inf;
rv = zeros(n+1,1);
for i = 1:n+1
    % Estabelece a restri��o para as vari�veis de mistura
    if mix_var > 0
        M(:,i) = mix_res(M(:,i),mix_var,L,U,eta);
    end
    rede = feval(f_otm,x,y,opt_svm,M(:,i),kfold);
    rv(i) = sinal*rede.DS;
    saida(i,:) = rede.y;
    if sinal*rede.DS < D_perf
        D_perf = sinal*rede.DS;
        b_net = rede;
    end
    sim_reg{i} = 'Simplex Inicial';
end
%% Armazenamento do simplex inicial
ma = M';
ma(:,n+1) = sinal*rv;
vert = n+1;
fid1 = fopen('simplex.txt','w+');
fid2 = fopen('respostas.txt','w+');
fclose('all');
save simplex.txt ma -append -ascii
save respostas.txt saida -append -ascii
% Sa�da com os v�rtices e respectivas respostas
disp('Simplex Inicial')
for i = 1:n+1
    disp(['V�rtice ' int2str(i)])
    for j = 1:n
        disp(['X' int2str(j) ' = ' num2str(M(j,i))])
    end
    disp(['Resposta = ' num2str(sinal*rv(i))])
end
%% Algoritmo simplex
pare = 0; % Crit�rio de parada
while pare == 0
    disp('Calculando o novo v�rtice - Reflex�o ...')
    % Localizando o v�rtice de pior resposta
    [rv,j] = sort(rv); % Ordem crescente - minimiza��o
    M = M(:,j); % Ordena��o dos v�rtices
    % C�lculo das coordenadas do centr�ide
    cent = mean(M(:,1:n),2);
    %C�lculo das coordenadas de reflex�o
    R = cent + alfa*(cent - M(:,n+1));
    % Checagem da regi�o experimental
    R = boundcheck(R,L,U,eta);
    % Estabelece a restri��o para as vari�veis de mistura
    if mix_var > 0
        R = mix_res(R,mix_var,L,U,eta);
    end
    % C�lculo da resposta do centr�ide e da reflex�o
    rede = feval(f_otm,x,y,opt_svm,R,kfold);
    rede_R = rede;
    RR = sinal*rede.DS;
    if sinal*rede.DS < D_perf
        D_perf = sinal*rede.DS;
        b_net = rede;
    end
    if RR < rv(1)
    % Expans�o
        disp('Calculando o novo v�rtice - Expans�o ...')
        E = cent + beta*(R - M(:,n+1));
        E = boundcheck(E,L,U,eta);
        % Estabelece a restri��o para as vari�veis de mistura
        if mix_var > 0
            E = mix_res(E,mix_var,L,U,eta);
        end
        rede = feval(f_otm,x,y,opt_svm,E,kfold);
        rede_E = rede;
        RE = sinal*rede.DS;
        if sinal*rede.DS < D_perf
            D_perf = sinal*rede.DS;
            b_net = rede;
        end
        if RE < RR
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,E,RE,rede_E); % Armazenamento e sa�da
            sim_reg{vert} = 'Expans�o';
        else
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,R,RR,rede_R); % Armazenamento e sa�da
            sim_reg{vert} = 'Reflex�o';
        end
    % Armazenamento da reflex�o
    elseif RR < rv(n)
        [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,R,RR,rede_R); % Armazenamento e sa�da
        sim_reg{vert} = 'Reflex�o';
    % Contra��o externa
    elseif RR < rv(n+1)
        disp('Calculando o novo v�rtice - Contra��o externa ...')
        CE = cent + gama*(R - cent);
        CE = boundcheck(CE,L,U,eta);
        % Estabelece a restri��o para as vari�veis de mistura
        if mix_var > 0
            CE = mix_res(CE,mix_var,L,U,eta);
        end
        rede = feval(f_otm,x,y,opt_svm,CE,kfold);
        rede_CE = rede;
        RCE = sinal*rede.DS;
        if sinal*rede.DS < D_perf
            D_perf = sinal*rede.DS;
            b_net = rede;
        end
        if RCE <= RR
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,CE,RCE,rede_CE); % Armazenamento e sa�da
            sim_reg{vert} = 'Contra��o externa';
        else
            M = shrink(M,delta); % Encolhimento
            % C�lculo das respostas dos novos v�rtices
            for i = 2:n+1
                if mix_var > 0
                    M(:,i) = mix_res(M(:,i),mix_var,L,U,eta);
                end
                rede = feval(f_otm,x,y,opt_svm,M(:,i),kfold);
                rv(i)= sinal*rede.DS;
                y_d(i,:) = rede.y;
                if sinal*rede.DS < D_perf
                    D_perf = sinal*rede.DS;
                    b_net = rede;
                end
            end
            % Sa�da com os v�rtices e respectivas respostas
            disp('Novos V�rtices')
            for i = 2:n+1
                vert = vert + 1;
                disp(['V�rtice ' int2str(vert)])
                for j = 1:n
                    disp(['X' int2str(j) ' = ' num2str(M(j,i))])
                end
                disp(['Resposta = ' num2str(sinal*rv(i))])
                % Armazenamento do novo v�rtice
                ma(vert,1:n) = M(:,i)';
                ma(vert,n+1) = sinal*rv(i);
                sim_reg{vert} = 'Encolhimento';
                saida = ma(vert,:);
                save simplex.txt saida -append -ascii
                saida = y_d(i,:);
                save respostas.txt saida -append -ascii
            end
        end
    % Contra��o interna
    else 
        disp('Calculando o novo v�rtice - Contra��o interna ...')
        CI = cent - gama*(R - cent); %C�lculo das coordenadas de contra��o interna
        CI = boundcheck(CI,L,U,eta); % Checagem da regi�o experimental
        % Estabelece a restri��o para as vari�veis de mistura
        if mix_var > 0
            CI = mix_res(CI,mix_var,L,U,eta);
        end
        rede = feval(f_otm,x,y,opt_svm,CI,kfold);
        rede_CI = rede;
        RCI = sinal*rede.DS;
        if sinal*rede.DS < D_perf
            D_perf = sinal*rede.DS;
            b_net = rede;
        end
        if RCI < rv(n+1)
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,CI,RCI,rede_CI); % Armazenamento e sa�da
            sim_reg{vert} = 'Contra��o interna';
        else
            M = shrink(M,delta); % Encolhimento
            % C�lculo das respostas dos novos v�rtices
            for i = 2:n+1
                if mix_var > 0
                    M(:,i) = mix_res(M(:,i),mix_var,L,U,eta);
                end
                rede = feval(f_otm,x,y,opt_svm,M(:,i),kfold);
                rv(i)= sinal*rede.DS;
                y_d(i,:) = rede.y;
                if sinal*rede.DS < D_perf
                    D_perf = sinal*rede.DS;
                    b_net = rede;
                end
            end
            % Sa�da com os v�rtices e respectivas respostas
            disp('Novos V�rtices')
            for i = 2:n+1
                vert = vert + 1;
                disp(['V�rtice ' int2str(vert)])
                for j = 1:n
                    disp(['X' int2str(j) ' = ' num2str(M(j,i))])
                end
                disp(['Resposta = ' num2str(sinal*rv(i))])
                % Armazenamento do novo v�rtice
                ma(vert,1:n) = M(:,i)';
                ma(vert,n+1) = sinal*rv(i);
                sim_reg{vert} = 'Encolhimento';
                saida = ma(vert,:);
                save simplex.txt saida -append -ascii
                saida = y_d(i,:);
                save respostas.txt saida -append -ascii
            end
        end
    end
    % Crit�rio de parada
    % Converg�ncia nas vari�veis
    cont = 0;
    for i = 1:n
        if max(abs(ma(end-n-1:end,i) - ma(end,i))) < tol
            cont = cont + 1;
        end
    end
    if cont == n
        pare = 1;
    end
    % Quantidade m�xima de itera��es
    if vert >= max_itr
        pare = 1;
    end
    close all
    % Gr�fico para cada vari�vel e resposta
    for i = 1:n+1
        figure
        plot(ma(:,i))
        xlabel('V�rtice')
        switch i
            case 1
                ylabel('log C')
            case 2
                str = sprintf('log \x03B3');
                ylabel(str)
            case 3
                switch tipo
                    case 'SVR'
                        str = sprintf('log \x03B5');
                        ylabel(str)
                    case 'SVC'
                        ylabel('AUC m�dio')
                end
            case 4
                ylabel('RMSECV')
        end
    end
end
% Sa�da das vari�veis importantes
otm_simplex.vsimplex = M;
otm_simplex.registro = sim_reg;
otm_simplex.vertices = ma;
otm_simplex.potm = b_net;
