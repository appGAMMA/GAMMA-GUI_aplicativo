function res = ini_grid_svr(f_otm,L,U,x,y,opt,kfold)
%% Inicializa��o do simplex por grid search
% Planejamento central composto rotacional
%% Vers�o: 08/08/2017
% Planejamento central composto rotacional
nv = zeros(3,5);    % Tabela de n�veis
for ii = 1:3
    nv(ii,1) = L(ii);
    nv(ii,5) = U(ii);
    nv(ii,3) = (U(ii) + L(ii))/2;
    passo = (nv(ii,3) - nv(ii,1))/1.6818;
    nv(ii,2) = nv(ii,3) - passo;
    nv(ii,4) = nv(ii,3) + passo;
end
% Matriz do planejamento
dcc = ccdesign(3);
dcc(16:end,:) = [];
for ii = 1:3
    idx = dcc(:,ii) == 0;
    dcc(idx,ii) = nv(ii,3);
    idx = dcc(:,ii) == -1;
    dcc(idx,ii) = nv(ii,2);
    idx = dcc(:,ii) == 1;
    dcc(idx,ii) = nv(ii,4);
    idx = dcc(:,ii) == -8^(1/4);
    dcc(idx,ii) = nv(ii,1);
    idx = dcc(:,ii) == 8^(1/4);
    dcc(idx,ii) = nv(ii,5);
end
perf = zeros(size(dcc,1),1);
for ii = 1:size(dcc,1)
    param = zeros(3,1);
    for jj = 1:3
        param(jj) = dcc(ii,jj);
    end
    svr = feval(f_otm,x,y,opt,param,kfold);
    perf(ii) = svr.DS;
end
res.perf = perf;
res.dcc = dcc;
