function res = ini_grid_svc(f_otm,L,U,x,y,opt,kfold)
%% Inicializa��o do simplex por grid search
%% Vers�o: 26/05/2017
% Planejamento central composto rotacional
nv = zeros(2,5);    % Tabela de n�veis
for ii = 1:2
    nv(ii,1) = L(ii);
    nv(ii,5) = U(ii);
    nv(ii,3) = (U(ii) + L(ii))/2;
    passo = (nv(ii,3) - nv(ii,1))/1.4142;
    nv(ii,2) = nv(ii,3) - passo;
    nv(ii,4) = nv(ii,3) + passo;
end
% Matriz do planejamento
dcc = ccdesign(2);
dcc(10:end,:) = [];
for ii = 1:2
    idx = dcc(:,ii) == 0;
    dcc(idx,ii) = nv(ii,3);
    idx = dcc(:,ii) == -1;
    dcc(idx,ii) = nv(ii,2);
    idx = dcc(:,ii) == 1;
    dcc(idx,ii) = nv(ii,4);
    idx = dcc(:,ii) == -4^(1/4);
    dcc(idx,ii) = nv(ii,1);
    idx = dcc(:,ii) == 4^(1/4);
    dcc(idx,ii) = nv(ii,5);
end
perf = zeros(size(dcc,1),1);
for ii = 1:size(dcc,1)
    param = zeros(2,1);
    for jj = 1:2
        param(jj) = dcc(ii,jj);
    end
    svc = feval(f_otm,x,y,opt,param,kfold);
    perf(ii) = svc.DS;
end
res.perf = perf;
res.dcc = dcc;
clc % Apagar as sa�das intermedi�rias do LIBSVM
