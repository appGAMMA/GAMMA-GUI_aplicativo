% Checa os limites das vari�veis
function x = boundcheck(x,L,U,eta)

for i = 1:length(L)
    if x(i) > U(i)
        x(i) = U(i) - eta;
    elseif x(i) < L(i)
        x(i) = L(i) + eta;
    end
end
end