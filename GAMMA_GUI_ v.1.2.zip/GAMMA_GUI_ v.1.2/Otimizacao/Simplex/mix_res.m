%% Restri��o de mistura
% Vers�o: 28/06/2023
function x = mix_res(x,nmix,L,U,eta)
parada = 0;
while parada == 0
    x_mix = x(1:nmix);
    x(1:nmix) = x_mix/sum(x_mix);
    x_new = boundcheck(x,L,U,eta);
    if abs(sum(x - x_new)) < 0.0001
        parada = 1;
    end
    x = x_new;
end
end