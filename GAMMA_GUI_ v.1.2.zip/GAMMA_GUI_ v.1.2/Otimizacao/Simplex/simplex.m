function otm_simplex = simplex(otm)
%% Simplex Sequencial - GAMMA
% Vers�o: 08/06/2021
%% Caixa de di�logo do progresso da otimiza��o
fig = uifigure;
d = uiprogressdlg(fig,'Title','Otimiza��o Simplex...','Indeterminate','on');
drawnow
%% Op��es do algoritmo
opt.itr = 1000;
opt.eta = 0.0001;
opt.tol = 0.001;
%% Prepara��o dos dados
sinal = -1;
mix_var = otm(1).mixvar;
L = min(otm(1).dados.Variables{:,1:end-1});
U = max(otm(1).dados.Variables{:,1:end-1});
%L = [-1.6 -1.414];
%U = [2.5 1.414];
nresp = length(otm);
%% Par�metros do algoritmo
max_itr = opt.itr;  % Quantidade m�xima de itera��es
eta = opt.eta;      % Toler�ncia para os limites superiores e inferiores
tol = opt.tol;      % Crit�rio de parada
% Determina��o do n�mero de vari�veis
n = length(L); 
% Par�metros adaptativos do algoritmo
alfa = 1;
beta = 1 + 2/n;
gama = 0.75 - 1/(2*n);
delta = 1 - 1/n;
%% Inicializa��o
p = (sqrt(n+1)+n-1)/(n*sqrt(2));
q = (sqrt(n+1)-1)/(n*sqrt(2));
% Constru��o da matriz M - Simplex inicial
M = zeros(n,n+1);
% Estabelece o primeiro ponto no m�nimo
%M(:,1) = L;
% Estabelece o primeiro ponto no m�ximo
M(:,1) = U;
for j = 2:n+1
    for i = 1:n
        if (j - 1) == i
            M(i,j) = L(i) + p*(U(i) - L(i));
        else
            M(i,j) = L(i) + q*(U(i) - L(i));
        end
    end
end
% C�lculo dos valore de f para o simplex inicial
% As repostas ser�o armazenadas no vetor rv
D_perf = inf;
rv = zeros(n+1,1);
for i = 1:n+1
    % Estabelece a restri��o para as vari�veis de mistura
    if mix_var > 0
        M(:,i) = mix_res(M(:,i),mix_var,L,U,eta);
    end
    fdsjb = simplex_DS(M(:,i),otm);
    rv(i) = sinal*fdsjb.DS;
    saida(i,:) = fdsjb.y;
    if sinal*fdsjb.DS < D_perf
        D_perf = sinal*fdsjb.DS;
        b_net = fdsjb;
    end
    sim_reg{i} = 'Simplex Inicial';
end
%% Armazenamento do simplex inicial
ma = M';
ma(:,n+1) = sinal*rv;
ma(:,end+1:end+nresp) = saida;
vert = n+1;
%% Algoritmo simplex
pare = 0; % Crit�rio de parada
while pare == 0
    % Localizando o v�rtice de pior resposta
    [rv,j] = sort(rv); % Ordem crescente - minimiza��o
    M = M(:,j); % Ordena��o dos v�rtices
    % C�lculo das coordenadas do centr�ide
    cent = mean(M(:,1:n),2);
    %C�lculo das coordenadas de reflex�o
    R = cent + alfa*(cent - M(:,n+1));
    % Checagem da regi�o experimental
    R = boundcheck(R,L,U,eta);
    % Estabelece a restri��o para as vari�veis de mistura
    if mix_var > 0
        R = mix_res(R,mix_var,L,U,eta);
    end
    % C�lculo da resposta do centr�ide e da reflex�o
    fdsjb = simplex_DS(R,otm);
    rede_R = fdsjb;
    RR = sinal*fdsjb.DS;
    if sinal*fdsjb.DS < D_perf
        D_perf = sinal*fdsjb.DS;
        b_net = fdsjb;
    end
    if RR < rv(1)
    % Expans�o
        E = cent + beta*(R - M(:,n+1));
        E = boundcheck(E,L,U,eta);
        % Estabelece a restri��o para as vari�veis de mistura
        if mix_var > 0
            E = mix_res(E,mix_var,L,U,eta);
        end
        fdsjb = simplex_DS(E,otm);
        rede_E = fdsjb;
        RE = sinal*fdsjb.DS;
        if sinal*fdsjb.DS < D_perf
            D_perf = sinal*fdsjb.DS;
            b_net = fdsjb;
        end
        if RE < RR
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,E,RE,rede_E,nresp); % Armazenamento e sa�da
            sim_reg{vert} = 'Expans�o';
        else
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,R,RR,rede_R,nresp); % Armazenamento e sa�da
            sim_reg{vert} = 'Reflex�o';
        end
    % Armazenamento da reflex�o
    elseif RR < rv(n)
        [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,R,RR,rede_R,nresp); % Armazenamento e sa�da
        sim_reg{vert} = 'Reflex�o';
    % Contra��o externa
    elseif RR < rv(n+1)
        CE = cent + gama*(R - cent);
        CE = boundcheck(CE,L,U,eta);
        % Estabelece a restri��o para as vari�veis de mistura
        if mix_var > 0
            CE = mix_res(CE,mix_var,L,U,eta);
        end
        fdsjb = simplex_DS(CE,otm);
        rede_CE = fdsjb;
        RCE = sinal*fdsjb.DS;
        if sinal*fdsjb.DS < D_perf
            D_perf = sinal*fdsjb.DS;
            b_net = fdsjb;
        end
        if RCE <= RR
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,CE,RCE,rede_CE,nresp); % Armazenamento e sa�da
            sim_reg{vert} = 'Contra��o externa';
        else
            M = shrink(M,delta); % Encolhimento
            % C�lculo das respostas dos novos v�rtices
            for i = 2:n+1
                if mix_var > 0
                    M(:,i) = mix_res(M(:,i),mix_var,L,U,eta);
                end
                fdsjb = simplex_DS(M(:,i),otm);
                rv(i)= sinal*fdsjb.DS;
                y_d(i,:) = fdsjb.y;
                if sinal*fdsjb.DS < D_perf
                    D_perf = sinal*fdsjb.DS;
                    b_net = fdsjb;
                end
            end
            for i = 2:n+1
                vert = vert + 1;
                % Armazenamento do novo v�rtice
                ma(vert,1:n) = M(:,i)';
                ma(vert,n+1) = sinal*rv(i);
                ma(vert,n+2:n+1+nresp) = y_d(i,:);
                sim_reg{vert} = 'Encolhimento';
            end
        end
    % Contra��o interna
    else 
        CI = cent - gama*(R - cent); %C�lculo das coordenadas de contra��o interna
        CI = boundcheck(CI,L,U,eta); % Checagem da regi�o experimental
        % Estabelece a restri��o para as vari�veis de mistura
        if mix_var > 0
            CI = mix_res(CI,mix_var,L,U,eta);
        end
        fdsjb = simplex_DS(CI,otm);
        rede_CI = fdsjb;
        RCI = sinal*fdsjb.DS;
        if sinal*fdsjb.DS < D_perf
            D_perf = sinal*fdsjb.DS;
            b_net = fdsjb;
        end
        if RCI < rv(n+1)
            [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,CI,RCI,rede_CI,nresp); % Armazenamento e sa�da
            sim_reg{vert} = 'Contra��o interna';
        else
            M = shrink(M,delta); % Encolhimento
            % C�lculo das respostas dos novos v�rtices
            for i = 2:n+1
                if mix_var > 0
                    M(:,i) = mix_res(M(:,i),mix_var,L,U,eta);
                end
                fdsjb = simplex_DS(M(:,i),otm);
                rv(i)= sinal*fdsjb.DS;
                y_d(i,:) = fdsjb.y;
                if sinal*fdsjb.DS < D_perf
                    D_perf = sinal*fdsjb.DS;
                    b_net = fdsjb;
                end
            end
            for i = 2:n+1
                vert = vert + 1;
                % Armazenamento do novo v�rtice
                ma(vert,1:n) = M(:,i)';
                ma(vert,n+1) = sinal*rv(i);
                ma(vert,n+2:n+1+nresp) = y_d(i,:);
                sim_reg{vert} = 'Encolhimento';
            end
        end
    end
    % Crit�rio de parada
    % Converg�ncia nas vari�veis
    cont = 0;
    for i = 1:n
        if max(abs(ma(end-n-1:end,i) - ma(end,i))) < tol
            cont = cont + 1;
        end
    end
    if cont == n
        pare = 1;
    end
    % Quantidade m�xima de itera��es
    if vert >= max_itr
        pare = 1;
    end
    close all
end
% Sa�da das vari�veis importantes
otm_simplex.vsimplex = M;
otm_simplex.registro = sim_reg;
otm_simplex.vertices = ma;
otm_simplex.potm = b_net;
% Fecha a caixa de di�logo
close(d)
delete(fig)
%% Gr�ficos
for ii = 1:n+1+nresp
    figure
    plot(ma(:,ii))
    xlabel('V�rtices')
    if ii <= n
        texto = ['Vari�vel ' num2str(ii)];
    elseif ii == n+1
        texto = 'Desejabilidade Global';
    else
        texto = ['Resposta ' num2str(ii-n-1)];
    end
    ylabel(texto)
end

