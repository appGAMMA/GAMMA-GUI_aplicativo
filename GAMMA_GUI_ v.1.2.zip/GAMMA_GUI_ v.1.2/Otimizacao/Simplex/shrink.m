%% Encolhimento da figura simplex
% Vers�o: 08/06/2021
function x = shrink(x,delta)
n = size(x,1);
% Substitui��o dos n+1 v�rtices, exceto o melhor
for i = 2:n+1
    x(:,i) = x(:,1) + delta*(x(:,i) - x(:,1));
end
end