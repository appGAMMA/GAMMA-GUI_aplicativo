%% Multiple-response optimization
% Utiliza��o das fun��es de Derringer e Suich (m�ximo, m�nimo e alvo)
% Vers�o 08/06/2021
function saida = simplex_DS(x,otm)
%% Prepara��o dos dados
nresp = length(otm); % N�mero de respostas
r = zeros(1,nresp);
y_i = zeros(1,nresp);
y_s = zeros(1,nresp);
y_a = zeros(1,nresp);
y = zeros(nresp,1);
for ii = 1:nresp
    r(ii) = otm(ii).importancia; % import�ncia para as desejabilidades individuais
    y_i(ii) = otm(ii).ymin; % limite inferior
    y_s(ii) = otm(ii).ymax; % limite superior
    y_a(ii) = otm(ii).alvo; % valor alvo
    y(ii) = predict(otm(ii).dados,x'); % Calculo dos valores de y
end
%% Fun��o de desejabilidade
% Desejabilidades individuais 
ds = zeros(1,nresp);
DT = 1;   % Desejabilidade total
for i = 1:nresp
    % Identifica��o de minimiza��o, maximiza��o ou alvo
    if y_a(i) == y_s(i) % Maximiza��o
        if y(i) <= y_i(i)
            ds(i) = 0;
        elseif y(i) >= y_s(i)
            ds(i) = 1;
        else
            ds(i) = ((y(i) - y_i(i))/(y_s(i) - y_i(i)))^r(i);
        end
    elseif y_a(i) == y_i(i) % Minimiza��o
        if y(i) >= y_s(i)
            ds(i) = 0;
        elseif y(i) <= y_i(i)
            ds(i) = 1;
        else
            ds(i) = ((y(i) - y_s(i))/(y_i(i) - y_s(i)))^r(i);
        end
    else % Valor Alvo
        if y(i) <= y_i(i)
            ds(i) = 0;
        elseif y(i) >= y_s(i)
            ds(i) = 0;
        elseif y(i) <= y_a(i)
            ds(i) = ((y(i) - y_i(i))/(y_a(i) - y_i(i)))^r(i);
        else
            ds(i) = ((y(i) - y_s(i))/(y_a(i) - y_s(i)))^r(i);
        end
    end
    DT = DT*ds(i);
end
% Desejabilidade total
DT = DT^(1/nresp);
% Armazenamento
saida.y = y;
saida.y_d = ds;
saida.DS = DT;
saida.x = x;
