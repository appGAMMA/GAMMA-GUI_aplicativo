%% Armazena o novo v�rtice
% Vers�o: 08/06/2021
function [M,rv,ma,vert] = newvert(sinal,M,rv,ma,vert,x,f,rede,nresp)
n = size(M,1);
vert = vert + 1;
M(:,end) = x;
rv(end) = f;
ma(vert,1:n) = x';
ma(vert,n+1) = sinal*f;
ma(vert,n+2:n+1+nresp) = rede.y';