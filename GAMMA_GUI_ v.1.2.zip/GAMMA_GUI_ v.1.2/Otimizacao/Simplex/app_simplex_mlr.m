%% Coleta as informações iniciais para otimização simplex usando os modelo do app MLR
% Versão: 08/06/2021
function app_simplex_mlr
%% Criar a tabela para a entrada dos modelos
nmod = 20; % Quantidade máxima de modelos
texto = 'Otimização Simplex';
pos = [300 200 450 300];
fig = uifigure('Name',texto,'Position',pos);
% Texto explicativo
texto = "Otimização Simplex usando o algoritmo sequencial de Nelder-Mead (https://periodicos.uem.br/ojs/index.php/ActaSciTechnol/article/view/3012). Otimização simulatânea usando a função de desejabilidade de Derringer-Suich. Indicar a(s) estrutura(s) com o(s) modelo(s) a ser(em) otimizado(s).";
wraptexto = "{" + replace(texto," ","} {") + "} ";
uilabel(fig,'Position',[10 pos(4)-85 pos(3)-10 100],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Tabela de dados
uit = uitable(fig,'Position',[10 50 pos(3)-20 pos(4)-120]);
uit.ColumnName = {'Modelo';'Estrutura'}; 
uit.ColumnWidth = {80,"auto"};
uit.ColumnEditable = [true true]; % habilita a edição nas colunas
dados = cell(nmod,2);
for ii = 1:nmod
    dados{ii,1} = ['Modelo ' num2str(ii)];
end
uit.Data = dados;
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Continuar','ButtonPushedFcn', @(btn,event) ler_modelos(btn,fig,uit));
end
%% Leitura dos dados após eventual alteração pelo usuário
function ler_modelos(~,fig,uit)
    dados = uit.Data;
    delete(fig)
    nmod = size(dados,1);
    idx = 0;
    otm = struct;
    for ii = 1:nmod
        if ~isempty(dados{ii,2})
            idx = idx + 1;
            otm(idx).modelo = dados{ii,1};
            otm(idx).dados = evalin('base',dados{ii,2});
        end
    end
    nmod = idx; % quantidade real de modelos
    app_dados_otimizacao(nmod,otm)
end
%% Tela para atribuição das propriedades de cada modelo na otimização
function app_dados_otimizacao(nmod,otm)
    texto = 'Função de desejabilidade';
    pos = [100 200 567 300];
    fig = uifigure('Name',texto,'Position',pos);
    % Texto explicativo
    texto = "Para maximização alvo = y máximo, para minimização alvo = y mínimo, para otimização bilateral y mínimo < alvo < y máximo. Quanto maior o valor do expoente, maior será a importância relativa do modelo na otimização.";
    wraptexto = "{" + replace(texto," ","} {") + "} ";
    uilabel(fig,'Position',[10 pos(4)-85 pos(3)-15 90],'Interpreter','latex','WordWrap','on','Text',wraptexto);
    % Tabela de dados
    uit = uitable(fig,'Position',[10 90 pos(3)-20 pos(4)-170]);
    uit.ColumnName = {'Modelo';'Incluir';'Variáveis de mistura';'y mínimo';'y máximo';'Alvo';'Expoente'}; 
    uit.ColumnEditable = true; % habilita a edição na coluna 2
    uit.ColumnFormat = {[] 'logical' [] [] [] [] []};
    uit.ColumnWidth = 'fit';
    dados = cell(nmod,7);
    for ii = 1:nmod
        dados{ii,1} = otm(ii).modelo;
        dados{ii,2} = 1;
        dados{ii,3} = 0.0;
        dados{ii,4} = min(otm(ii).dados.modelo.Variables{:,end});
        dados{ii,5} = max(otm(ii).dados.modelo.Variables{:,end});
        dados{ii,6} = max(otm(ii).dados.modelo.Variables{:,end});
        dados{ii,7} = 1.0;
    end
    uit.Data = dados;
    % Campo de edição para salvar os dados da otimização
    texto = 'Saída para os resultados da otimização';
    uilabel(fig,'Position',[10 50 230 30],'Text',texto);
    namefld = uieditfield(fig,'text','Position',[230 50 180 30],'Value','otm_out');
    % Criar o botão de leitura dos dados
    btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Otimizar','ButtonPushedFcn', @(btn,event) otimizacao_simplex(btn,nmod,otm,uit,namefld));
end
%% Iniciar a otimização simplex
function otimizacao_simplex(~,nmod,modelos,uit,namefld)
    saida = namefld.Value;
    dados = uit.Data;
    idx = 0;
    otm = struct;
    for ii = 1:nmod
        if dados{ii,2} == 1
            idx = idx + 1;
            otm(idx).modelo = modelos(ii).modelo;
            otm(idx).dados = modelos(ii).dados.modelo;
            otm(idx).mixvar = dados{ii,3};
            otm(idx).ymin = dados{ii,4};
            otm(idx).ymax = dados{ii,5};
            otm(idx).alvo = dados{ii,6};
            otm(idx).importancia = dados{ii,7};
        end
    end
    nmod = idx; % Correção na quantidade de modelos
    final.modelos = nmod;
    final.dados = otm;
    otm_simplex = simplex(otm);
    final.resultado = otm_simplex;
    assignin('base',saida,final)
end