% Encolhimento da figura simplex
function x = shrink(x,delta)

disp('Encolhimento da figura simplex ...')

n = size(x,1);
% Substitui��o dos n+1 v�rtices, exceto o melhor
for i = 2:n+1
    x(:,i) = x(:,1) + delta*(x(:,i) - x(:,1));
end

end