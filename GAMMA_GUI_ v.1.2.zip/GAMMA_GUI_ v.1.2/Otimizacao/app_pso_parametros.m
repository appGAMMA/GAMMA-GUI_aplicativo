%% Cria uma tabela com os parâmetros da SVR
% Versão: 30/04/2023
function app_pso_parametros(app)
%% Cria os valores iniciais da tabela
lista{1} = 'Quantidade de partículas';
valor(1) = 20;
lista{2} = 'Fração mínima de vizinhos';
valor(2) = 0.25;
lista{3} = 'Mínimo de inércia';
valor(3) = 0.1;
lista{4} = 'Máximo de inércia';
valor(4) = 1.1;
lista{5} = 'Peso de auto ajuste';
valor(5) = 1.49;
lista{6} = 'Peso de ajuste social';
valor(6) = 1.49;
lista{7} = 'Tolerância de parada';
valor(7) = 1e-3;
lista{8} = 'Máximo de iterações';
valor(8) = 100;
lista{9} = 'Tempo máximo (segundos)';
valor(9) = 600;
lista{10} = 'Máximo de iterações de parada';
valor(10) = 10;
lista{11} = 'Mínimo da função objetivo';
valor(11) = 0;
%% Criação da janela gráfica
texto = 'Parâmetros PSO';
pos = [300 300 350 350];
fig = uifigure('Name',texto,'Position',pos);
% Tabela de dados
uit = uitable(fig,'Position',[10 90 pos(3)-20 pos(4)-100]);
uit.ColumnName = {'Parâmetro';'Valor'}; 
uit.ColumnEditable = [false true]; % habilita a edição nas colunas
nparam = length(lista);
dados = cell(nparam,2);
for ii = 1:nparam
    dados{ii,1} = lista{ii};
    dados{ii,2} = valor(ii);
end
uit.Data = dados;
uilabel(fig,'Text','Função híbrida','Position',[15 60 100 20]);
uid = uidropdown(fig,'Position',[100 60 100 20],'Items',{'nenhuma','fmincon','patternsearch'},'Value','nenhuma');
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Salvar','ButtonPushedFcn', @(btn,event) salva_param(btn,fig,uit,uid,app));
end
%% Saída dos valores alterados pelo usuário
function salva_param(~,fig,uit,uid,app) 
dados = uit.Data;
f = uid.Value;
delete(fig)
nparam = size(dados,1);
lista = cell(nparam,1);
v = zeros(nparam,1);
for ii = 1:nparam
    lista{ii} = dados{ii,1};
    v(ii) = dados{ii,2};
end
switch f
    case 'nenhuma'
        fv = [];
    otherwise
        fv = f;
end
app.opt_pso = optimoptions('particleswarm','HybridFcn',fv,'InertiaRange',[v(3),v(4)], ...
    'MaxIterations',v(8),'MaxStallIterations',v(10),'MaxTime',v(9),'MinNeighborsFraction',v(2), ...
    'ObjectiveLimit',v(11),'SelfAdjustmentWeight',v(5),'SocialAdjustmentWeight',v(6), ...
    'SwarmSize',v(1),'FunctionTolerance',v(7),'Display','off','PlotFcns','pswplotbestf');
end