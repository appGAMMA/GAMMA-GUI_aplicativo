%% Faz o gr�fico de sali�ncias - app
%% Vers�o: 01/05/2022
function app_plot_saliences(res,eixo)
%% Dados
if eixo(3) ~= 0
    op = 3;
    d1 = eixo(1);
    d2 = eixo(2);
    d3 = eixo(3);
elseif eixo(2) ~= 0
    op = 2;
    d1 = eixo(1);
    d2 = eixo(2);
else
    op = 1;
    d1 = eixo(1);
end
ncds = res.CDs;
S = res.S{:,:};
tab = size(S,1); % quantidade de tabelas
explained = res.explained(1,:);
tab_nam = cell(tab,1);
for ii = 1:tab
    tab_nam{ii} = res.data(ii).info;
end
texto = 'CD';
%% Gr�ficos
switch op
    case 1 % 1D
        if d1 > ncds
            msgbox('CD inexistente!','Gr�fico de Sali�ncias','warn');
            return
        end
        figure
        stem(S(:,d1),'filled')
        xlim([0 tab+1])
        text(1:tab,S(:,d1)+0.025*S(:,d1),tab_nam)
        xlabel('Tabelas')
        str = [texto num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        ylabel(str)
    case 2 % 2D
        if d1 > ncds || d2 > ncds
            msgbox('CD inexistente!','Gr�fico de Sali�ncias','warn');
            return
        end
        figure
        plot(S(:,d1),S(:,d2),'ob')
        grid on
        axis equal
%         emax = 1.1*(max([xlim ylim]));
%         emin = 1.1*(min([xlim ylim]));
%         xlim([emin emax])
%         ylim([emin emax])
        xlim([0 1])
        ylim([0 1])
        str = [texto num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        xlabel(str)
        str = [texto num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
        ylabel(str)
        str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2),'%3.2f'),'%'];
        title(str)
        % Nome nas amostras
        text(S(:,d1),S(:,d2),tab_nam)
    case 3
        if d1 > ncds || d2 > ncds || d3 > ncds
            msgbox('CD inexistente!','Gr�fico de Sali�ncias','warn');
            return
        end
        figure
        plot3(S(:,d1),S(:,d2),S(:,d3),'ob')
        grid on
        axis equal
        emax = 1.1*(max([xlim ylim zlim]));
        emin = 1.1*(min([xlim ylim zlim]));
        xlim([emin emax])
        ylim([emin emax])
        zlim([emin emax])
        str = [texto num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        xlabel(str)
        str = [texto num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
        ylabel(str)
        str = [texto num2str(d3) ' (' num2str(explained(d3),'%3.2f') '%)'];
        zlabel(str)
        str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2)+explained(d3),'%3.2f'),'%'];
        title(str)
        % Nome nas amostras
        text(S(:,d1),S(:,d2),S(:,d3),tab_nam)
end