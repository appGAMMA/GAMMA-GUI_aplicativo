function limiar = plot_post_svc(GN,kSVC,graf)
%% Plota a probabilidade a posteriori da sa�da da SVM usando o m�todo de Platt
%% Vers�o: 13/02/2017
%% Prepara��o dos dados
nclass = length(GN);
limiar = zeros(nclass,1);
%% Limiar de cada classe
for ii = 1:nclass
    A = kSVC{ii}.model.ProbA;
    B = kSVC{ii}.model.ProbB;
    limiar(ii) = (log(1/0.5 - 1) - B)/A;
end
%% Gr�ficos
if graf == 1
    for ii = 1:nclass
        figure
        hold on
        % Sa�da da SVM a partir das probabilidades 
        pap = kSVC{ii}.yo;
        clas = kSVC{ii}.yb;
        A = kSVC{ii}.model.ProbA;
        B = kSVC{ii}.model.ProbB;
        fsvm = (log(1./pap - 1) - B)./A;
        % Simula��o de uma sa�da cont�nua da SVM
        %fmin = round(min(fsvm) - 1);
        %fmax = round(max(fsvm) + 1);
        fmax = round(max(abs(fsvm)));
        fmin = -1*fmax;
        faixa = -1*fmax:0.1:fmax;
        p_classe = 1./(1 + exp(A.*faixa + B));
        p_nclasse = 1 - p_classe;
        % Histogramas
        idx = clas == 1;
        histogram(fsvm(idx),'FaceColor','b','BinWidth',0.20)
        idx = clas == -1;
        histogram(fsvm(idx),'FaceColor','r','BinWidth',0.20)
        xlim([fmin fmax])
        xlabel('SVM output')
        ylabel('Number of samples')
        legend(GN{ii},'Other samples','Location','northwest')
        % Gr�fico como um novo eixo y
        ax1 = gca; % current axes
        ax1_pos = ax1.Position; % position of first axes
        ax2 = axes('Position',ax1_pos,'XAxisLocation','top','YAxisLocation','right','Color','none');
        line(faixa,p_classe,'Parent',ax2,'Color','b')
        %set(gca,'YAxisLocation','right')
        ylabel('Posterior Probabilitie')
        xlim([fmin fmax])
        line(faixa,p_nclasse,'Parent',ax2,'Color','r')
        xg = [limiar(ii) limiar(ii)];
        yg = ylim;
        ylim(yg)
        line(xg,yg,'LineStyle',':','Color','k') % Linha vertical
        hold off
    end
end