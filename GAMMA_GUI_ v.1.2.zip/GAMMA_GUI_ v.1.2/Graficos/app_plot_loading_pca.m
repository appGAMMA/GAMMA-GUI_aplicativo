%% Faz o gr�fico de loadings PCA - app
% Vers�o: 18/05/2023
function app_plot_loading_pca(res_pca)
%% interface de usu�rio
texto = 'Gr�fico de Loadings';
pos = [300 300 270 230];
fig = uifigure('Name',texto,'Position',pos);
pcs = length(res_pca.latent);
lista = cell(pcs,1);
for ii = 1:pcs
    lista{ii} = num2str(ii);
end
uilabel(fig,'Text','Escolha as PCs','Position',[15 pos(4)-30 100 20],'FontWeight','bold');
uilabel(fig,'Text','*Para m�ltiplas PCs mantenha a tecla CTRL pressionada','Position',[15 pos(4)-70 180 40],'WordWrap','on');
uilabel(fig,'Text','**Para biplot escolha no m�nimo duas e no m�ximo tr�s PCs','Position',[15 pos(4)-110 180 40],'WordWrap','on');
lbx = uilistbox(fig,'Position',[200 pos(4)-110 50 100],'Multiselect','on','Items',lista,'ItemsData',1:pcs);
uilabel(fig,'Text','Tipo de gr�fico','Position',[15 pos(4)-140 100 20]);
dd = uidropdown(fig,'Items',{'Discreto','Linha','Biplot'},'Value','Discreto','Position',[110 pos(4)-140 140 20]);
cbx = uicheckbox(fig,'Position',[15 pos(4)-185 230 40],'Text','Incluir intervalo � 2 SD (indispon�vel para mais de uma PC ou Biplot)','WordWrap','on');
% Criar o bot�o de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Plotar','ButtonPushedFcn', @(btn,event) plot_loadings(btn,fig,lbx,dd,cbx,res_pca));
end
%% Gr�fico de loadings
function plot_loadings(~,~,lbx,dd,cbx,res_pca)
eixo = lbx.Value;
graf = dd.Value;
cce = length(eixo);
op = cbx.Value;
L = res_pca.P;
vrs = size(L,1); % quantidade de vari�veis
T = res_pca.T;
ams = size(T,1); % quantidade de amostras
switch graf
    case 'Discreto'
        tipo = 0;
    case 'Linha'
        tipo = 1;
    case 'Biplot'
        if cce < 2
            msgbox('Quantidade insuficiente de PCs!','Gr�fico de Loadings','warn');
            return
        elseif cce > 3
            msgbox('Quantidade m�xima de PCs excedida!','Gr�fico de Loadings','warn');
        return
        end
        tipo = 2;
        b_plot = zeros(ams,cce);
end
vname = res_pca.variaveis;
samples = res_pca.amostras;
explained = res_pca.explained;
% Gr�fico
cc_leg = cell(cce,1);
y_plot = zeros(vrs,cce);
for ii = 1:cce
    cc_leg{ii} = ['PC' num2str(eixo(ii))];
    y_plot(:,ii) = L(:,eixo(ii));
    if tipo == 2
        b_plot(:,ii) = T(:,eixo(ii));
    end
end
switch tipo
    case 0 % discreto
        figure
        stem(y_plot,'filled')
        ylabel('Loading')
        % Muda os nomes das barras (TickLabel)
        ax = gca;
        xticks = vname;
        set(ax,'XTickLabel',xticks)
        set(ax,'XTick',1:vrs)
        set(ax,'XTickLabelRotation',90)
        xlim([0 vrs+1])
        % Intervalo � 2 SD
        if op == 1 && cce < 2
            sd = std(y_plot);
            xg = xlim;
            yg = [2*sd 2*sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            yg = [-2*sd -2*sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            cc_leg{end+1} = '� 2 SD';
        end
        legend(cc_leg,'Location','Best')
    case 1 % espectros (linha)
        if iscell(vname)
            temp = zeros(1,vrs);
            for ii = 1:vrs
                temp(ii) = str2double(vname{ii}(2:end));
            end
            vname = temp;
        end
        figure
        hold on
        for ii = 1:cce
            plot(vname,y_plot(:,ii),'LineWidth',1.5)
        end
        hold off
        xlim([min(vname) max(vname)])
        % Intervalo � 2 SD
        if op == 1 && cce < 2
            sd = std(y_plot);
            xg = xlim;
            yg = [sd sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            yg = [-sd -sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            cc_leg{end+1} = '� 2 SD';
        end
        % Eixo horizontal
        xg = xlim;
        yg = [0 0];
        line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5) 
        xlim(xg)
        ylabel('Loading')
        xlabel('Vari�veis')
        legend(cc_leg,'Location','Best')
    case 2 % biplot 
        figure
        if isnumeric(vname)
            temp = cell(length(vname),1);
            for ii = 1:length(vname)
                temp{ii} = num2str(vname(ii));
            end
        else
        temp = cellstr(vname);
        end
        h = biplot(y_plot,'scores',b_plot,'varlabels',temp,'obslabels',samples);
        axis equal
        emax = 1.1*(max([xlim ylim]));
        emin = 1.1*(min([xlim ylim]));
        xlim([emin emax])
        ylim([emin emax])
        str = ['PC',num2str(eixo(1)),' (',num2str(explained(eixo(1)),'%3.2f'),'%)'];
        xlabel(str)
        str = ['PC',num2str(eixo(2)),' (',num2str(explained(eixo(2)),'%3.2f'),'%)'];
        ylabel(str)
        if cce == 3
            str = ['PC',num2str(eixo(3)),' (',num2str(explained(eixo(3)),'%3.2f'),'%)'];
            zlabel(str)
            str = ['Vari�ncia Total: ',num2str(explained(eixo(1))+explained(eixo(2))+explained(eixo(3)),'%3.2f'),'%'];
        else
            str = ['Vari�ncia Total: ',num2str(explained(eixo(1))+explained(eixo(2)),'%3.2f'),'%'];
        end
        title(str)
        % Coloca o nome das amostras no biplot
        ini = size(y_plot,1)*3;
        for ii = 1:size(b_plot,1)
            prop = get(h(ii+ini));
            px = prop.XData(1);
            py = prop.YData(1);
            if cce == 3
                pz = prop.ZData(1);
                text(px+0.005,py+0.010,pz+0.005,samples{ii})
            else
                text(px+0.005,py+0.010,samples{ii})
            end
        end
end
end