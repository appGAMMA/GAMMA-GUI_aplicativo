function app_plot_scree(res_pca)
%% Faz o gr�fico de scree
%% Vers�o: 18/11/2020
%% Dados
latent = res_pca.latent;
x = res_pca.X;
ams = length(latent);
%% Gr�fico de scree
figure
plot(latent,'-bo','LineWidth',1.5)
xlim([0 ams+1])
xlabel('Componente Principal')
ylabel('Autovalor')