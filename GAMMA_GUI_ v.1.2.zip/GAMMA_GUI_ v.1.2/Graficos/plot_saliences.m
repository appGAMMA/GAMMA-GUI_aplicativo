%% Faz o gr�fico de sali�ncias
%% Vers�o: 25/01/2018
function plot_saliences(score,explained,samples)
eixo = 'CD';
op = 1; % Para abrir o loop
while op == 1
    ams = size(score,1); % quantidade de amostras
    fprintf('\n')
    op = input('Tipo de gr�fico: (1) 1D (2) 2D (3) 3D ');
    fprintf('\n')
    switch op
        case 1 % 1D
            texto = ['Indique a ' eixo ' a ser utilizada'];
            disp(texto)
            d1 = input('Dimens�o 1: ');
            figure
            stem(score(:,d1),'filled')
            xlim([0 ams+1])
            text(1:ams,score(:,d1)+0.075*score(:,d1),samples)
            xlabel('Tabelas')
            str = [eixo num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
            ylabel(str)
        case 2 % 2D
            texto = ['Indique as ' eixo 's a serem utilizadas'];
            disp(texto)
            d1 = input('Dimens�o 1: ');
            d2 = input('Dimens�o 2: ');
            figure
            plot(score(:,d1),score(:,d2),'+b')
            axis equal
            emax = 1.1*(max([xlim ylim]));
            emin = 1.1*(min([xlim ylim]));
            xlim([emin emax])
            ylim([emin emax])
            str = [eixo num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
            xlabel(str)
            str = [eixo num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
            ylabel(str)
            str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2),'%3.2f'),'%'];
            title(str)
            % Nome nas amostras
            text(score(:,d1),score(:,d2),samples)
        case 3
            texto = ['Indique as ' eixo 's a serem utilizadas'];
            disp(texto)
            d1 = input('Dimens�o 1: ');
            d2 = input('Dimens�o 2: ');
            d3 = input('Dimens�o 3: ');
            figure
            plot3(score(:,d1),score(:,d2),score(:,d3),'+b')
            axis equal
            emax = 1.1*(max([xlim ylim zlim]));
            emin = 1.1*(min([xlim ylim zlim]));
            xlim([emin emax])
            ylim([emin emax])
            zlim([emin emax])
            str = [eixo num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
            xlabel(str)
            str = [eixo num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
            ylabel(str)
            str = [eixo num2str(d3) ' (' num2str(explained(d3),'%3.2f') '%)'];
            zlabel(str)
            str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2)+explained(d3),'%3.2f'),'%'];
            title(str)
            % Nome nas amostras
            text(score(:,d1),score(:,d2),score(:,d3),samples)
    end
    fprintf('\n')
    op = input('Deseja fazer outro gr�fico de sali�ncias? (0) N�o (1) Sim ');
end