%% Faz o gráfico aranha
% Versão: 24/04/2022
function app_aranha(s)
% Preparação dos dados
% Variáveis
nvrs = length(s.Resultados);
vrs = cell(nvrs,1);
for ii = 1:nvrs
    vrs{ii} = s.Resultados(ii).Variavel;
end
% Amostras
ams = s.Resultados(1).Stats.gnames  ;
nams = length(ams);
% dados
x = zeros(nams,nvrs);
for ii = 1:nvrs
    x(:,ii) = s.Resultados(ii).Stats.means;
end
% p-valor
pv = zeros(nvrs,1);
for ii = 1:nvrs
    pv(ii) = cell2mat(s.Resultados(ii).ANOVA{1,6});
end
% Janela de usuário
texto = 'Gráfico Aranha';
pos = [350 250 400 500];
fig = uifigure('Name',texto,'Position',pos);
% Texto explicativo
texto = "Variáveis estatisticamente significativas previamente selecionadas";
uilabel(fig,'Position',[10 pos(2)+190 pos(3)-15 90],'Text',texto);
% Tabela das variáveis
uit1 = uitable(fig,'Position',[10 pos(2)+50 pos(3)-20 170]);
uit1.ColumnName = {'Selecionar';'Variável'}; 
uit1.ColumnEditable = [true true]; % habilita a edição das colunas
uit1.ColumnFormat = {'logical' []};
dados1 = cell(nvrs,2);
for ii = 1:nvrs
    if pv(ii) <= s.Alfa
        dados1{ii,1} = 1;
    else
        dados1{ii,1} = 0;
    end
    dados1{ii,2} = vrs{ii};
end
uit1.Data = dados1;
% Tabela das amostras
texto = "Seleção de amostras";
uilabel(fig,'Position',[10 pos(2)-10 pos(3)-15 90],'Text',texto);
uit2 = uitable(fig,'Position',[10 pos(2)-190 pos(3)-20 210]);
uit2.ColumnName = {'Selecionar';'Amostra';'Preencher'}; 
uit2.ColumnEditable = [true true true]; % habilita a edição das colunas
uit2.ColumnFormat = {'logical' [] 'logical'};
dados2 = cell(nams,3);
for ii = 1:nams
    dados2{ii,1} = 1;
    dados2{ii,2} = ams{ii};
    dados2{ii,3} = 0;
end
uit2.Data = dados2;
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Gerar Gráfico','ButtonPushedFcn', @(btn,event) grafico_aranha(btn,uit1,uit2,x,vrs,ams));
end
%% Função que gera o gráfico
function grafico_aranha(~,uit1,uit2,x,vrs,ams)
nvrs = length(vrs);
nams = length(ams);
% Variáveis
d1 = uit1.Data;
idx = zeros(nvrs,1);
for ii = 1:nvrs
    idx(ii) = d1{ii,1};
end
idx = logical(idx);
vrs(~idx) = [];
x(:,~idx) = [];
% Amostras
d2 = uit2.Data;
idx = zeros(nams,1);
fop = cell(1,nams);
ftr = ones(1,nams)*0.2;
for ii = 1:nams
    idx(ii) = d2{ii,1};
    if logical(d2{ii,3}) == 1
        fop{ii} = 'on';
    else
        fop{ii} = 'off';
    end
end
idx = logical(idx);
ams(~idx) = [];
x(~idx,:) = [];
fop(~idx) = [];
ftr(~idx) = [];
% Gráfico
figure
spider_plot_R2019b(x,'AxesLabels',vrs','FillOption',fop,'FillTransparency',ftr);
legend(ams,'Location','best');
end