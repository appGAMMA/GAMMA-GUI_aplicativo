%% Faz o gráfico 3D dos scores
% Versão: 18/05/2023
function app_plot_scores_3D(model)
%% Dados
pcs = length(model.latent);
%% Criação da janela gráfica
texto = 'Gráfico de Scores 3D';
pos = [300 300 370 200];
fig = uifigure('Name',texto,'Position',pos);
uilabel(fig,'Text','Escolha as PCs','Position',[15 pos(4)-30 100 20]);
uilabel(fig,'Text','Eixo X','Position',[15 pos(4)-55 50 20]);
spn1 = uispinner(fig,'Limits',[1  pcs],'Value',1,'Position',[70 pos(4)-55 50 20]);
uilabel(fig,'Text','Eixo Y','Position',[135 pos(4)-55 50 20]);
spn2 = uispinner(fig,'Limits',[1  pcs],'Value',2,'Position',[180 pos(4)-55 50 20]);
uilabel(fig,'Text','Eixo Z','Position',[255 pos(4)-55 50 20]);
spn3 = uispinner(fig,'Limits',[1  pcs],'Value',3,'Position',[300 pos(4)-55 50 20]);
uilabel(fig,'Text','Identificação das amostras','Position',[15 pos(4)-85 200 20]);
dd1 = uidropdown(fig,'Items',{'Nenhuma','Numeração','Nome','Cor por grupo'},'Value','Nenhuma','Position',[170 pos(4)-85 140 20]);
cbx1 = uicheckbox(fig,'Position',[15 pos(4)-115 150 20],'Text','Elipsoide de confiança');
uilabel(fig,'Text','Probabilidade','Position',[170 pos(4)-115 100 20]);
spn4 = uispinner(fig,'Limits',[1 99],'Value',95,'Position',[260 pos(4)-115 50 20]);
cbx2 = uicheckbox(fig,'Position',[15 pos(4)-145 250 20],'Text','Eixos na mesma escala');
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Plotar','ButtonPushedFcn', @(btn,event) plot_3D(btn,fig,spn1,spn2,spn3,spn4,dd1,cbx1,cbx2,model));
end
%% Gráfico de scores 2D
function plot_3D(~,~,spn1,spn2,spn3,spn4,dd1,cbx1,cbx2,model)
pc1 = spn1.Value;
pc2 = spn2.Value;
pc3 = spn3.Value;
prob = spn4.Value;
tipo = dd1.Value;
op(1) = cbx1.Value;
op(2) = cbx2.Value;
Tx = model.T(:,pc1);
Ty = model.T(:,pc2);
Tz = model.T(:,pc3);
varx = model.explained(pc1,1);
vary = model.explained(pc2,1);
varz = model.explained(pc3,1);
nams = size(Tx,1);
figure
switch tipo
    case 'Nenhuma'
        plot3(Tx,Ty,Tz,'bo')
    case 'Numeração'
        plot3(Tx,Ty,Tz,'bo')
        texto = cell(nams,1);
        for ii = 1:nams
            texto{ii} = num2str(ii);
        end
        hold on
        text(Tx,Ty,Tz,texto)
    case 'Nome'
        plot3(Tx,Ty,Tz,'bo')
        texto = model.amostras;
        hold on
        text(Tx,Ty,Tz,texto)
    case 'Cor por grupo'
        [g,gn] = grp2idx(model.amostras);
        grupos = length(gn);
        for ii = 1:grupos
            idx = g == ii;
            scatter3(Tx(idx),Ty(idx),Tz(idx),'filled')
            hold on
        end
        legend(gn,'Location','best')
end
axis padded
grid on
xlabel(['PC' num2str(pc1) ' (' num2str(varx,'%.2f') '%)'])
ylabel(['PC' num2str(pc2) ' (' num2str(vary,'%.2f') '%)'])
zlabel(['PC' num2str(pc3) ' (' num2str(varz,'%.2f') '%)'])
title(['Variância total: ' num2str(varx+vary+varz,'%.2f') '%'])
% Elipsoide de confiança
if op(1) == 1
    latent = model.latent;
    r1 = sqrt(((nams+1)*3*latent(pc1)/(nams*(nams-3)))*finv(prob/100,3,nams-3)); % Raio na PC1 
    r2 = sqrt(((nams+1)*3*latent(pc2)/(nams*(nams-3)))*finv(prob/100,3,nams-3)); % Raio na PC2
    r3 = sqrt(((nams+1)*3*latent(pc3)/(nams*(nams-3)))*finv(prob/100,3,nams-3)); % Raio na PC3
    hold on
    [X,Y,Z] = ellipsoid(0,0,0,r1,r2,r3,20);
    mesh(X,Y,Z,'FaceColor','r','EdgeColor','r','FaceAlpha',0.1,'DisplayName','Elipsoide de confiança')
    subtitle(['Elipsoide com ' num2str(prob) '% de confiança'])
end
% Eixos na mesma escala
if op(2) == 1
    emax = 1.1*(max([xlim ylim zlim]));
    emin = 1.1*(min([xlim ylim zlim]));
    xlim([emin emax])
    ylim([emin emax])
    zlim([emin emax])
    axis square
end
end