%% Gráfico com as estatísticas resumidas do modelo PLS
% Versão: 05/04/2023
function app_graf_stat_pls(model)
%% Dados
lv = model.VLs;
% Calibração
rmse = model.STATcal.RMSE;
r2 = model.STATcal.r2;
nome{1} = 'Calibração';
cont = 1;
% Validação cruzada
try
    rmse = [rmse;model.CV.RMSECV(lv)];
    r2 = [r2;model.CV.r2_cv(lv)];
    cont = cont + 1;
    nome{cont} = 'Validação';
catch
    msgbox('A validação cruzada não foi realizada!','PLS','warn');
end
% Previsão
try
    rmse = [rmse;model.STATprev.RMSE];
    r2 = [r2;model.STATprev.r2];
    cont = cont + 1;
    nome{cont} = 'Previsão';
catch
    msgbox('Grupo de previsão inexistente!','PLS','warn');
end
%% Gráficos de barras
figure
subplot(1,2,1)
bar(rmse)
ax= gca;
set(ax,'XTick',1:length(nome),'XTickLabel',nome)
ylabel('RMSE')
ax.YGrid = 'on'; 
gmin = min(rmse,[],'all');
gmax = max(rmse,[],'all');
ylim([gmin-0.30*gmin gmax+0.30*gmax])
title(['Modelo com ' num2str(lv) ' LVs'])
subplot(1,2,2)
bar(r2,'red')
ax= gca;
set(ax,'XTick',1:length(nome),'XTickLabel',nome)
ylabel('r^{2}')
ax.YGrid = 'on'; 
gmin = min(r2,[],'all');
gmax = max(r2,[],'all');
ylim([gmin-0.30*gmin gmax+0.30*gmax])
title(['Modelo com ' num2str(lv) ' LVs'])


