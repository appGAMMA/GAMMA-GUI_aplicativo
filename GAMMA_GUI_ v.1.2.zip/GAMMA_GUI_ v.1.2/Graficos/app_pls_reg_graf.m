%% Faz gr�ficos para avaliar a performance de modelos de regress�o pls
% Vers�o: 08/05/2023
function graf_out = app_pls_reg_graf(model,op_graf)
alfa = 0.05;    % probabilidade para a elipse de confian�a
sigma_out = 2;  % valor de desvio para definir outliers
am_treina = model.Cal;
y_treina = model.ycal;
yp_treina = model.ypcal;
am_teste = model.Pred;
y_teste = model.yprev;
if ~isempty(y_teste)
    yp_teste = model.ypteste;
end
ncal = length(am_treina);
nteste = length(am_teste);
%% Gr�fico do previsto vs. observado
if op_graf(1) == 1
    figure
    plot(sort([y_treina;y_teste]),sort([y_treina;y_teste]),'-k')
    hold on
    plot(y_treina,yp_treina,'bo')
    if isempty(y_teste)
        title('Valida��o Cruzada')
        legend('Modelo','Valida��o cruzada','Location','best')
    else
        plot(y_teste,yp_teste,'r+')
        legend('Modelo','Calibra��o','Previs�o','Location','best')
    end
    axis('padded')
    xlabel('Observado')
    ylabel('Previsto')
    hold off
end
%% Gr�fico do res�duo
if op_graf(2) == 1
    figure
    res1 = y_treina - yp_treina;
    plot(y_treina,res1,'bo')
    hold on
    if isempty(y_teste)
        title('Valida��o Cruzada')
        res = res1;
    else
        res2 = y_teste - yp_teste;
        plot(y_teste,res2,'r+')
        legend('Calibra��o','Previs�o','Location','best')
        res = zeros(ncal+nteste,1);
        res(am_treina) = res1;
        res(am_teste) = res2;
    end
    xlabel('Observado')
    ylabel('Res�duo puro')
    grid on
    hold off
    graf_out.residuos = res;
end
%% Res�duos padronizados
if op_graf(3) == 1
    if isempty(y_teste)
        res = y_treina - yp_treina;
    else
        res = [y_treina - yp_treina;y_teste - yp_teste];
    end
    desvio = sqrt(res'*res/size(res,1));
    std_error = res/desvio;
    outliers = find(abs(std_error) > sigma_out);
    figure
    plot(std_error,'bo')
    xlim([0 ncal+nteste+1])
    ylabel('Res�duos Padronizados')
    hold on
    plot(outliers,std_error(outliers),'r.')
    yl = ylim;
    if yl(1) > -3.5
        yl(1) = - 3.5;
    end
    if yl(2) < 3.5
        yl(2) = 3.5;
    end
    ylim([yl(1) yl(2)])
    H = line(xlim,[0 0]);
    set(H,'Color',[0 0 0])
    H = line(xlim,[2 2]);
    set(H,'Color',[0 0 0],'LineStyle','--')
    H = line(xlim,[-2 -2]);
    set(H,'Color',[0 0 0],'LineStyle','--')
    if isempty(y_teste)
        xlabel('Amostra (Valida��o Cruzada)')
    else
        H = line([ncal+0.5 ncal+0.5],ylim);
        set(H,'Color',[0 0 0],'LineStyle','--')
        xlabel('Amostra (Calibra��o | Previs�o)')
    end
    hold off
    % Corre��o da numera��o dos outliers
    if ~isempty(y_teste)
        nout = length(outliers);
        for ii = 1:nout
            if outliers(ii) > ncal
                temp = am_teste(outliers(ii) - ncal);
                outliers(ii) = temp;
            else
                temp = am_treina(outliers(ii));
                outliers(ii) = temp;
            end
        end
    end
    % Corre��o da ordem dos res�duos
    if ~isempty(y_teste)
        std_error_ord = zeros(ncal+nteste,1);
        std_error_ord(am_treina) = std_error(1:ncal);
        std_error_ord(am_teste) = std_error(ncal+1:end);
    else
        std_error_ord = std_error;
    end
    graf_out.res_pad = std_error_ord;
    graf_out.outliers = outliers;
end
%% Elipse de confian�a
if op_graf(4) == 1
    if isempty(y_teste)
        str = ['Elipse de Confian�a - Calibra��o - ' num2str(100*(1-alfa)) '%'];
        graf_out = app_elp_conf(y_treina,yp_treina,alfa,str);
    else
        str = ['Elipse de Confian�a - Previs�o - ' num2str(100*(1-alfa)) '%'];
        graf_out = app_elp_conf(y_teste,yp_teste,alfa,str);
    end
end
%% APARP
if op_graf(5) == 1
    A = model.VLs;
    T = model.xs; 
    y = y_treina;
    Taum = [ones(size(T,1),1),T(:,1:A),T(:,1).^2];
    Vaum = pinv(Taum)*y;
    eAPARP = y - Taum*Vaum;
    yAPARP = eAPARP + Vaum(2)*T(:,1) + Vaum(end)*Taum(:,end);
    slope = pinv(T(:,1) - mean(T(:,1)))*(yAPARP - mean(yAPARP));
    intercept = mean(yAPARP) - slope*mean(T(:,1));
    rAPARP = intercept + slope*T(:,1) - yAPARP;
    [sT1,index] = sort(T(:,1));
    % Gr�ficos
    figure
    subplot(1,2,1)
    plot(T(:,1),yAPARP,'bo')
    xlabel('Scores LV1')
    ylabel('yAPARP')
    axis('padded')
    subplot(1,2,2)
    plot(T(:,1),rAPARP,'bo')
    xlabel('Scores LV1')
    ylabel('rAPARP')
    axis('tight')
    xg = xlim;
    yg = [0 0];
    line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5) % Eixo horizontal no valor 0
    % Teste de Durbin-Watson
    [pdw,dw] = dwtest(rAPARP(index),[ones(size(sT1)),sT1]);
    % Sa�da
    graf_out.APARP.yAPARP = yAPARP;
    graf_out.APARP.rAPARP = rAPARP;
    graf_out.APARP.T1 = T(:,1);
    graf_out.APARP.DW = dw;
    graf_out.APARP.p_DW = pdw;
end
%% VIP
if op_graf(6) == 1
    VLs = model.VLs;
    W = model.stats.W;
    T = model.xs;
    Py = model.yl;
    Px = model.xl;
    W0 = bsxfun(@rdivide,W,sqrt(sum(W.^2,1))); % Pesos normalizados do PLS
    sumSq = sum(T.^2,1).*sum(Py.^2,1); % soma de quadrados de T e P
    VIP = sqrt(size(Px,1)*sum(bsxfun(@times,sumSq,W0.^2),2)./sum(sumSq,2)); % VIP
    VIPcum = sqrt(size(Px,1)*sum(bsxfun(@times,sumSq,W0.^2),2)./cumsum(sumSq,2)); % VIP acumulado
    % Gr�fico
    figure
    plot(VIP,'LineWidth',1.5)
    xlabel('Vari�veis')
    ylabel(['VIP Scores: ' num2str(VLs) ' vari�veis latentes'])
    axis('tight')
    xg = xlim;
    yg = [1 1];
    line(xg,yg,'LineStyle','--','Color','k','LineWidth',0.5) % Eixo horizontal no valor 1
    % Sa�da
    graf_out.VIP.Scores = VIP; % modelo completo
    graf_out.VIP.CumScores = VIPcum; % para cada modelo de 1 at� todas as LVs
end
%% SR
if op_graf(7) == 1
    VLs = model.VLs;
    alfa = 0.01; % n�vel de signific�ncia
    Xres = model.stats.Xresiduals; % Res�duos de X
    T = model.xs;
    P = model.xl;
    Xhat = T*P';
    SQreg = sum(Xhat.^2);	% soma de quadrados da regress�o
    SQres = sum(Xres.^2);	% soma de quadrados dos res�duos
    SR = SQreg./SQres; % raz�o de seletividade ou Fcalc
    Fcrit = finv(1-alfa,ncal-2,ncal-3);
    % Gr�fico
    figure
    plot(SR,'LineWidth',1.5)
    xlabel('Vari�veis')
    ylabel(['SR: ' num2str(VLs) ' vari�veis latentes'])
    title(['-- Fcrit para alfa = ' num2str(alfa)])
    xg = xlim;
    yg = [Fcrit Fcrit];
    line(xg,yg,'LineStyle','--','Color','k','LineWidth',2) % Eixo horizontal no valor Fcrit
    % Sa�da
    graf_out.SR.SR = SR;
    graf_out.SR.Fcrit = Fcrit;
end
%% Coeficientes
if op_graf(8) == 1
    figure
    b = model.beta(2:end);
    nb = length(b);
    plot(1:nb,b,'-b','LineWidth',1.5)
    grid on
    xlabel('Vari�veis')
    ylabel('Valor do coeficiente')
    axis('tight')
end