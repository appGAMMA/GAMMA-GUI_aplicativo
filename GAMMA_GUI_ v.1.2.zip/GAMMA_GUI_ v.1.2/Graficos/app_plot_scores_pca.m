%% Faz o gr�fico de scores da PCA - app
%% Vers�o: 10/07/2020
function app_plot_scores_pca(res_pca,eixo)
%% Dados
if eixo(3) ~= 0
    op = 3;
    d1 = eixo(1);
    d2 = eixo(2);
    d3 = eixo(3);
elseif eixo(2) ~= 0
    op = 2;
    d1 = eixo(1);
    d2 = eixo(2);
else
    op = 1;
    d1 = eixo(1);
end
pcs = res_pca.pcs;
score = res_pca.T;
ams = size(score,1);
samples = res_pca.amostras;
explained = res_pca.explained;
%% Gr�ficos
switch op
    case 1 % 1D
        if d1 > pcs
            msgbox('PC inexistente!','Gr�fico de Score','warn');
            return
        end
        figure
        stem(score(:,d1),'filled')
        xlim([0 ams+1])
        text(1:ams,score(:,d1)+0.075*score(:,d1),samples)
        xlabel('Amostras')
        str = ['PC' num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        ylabel(str)
    case 2 % 2D
        if d1 > pcs || d2 > pcs
            msgbox('PC inexistente!','Plotar scores','warn');
            return
        end
        figure
        plot(score(:,d1),score(:,d2),'bo')
        grid on
        axis equal
        emax = 1.1*(max([xlim ylim]));
        emin = 1.1*(min([xlim ylim]));
        xlim([emin emax])
        ylim([emin emax])
        str = ['PC' num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        xlabel(str)
        str = ['PC' num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
        ylabel(str)
        str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2),'%3.2f'),'%'];
        title(str)
        % Nome nas amostras
        text(score(:,d1),score(:,d2),samples)
        %text(score(:,d1)+0.001,score(:,d2)+0.001,samples,'FontSize',14)
        % Elipse de 95% de confian�a centrada na origem
        %     r1 = sqrt(((ams+1)*2*latent(d1)/(ams*(ams-2)))*finv(0.95,2,ams-2)); % Raio na PC1 
        %     r2 = sqrt(((ams+1)*2*latent(d2)/(ams*(ams-2)))*finv(0.95,2,ams-2)); % Raio na PC2
        %     t = -pi:0.01:pi;
        %     x = r1*cos(t);
        %     y = r2*sin(t);
        %     plot(x,y,'r--')
        % Eixo horizontal
        xg = xlim;
        yg = [0 0];
        line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5)
        % Eixo vertical
        xg = [0 0];
        yg = ylim;
        line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5)
    case 3 % 3D
        if d1 > pcs || d2 > pcs || d3 > pcs
            msgbox('PC inexistente!','Plotar scores','warn');
            return
        end
        figure
        plot3(score(:,d1),score(:,d2),score(:,d3),'bo')
        grid on
        axis equal
        emax = 1.1*(max([xlim ylim zlim]));
        emin = 1.1*(min([xlim ylim zlim]));
        xlim([emin emax])
        ylim([emin emax])
        zlim([emin emax])
        str = ['PC' num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        xlabel(str)
        str = ['PC' num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
        ylabel(str)
        str = ['PC' num2str(d3) ' (' num2str(explained(d3),'%3.2f') '%)'];
        zlabel(str)
        str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2)+explained(d3),'%3.2f'),'%'];
        title(str)
        % Nome nas amostras
        text(score(:,d1),score(:,d2),score(:,d3),samples)
end
