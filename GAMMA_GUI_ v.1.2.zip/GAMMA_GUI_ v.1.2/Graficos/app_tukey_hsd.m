%% Gráfico interativo para o Tukey HSD - APP
% Versão: 12/08/2021
function app_tukey_hsd(estrutura)
pos = [300 200 250 150];
fig = uifigure('Name','Tukey HSD','Position',pos);
% Texto explicativo
texto = "Selecione uma variável para o gráfico";
wraptexto = "{" + replace(texto," ","} {") + "} ";
uilabel(fig,'Position',[10 pos(4)-55 pos(3)--10 50],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Drop-down
vrs = estrutura.Dados.Properties.VariableNames;
vrs(1) = []; % exclui a primeira linha que corresponde aos grupos
dd = uidropdown(fig,'Position',[20 pos(4)-75 150 22],'Items',vrs,'ItemsData',1:length(vrs));
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 25 100 30],'Text','Gerar Gráfico','ButtonPushedFcn', @(btn,event) gerargrafico(btn,dd,estrutura));
end
%% Leitura da variável escolhida e geração do gráfico
function gerargrafico(~,dd,estrutura)
nvr = dd.Value;
texto = dd.Items(nvr);
S = estrutura.Resultados(nvr).Stats;
alfa = estrutura.Alfa;
figure
[~,~,h] = multcompare(S,'Alpha',alfa); % Tukey HSD
h.Name = string(texto); 
end
