%% Gráfico da validação cruzada - PLS
% Versão: 26/03/2023
function app_plot_pls_cv(CV)
pctvar = CV.var_acum;
% Gráficos para RMSECV e r2
figure
subplot(1,2,1)
plot(CV.NVLS,cumsum(100*pctvar(1,:)),'-bo','LineWidth',2)
hold on
plot(CV.NVLS,cumsum(100*pctvar(2,:)),'-ro','LineWidth',2)
axis tight
%set(gca,'FontSize',10,'FontWeight','bold')
grid on
xlabel('Variáveis latentes')
ylabel('Variância acumulada (%)')
legend('X','Y','Location','best')
title(CV.metodo);
subplot(1,2,2)
yyaxis left
plot(CV.NVLS,CV.RMSECV,'-bo','linewidth',2)
axis("tight")
ylabel('RMSECV')
xlabel('Variáveis latentes')
yyaxis right
plot(CV.NVLS,CV.r2_cv,'-ro','LineWidth',2)
ylabel('r^{2}')
legend('RMSECV','r^{2}','Location','best')
grid on
title(CV.metodo)