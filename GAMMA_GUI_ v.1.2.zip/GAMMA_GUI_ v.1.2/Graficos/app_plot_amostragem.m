%% Gráfico de amostragem
% Versão: 26/03/2023
function app_plot_amostragem(model)
X = model.amostragem.x;
switch model.amostragem.tipo
    case 'Kennard-Stone'
        cal = model.amostragem.cal;
        val = model.amostragem.val;
    case 'SPXY'
        cal = model.amostragem.Cal;
        val = model.amostragem.Pred;
end
figure
plot(X(val,1),X(val,2),'ko')
hold on
plot(X(cal,1),X(cal,2),'kx')
axis('padded')
legend('Previsão','Calibração','Location','Best')
xlabel('PC 1')
ylabel('PC 2')
title(['Amostragem ' model.amostragem.tipo])
hold off