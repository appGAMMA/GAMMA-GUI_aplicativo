function app_plot_pareto_comdim(res)
%% Gr�fico de pareto para a vari�ncia explicada
%% Vers�o: 18/07/2020
%% Dados
explained = res.explained;
%% Gr�fico
figure
pareto(explained(1,:))
xlabel('Dimens�o Comum')
ylabel('Vari�ncia Explicada (%)')