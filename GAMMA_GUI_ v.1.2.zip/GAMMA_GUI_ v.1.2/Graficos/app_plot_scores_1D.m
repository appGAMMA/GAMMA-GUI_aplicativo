%% Faz o gráfico 1D dos scores
% Versão: 18/05/2023
function app_plot_scores_1D(model)
%% Dados
pcs = length(model.latent);
%% Criação da janela gráfica
texto = 'Gráfico de Scores 1D';
pos = [300 300 330 150];
fig = uifigure('Name',texto,'Position',pos);
uilabel(fig,'Text','PC','Position',[15 pos(4)-30 50 20]);
spn1 = uispinner(fig,'Limits',[1  pcs],'Value',1,'Position',[70 pos(4)-30 50 20]);
uilabel(fig,'Text','Tipo','Position',[135 pos(4)-30 50 20]);
dd1 = uidropdown(fig,'Items',{'Haste','Barra','Pontos'},'Value','Haste','Position',[170 pos(4)-30 140 20]);
uilabel(fig,'Text','Identificação das amostras','Position',[15 pos(4)-60 200 20]);
dd2 = uidropdown(fig,'Items',{'Nenhuma','Numeração','Nome'},'Value','Nenhuma','Position',[170 pos(4)-60 140 20]);
cbx1 = uicheckbox(fig,'Position',[15 pos(4)-90 150 20],'Text','Limiar de confiança','Enable','on');
uilabel(fig,'Text','Probabilidade','Position',[160 pos(4)-90 100 20]);
spn2 = uispinner(fig,'Limits',[1 99],'Value',95,'Position',[260 pos(4)-90 50 20]);
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Plotar','ButtonPushedFcn', @(btn,event) plot_1D(btn,fig,spn1,spn2,dd1,dd2,cbx1,model));
end
%% Gráfico de scores 1D
function plot_1D(~,~,spn1,spn2,dd1,dd2,cbx1,model)
pc1 = spn1.Value;
prob = spn2.Value;
tipo = dd1.Value;
ident = dd2.Value;
op = cbx1.Value;
Tx = model.T(:,pc1);
varx = model.explained(pc1,1);
nams = size(Tx,1);
figure
switch tipo
    case 'Haste'
        stem(Tx,'filled')
    case 'Barra'
        bar(Tx)
    case 'Pontos'
        plot(1:nams,Tx,'bo')
end
switch ident
    case 'Numeração'
        texto = cell(nams,1);
        for ii = 1:nams
            texto{ii} = num2str(ii);
        end
        hold on
        text(1:nams,Tx,texto)
    case 'Nome'
        texto = model.amostras;
        hold on
        text(1:nams,Tx,texto)
end
xlim([0 nams+1])
grid on
xlabel('Amostra')
ylabel(['PC' num2str(pc1) ' (' num2str(varx,'%.2f') '%)'])
% Limiar de confiança
if op(1) == 1
    latent = model.latent;
    r1 = sqrt(((nams+1)*latent(pc1)/(nams*(nams-1)))*finv(prob/100,1,nams-1)); % Raio na PC1 
    hold on
    line([0 nams+1],[r1 r1],'Color','r','LineStyle','--','LineWidth',1)
    line([0 nams+1],[-r1 -r1],'Color','r','LineStyle','--','LineWidth',1)
    subtitle(['Limiar com ' num2str(prob) '% de confiança'])
end
end
