%% Faz o gr�fico de correla��es: PCA; ComDim; Path-ComDim
%% Vers�o: 29/01/2019
function plot_correlation(tipo,corr_tab)
% Defini��o das propriedades para cada tipo de m�todo
switch tipo
    case 'PCA'
        eixo = 'PC';
        etab = 0;
    case 'Path-ComDim'
        eixo = 'CD';
        etab = 1;
    case 'ComDim'
        eixo = 'CD';
        etab = 1;
end
op = 1; % Para abrir o loop
while op == 1
    if etab == 1
        fprintf('\n')
        te = input('Tabela escolhida: ');
        vname = corr_tab{te}.r.Properties.RowNames;
        rc95 = corr_tab{te}.rc_95;
        rc99 = corr_tab{te}.rc_99;
        R = table2array(corr_tab{te}.r);
        tabname = corr_tab{te}.tabela;
    end
    vrs = size(R,1); % quantidade de vari�veis
    fprintf('\n')
    fprintf('Tipo de gr�fico: \n')
    fprintf('\t (0) discreto (poucas vari�veis) \n')
    fprintf('\t (1) linha (espectros) \n')
    fprintf('\t (2) dispers�o 2D (poucas vari�veis) \n')
    fprintf('\t (3) barras verticais (poucas vari�veis) \n')
    tipo = input('Escolha uma op��o: ');
    fprintf('\n')
    % Intervalo de confian�a
    itv = input('Apresentar o intervalo de confian�a? (0) 95% (1) 99% ');
    fprintf('\n')
    if itv == 0
        rc = rc95;
        leg_texto = 'IC 95%';
    else
        rc = rc99;
        leg_texto = 'IC 99%';
    end
    % Op��es espec�ficas de cada tipo de gr�fico
    if tipo == 2
        cce = 2;
    else
        texto = ['Quantidade de ' eixo 's plotadas: '];
        cce = input(texto);
    end
    cc_plot = zeros(cce,1);
    cc_leg = cell(cce+1,1);
    y_plot = zeros(vrs,cce);
    texto = ['Indique as ' eixo 's a serem utilizadas'];
    disp(texto)
    for ii = 1:cce
        texto = ['Dimens�o ' num2str(ii) ': '];
        cc_plot(ii) = input(texto);
        cc_leg{ii} = [eixo num2str(cc_plot(ii))];
        y_plot(:,ii) = R(:,cc_plot(ii));
    end
    switch tipo
        case 0 % discreto
            figure
            stem(y_plot,'filled')
            ylabel('Correla��o')
            if etab == 1
                title(tabname)
            end
            % Muda os nomes das barras (TickLabel)
            ax = gca;
            xticks = vname;
            set(ax,'XTickLabel',xticks)
            set(ax,'XTick',1:vrs)
            set(ax,'XTickLabelRotation',90)
            xlim([0 vrs+1])
            % Intervalo de confian�a
            xg = xlim;
            yg = [rc rc];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            yg = [-rc -rc];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            cc_leg{cce+1} = leg_texto;
            legend(cc_leg,'Location','Best')
        case 1 % espectros (linha)
            x_plot = zeros(1,vrs);
            for ii = 1:vrs
                x_plot(ii) = str2double(vname{ii});
            end
            figure
            hold on
            for ii = 1:cce
                plot(x_plot,y_plot(:,ii))
            end
            hold off
            xlim([min(x_plot) max(x_plot)])
            if etab == 1
                title(tabname)
            end
            % Intervalo de confian�a
            xg = xlim;
            yg = [rc rc];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            yg = [-rc -rc];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            cc_leg{cce+1} = leg_texto;
            legend(cc_leg,'Location','Best')
            % Eixo horizontal
            xg = xlim;
            yg = [0 0];
            line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5) 
            xlim(xg)
            ylabel('Correla��o')
            xlabel('Vari�veis')
        case 2 % dispers�o 2D
            figure
            % Gr�fico
            plot(y_plot(:,1),y_plot(:,2),'bo')
            % Intervalo de confian�a
            viscircles([0 0],rc,'LineStyle','--');
            text(y_plot(:,1),y_plot(:,2),vname)
            for ii = 1:vrs
                line([0 y_plot(ii,1)],[0 y_plot(ii,2)],'Color',[0 0 1])
            end
            xlim([-1 1])
            ylim([-1 1])
            axis equal
            str = [eixo,num2str(cc_plot(1))];
            xlabel(str)
            str = [eixo,num2str(cc_plot(2))];
            ylabel(str)
            if etab == 1
                title([tabname ' - ' leg_texto ' (--)'])
            end
        case 3 % barras verticais
            x_plot = 1:vrs;
            figure
            bar(x_plot,y_plot)
            ylabel('Correla��es')
            % Muda os nomes das barras (TickLabel)
            ax = gca;
            xticks = vname;
            set(ax,'XTickLabel',xticks)
            set(ax,'XTick',1:vrs)
            set(ax,'XTickLabelRotation',90)
            xlim([0 vrs+1])
            % Intervalo de confian�a
            xg = xlim;
            yg = [rc rc];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            yg = [-rc -rc];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            cc_leg{cce+1} = leg_texto;
            legend(cc_leg,'Location','Best')
            if etab == 1
                title(tabname)
            end
    end
    fprintf('\n')
    op = input('Deseja fazer outro gr�fico de correla��o? (0) N�o (1) Sim ');
end