%% Faz o gr�fico de loadings: PCA; ComDim; Path-ComDim
%% Vers�o: 17/10/2019
function plot_loading(tipo,L,varname,T,samples,explained,tabname)
% Defini��o das propriedades para cada tipo de m�todo
samples = cellstr(samples);
switch tipo
    case 'PCA'
        eixo = 'PC';
        etab = 0;
        vname = varname;
    case 'Path-ComDim'
        eixo = 'CD';
        etab = 1;
        loading = L;
        score = T;
        variaveis = varname;
    case 'ComDim'
        eixo = 'CD';
        etab = 1;
        loading = L;
        score = T;
        variaveis = varname;
end
op = 1; % Para abrir o loop
while op == 1
    if etab == 1
        fprintf('\n')
        te = input('Tabela escolhida: ');
        L = loading{te};
        T = score{te};
        vname = variaveis{te};
    end
    vrs = size(L,1); % quantidade de vari�veis
    ams = size(T,1); % quantidade de amostras
    fprintf('\n')
    fprintf('Tipo de gr�fico: \n')
    fprintf('\t (0) discreto (poucas vari�veis) \n')
    fprintf('\t (1) linha (espectros) \n')
    fprintf('\t (2) biplot (poucas vari�veis) \n')
    tipo = input('Escolha uma op��o: ');
    fprintf('\n')
    % Op��es espec�ficas de cada tipo de gr�fico
    if tipo == 2
        cce = 2;
        b_plot = zeros(ams,cce);
    else
        itv = input('Apresentar o intervalo de � 2 SD? (0) N�o (1) Sim ');
        if itv == 1
            cce = 1;
        else
            fprintf('\n')
            texto = ['Quantidade de ' eixo 's plotadas: '];
            cce = input(texto);
        end
    end
    cc_plot = zeros(cce,1);
    cc_leg = cell(cce,1);
    y_plot = zeros(vrs,cce);
    texto = ['Indique as ' eixo 's a serem utilizadas'];
    disp(texto)
    for ii = 1:cce
        texto = ['Dimens�o ' num2str(ii) ': '];
        cc_plot(ii) = input(texto);
        cc_leg{ii} = [eixo num2str(cc_plot(ii))];
        y_plot(:,ii) = L(:,cc_plot(ii));
        if tipo == 2
            b_plot(:,ii) = T(:,cc_plot(ii));
        end
    end
    switch tipo
        case 0 % discreto
            figure
            stem(y_plot,'filled')
            ylabel('Loading')
            if etab == 1
                title(tabname{te})
            end
            % Muda os nomes das barras (TickLabel)
            ax = gca;
            xticks = vname;
            set(ax,'XTickLabel',xticks)
            set(ax,'XTick',1:vrs)
            set(ax,'XTickLabelRotation',90)
            xlim([0 vrs+1])
            % Intervalo � 2 SD
            if itv == 1
                sd = std(y_plot);
                xg = xlim;
                yg = [2*sd 2*sd];
                line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
                yg = [-2*sd -2*sd];
                line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
                cc_leg{end+1} = '� 2 SD';
            end
            legend(cc_leg,'Location','Best')
        case 1 % espectros (linha)
            if iscell(vname)
                temp = zeros(1,vrs);
                for ii = 1:vrs
                    temp(ii) = str2double(vname{ii}(2:end));
                end
                vname = temp;
            end
            figure
            hold on
            for ii = 1:cce
                plot(vname,y_plot(:,ii))
            end
            hold off
            xlim([min(vname) max(vname)])
            if etab == 1
                title(tabname{te})
            end
            % Intervalo � 2 SD
            if itv == 1
                sd = std(y_plot);
                xg = xlim;
                yg = [sd sd];
                line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
                yg = [-sd -sd];
                line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
                cc_leg{end+1} = '� 2 SD';
            end
            %legend(cc_leg,'Location','Best')
            % Eixo horizontal
            xg = xlim;
            yg = [0 0];
            line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5) 
            xlim(xg)
            ylabel('Loading')
            xlabel('Vari�veis')
            legend(cc_leg,'Location','Best')
        case 2 % biplot (escores do espa�o privado)
            figure
            if isnumeric(vname)
                temp = cell(length(vname),1);
                for ii = 1:length(vname)
                    temp{ii} = num2str(vname(ii));
                end
            else
            temp = cellstr(vname);
            end
            h = biplot(y_plot,'scores',b_plot,'varlabels',temp,'obslabels',samples);
            axis equal
            emax = 1.1*(max([xlim ylim]));
            emin = 1.1*(min([xlim ylim]));
            xlim([emin emax])
            ylim([emin emax])
            if etab == 1
                str = [eixo,num2str(cc_plot(1))];
                xlabel(str)
                str = [eixo,num2str(cc_plot(2))];
                ylabel(str)
                title(tabname{te})
            else
                str = [eixo,num2str(cc_plot(1)),' (',num2str(explained(cc_plot(1)),'%3.2f'),'%)'];
                xlabel(str)
                str = [eixo,num2str(cc_plot(2)),' (',num2str(explained(cc_plot(2)),'%3.2f'),'%)'];
                ylabel(str)
                str = ['Vari�ncia Total: ',num2str(explained(cc_plot(1))+explained(cc_plot(2)),'%3.2f'),'%'];
                title(str)
            end
            % Coloca o nome dos produtos no biplot
            ini = size(y_plot,1)*3;
            for ii = 1:size(b_plot,1)
                prop = get(h(ii+ini));
                px = prop.XData(1);
                py = prop.YData(1);
                text(px+0.005,py+0.010,samples{ii})
            end
    end
    fprintf('\n')
    op = input('Deseja fazer outro gr�fico dos loadings? (0) N�o (1) Sim ');
end