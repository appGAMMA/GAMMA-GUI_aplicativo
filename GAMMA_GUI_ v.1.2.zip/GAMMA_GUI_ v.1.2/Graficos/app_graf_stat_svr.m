%% Gráfico com as estatísticas resumidas do modelo PLS
% Versão: 30/04/2023
function app_graf_stat_svr(model)
%% Dados
%lv = model.VLs;
% Calibração
rmse = model.FOMcal.RMSE;
r2 = model.FOMcal.r2;
nome{1} = 'Calibração';
cont = 1;
% Validação cruzada
try
    rmse = [rmse;model.CV.FOMcv.RMSE];
    r2 = [r2;model.CV.FOMcv.r2];
    cont = cont + 1;
    nome{cont} = 'Validação';
catch
    msgbox('A validação cruzada não foi realizada!','SVM','warn');
end
% Previsão
try
    rmse = [rmse;model.FOMprev.RMSE];
    r2 = [r2;model.FOMprev.r2];
    cont = cont + 1;
    nome{cont} = 'Previsão';
catch
    msgbox('Grupo de previsão inexistente!','SVM','warn');
end
%% Gráficos de barras
figure
subplot(1,2,1)
bar(rmse)
ax= gca;
set(ax,'XTick',1:length(nome),'XTickLabel',nome)
ylabel('RMSE')
ax.YGrid = 'on'; 
gmin = min(rmse,[],'all')*0.9;
gmax = max(rmse,[],'all');
ylim([gmin gmax+0.01*gmax])
title([model.tipo ' - ' model.kernel])
subplot(1,2,2)
bar(r2,'red')
ax= gca;
set(ax,'XTick',1:length(nome),'XTickLabel',nome)
ylabel('r^{2}')
ax.YGrid = 'on'; 
gmin = min(r2,[],'all')*0.9;
gmax = max(r2,[],'all');
ylim([gmin gmax+0.01*gmax])
title([model.tipo ' - ' model.kernel])