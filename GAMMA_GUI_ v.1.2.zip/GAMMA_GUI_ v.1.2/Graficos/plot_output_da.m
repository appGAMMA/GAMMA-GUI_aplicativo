function plot_output_da(y,yp,gn,thrs,ntreina,tipo)
%% Plota as sa�das do classificador PLSDA
%% Vers�o: 09/07/2020
[ams,nc] = size(y); % Quantidade de amostras e classes
xg = 1:ams;
for ii = 1:nc
    figure
    % Amostras da classe
    idx = y(:,ii) == 1;
    plot(xg(idx),yp(idx,ii),'bo');
    hold on
    % Amostras que n�o s�o da classe
    plot(xg(~idx),yp(~idx,ii),'rx');
    % Legenda
    str{1} = gn{ii};
    str{2} = 'Outras amostras';
    str{3} = 'Limiar de Classifica��o';
    xlabel('Amostra')
    ylabel(['Resposta do ' tipo ' para a classe ' gn{ii}])
    exg = xlim;
    yg = [thrs(ii) thrs(ii)];
    line(exg,yg,'LineStyle',':','Color','k') % Linha horizontal
    if ntreina ~= 0
        exg = [ntreina+0.5 ntreina+0.5];
        yg = [min([0 min(yp(:,ii))])-0.1 max([1 max(yp(:,ii))])+0.1];
        line(exg,yg,'LineStyle',':','Color','k') % Linha vertical
        ylim(yg)
        title('Linha vertical = (calibra��o | previs�o)')
    %else
    %    title('Linha horizontal = limiar - Calibra��o')
    end
    legend(str,'Location','Best') 
    hold off
end