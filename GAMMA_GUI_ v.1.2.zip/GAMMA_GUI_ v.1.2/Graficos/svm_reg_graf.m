function graf_out = svm_reg_graf(svr,amcal,y_treina,yp_treina,y_teste,yp_teste)
%% Faz gr�ficos para avaliar a performance de modelos de regress�o svm
%% Vers�o: 13/08/2017
alfa = 0.05;    % probabilidade para a elipse de confian�a
sigma_out = 2;  % valor de desvio para definir outliers
%% Elipse de confian�a
if isempty(y_teste)
    str = ['Elipse de Confian�a - Valida��o Cruzada - ' num2str(100*(1-alfa)) '%'];
    elp_conf(y_treina,yp_treina,alfa,str);
else
    str = ['Elipse de Confian�a - Previs�o - ' num2str(100*(1-alfa)) '%'];
    elp_conf(y_teste,yp_teste,alfa,str);
end
%% Gr�fico do previsto vs. observado
figure
plot(y_treina,yp_treina,'bo')
hold on
if isempty(y_teste)
    title('Valida��o Cruzada')
else
    plot(y_teste,yp_teste,'r+')
    legend('Calibra��o','Previs�o','Location','best')
end
plot(sort([y_treina;y_teste]),sort([y_treina;y_teste]),'-k')
xlabel('Observado')
ylabel('Previsto')
hold off
%% Gr�fico do res�duo
figure
res = y_treina - yp_treina;
plot(y_treina,res,'bo')
hold on
plot(y_treina(svr.sv_indices),res(svr.sv_indices),'.r')
if isempty(y_teste)
    legend('Valida��o Cruzada','Vetores Suporte','Location','best')
else
    res = y_teste - yp_teste;
    plot(y_teste,res,'r+')
    legend('Calibra��o','Vetores Suporte','Previs�o','Location','best')
end
xlabel('Observado')
ylabel('Res�duo puro')
H = line(xlim,[0 0]);
set(H,'Color',[0 0 0])
hold off
%% Res�duos padronizados
if isempty(y_teste)
    res = y_treina - yp_treina;
else
    res = [y_treina - yp_treina;y_teste - yp_teste];
end
desvio = sqrt(res'*res/size(res,1));
std_error = res/desvio;
outliers = find(abs(std_error) > sigma_out);
figure
plot(std_error,'bo')
ylabel('Res�duos Padronizados')
hold on
plot(outliers,std_error(outliers),'r.')
yl = ylim;
if yl(1) > -3.5
    yl(1) = - 3.5;
end
if yl(2) < 3.5
    yl(2) = 3.5;
end
ylim([yl(1) yl(2)])
H = line(xlim,[0 0]);
set(H,'Color',[0 0 0])
H = line(xlim,[2 2]);
set(H,'Color',[0 0 0],'LineStyle','--')
H = line(xlim,[-2 -2]);
set(H,'Color',[0 0 0],'LineStyle','--')
if isempty(y_teste)
    xlabel('Amostra (Valida��o Cruzada)')
else
    H = line([amcal+0.5 amcal+0.5],ylim);
    set(H,'Color',[0 0 0],'LineStyle','--')
    xlabel('Amostra (Calibra��o | Previs�o)')
end
hold off
%% Sa�da de dados
graf_out.residuos = res;
graf_out.std_error = std_error;
graf_out.outliers = outliers;