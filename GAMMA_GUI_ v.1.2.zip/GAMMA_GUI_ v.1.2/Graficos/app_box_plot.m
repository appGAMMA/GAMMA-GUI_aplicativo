%% Box-Plot - APP
% Versão: 10/08/2021
function app_box_plot(estrutura)
pos = [300 200 250 150];
fig = uifigure('Name','Box-Plot','Position',pos);
% Texto explicativo
texto = "Selecione uma variável para o gráfico";
wraptexto = "{" + replace(texto," ","} {") + "} ";
uilabel(fig,'Position',[10 pos(4)-55 pos(3)--10 50],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Drop-down
vrs = estrutura.Dados.Properties.VariableNames;
vrs(1) = []; % exclui a primeira linha que corresponde aos grupos
dd = uidropdown(fig,'Position',[20 pos(4)-75 150 22],'Items',vrs,'ItemsData',1:length(vrs));
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 25 100 30],'Text','Gerar Gráfico','ButtonPushedFcn', @(btn,event) gerargrafico(btn,dd,estrutura));
end
%% Leitura da variável escolhida e geração do gráfico
function gerargrafico(~,dd,estrutura)
nvr = dd.Value;
texto = dd.Items(nvr);
grp = estrutura.Dados{:,1};
x = estrutura.Dados{:,nvr+1}; % tem que pular a primeira coluna
figure
boxplot(x,grp)
ylabel(texto)
end
