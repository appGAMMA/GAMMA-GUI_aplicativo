%% Teste de diagrama ternário usando ternary_plots

load teste_tri

vgen  = {'gridspaceunit', 10,      ... % linhas do grid
         'titlelabels', {'x1','x2','x3'}, ... % nome dos eixos
         'titlerotation', [0,0,0]};

H = ternary_axes(vgen); % cria os eixos do diagrama triangular

[A,B,C] = ternary_arrays(400); % retira as coordenadas 400 pontos de cada lado

yp = predict(mlr_out1.modelo,[A B C]); % faz a previsão usando o modelo de mistura

dataplots(1).obj = ternary_surf([],'l',A,'b',B,yp); % plota os dados no diagrama com colorbar

colormap jet % muda o padrão de cores

H = restack_dataplots(H, dataplots); % coloca o grid sobre o diagrama