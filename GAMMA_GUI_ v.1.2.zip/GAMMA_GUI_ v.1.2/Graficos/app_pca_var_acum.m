%% Gráfico da variância acumulada para cada variável
% Versão: 19/05/2023
function saida = app_pca_var_acum(model)
% Variáveis
X = model.X; % matriz X já normalizada
T = model.T;
P = model.P;
pcs = size(T,2);
if pcs > 6
    pcs = 6;
end
Res = pcares(X,pcs);
[ams,vars] = size(X);
texto = cell(pcs+1,1);
var_name = model.variaveis;
for ii = 1:pcs
    texto{ii} = ['PC' num2str(ii)];
end
texto{pcs+1} = 'Outras PCs';
% Somas de quadrado
SQRes = sum(Res.^2);
SQX   = sum(X.^2);
var_acum = zeros(pcs+2,vars);
var_acum(pcs+2,:) = 100*(1 - SQRes./SQX);
% X representado em cada PC
X_pc = zeros(ams,vars,pcs);
for ii = 1:pcs
    X_pc(:,:,ii) = T(:,ii)*P(:,ii)';
end
% Separação da variância de cada variável
X_var = zeros(ams,vars,pcs);
for ii = 1:vars
    Xtemp = squeeze(X_pc(:,ii,:));
    Xtemp3 = zeros(ams,pcs);
    for jj = 1:pcs
        % All columns but column f
        Xtemp2 = Xtemp(:,[1:jj-1 jj+1:pcs]);
        % Remove from column f what is predicted from the other columns
        Xtemp3(:,jj) = Xtemp(:,jj) - Xtemp2*(pinv(Xtemp2)*Xtemp(:,jj));
    end
    X_var(:,ii,:) = Xtemp3;
end
% Variância acumulada em cada variável
for ii = 1:pcs
    Rpc = X - X_var(:,:,ii);
    SQpc = sum(Rpc.^2);
    var_acum(ii,:) = 100*(1 - (SQpc./SQX));
end
var_acum(pcs+1,:) = var_acum(pcs+2,:) - sum(var_acum(1:pcs,:));
% Gráfico
if ~ischar(var_name) && ~isstring(var_name) && ~iscellstr(var_name)
    var_name = cellstr(num2str(var_name,'%.0f'));
end
figure
teste = max(abs(var_acum(pcs+1,:))) > 1e-2;
if teste
    bar(1:vars,var_acum(1:pcs+1,:)','stacked')
    legend(texto,'Location','eastoutside')
else
    bar(1:vars,var_acum(1:pcs,:)','stacked')
    legend(texto(1:pcs),'Location','eastoutside')
end
ylabel('Variância representada (%)')
ax = gca;
set(ax,'XTick',1:vars,'XTickLabel',var_name)
% Saída na forma de tabela
texto{pcs+2} = 'Variância total';
tab = array2table(var_acum,"RowNames",texto,"VariableNames",var_name);
saida = tab;