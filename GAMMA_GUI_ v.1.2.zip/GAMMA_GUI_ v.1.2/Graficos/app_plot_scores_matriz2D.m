%% Faz o gráfico dos scores em matriz 2D
% Versão: 17/05/2023
function app_plot_scores_matriz2D(model)
%% Dados
pcs = length(model.latent);
%% Criação da janela gráfica
texto = 'Gráfico de Scores Matriz 2D';
pos = [300 300 250 90];
fig = uifigure('Name',texto,'Position',pos);
uilabel(fig,'Text','Quantidade de PCs','Position',[15 pos(4)-30 120 20]);
spn1 = uispinner(fig,'Limits',[2  pcs],'Value',2,'Position',[130 pos(4)-30 50 20]);
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Plotar','ButtonPushedFcn', @(btn,event) plot_matriz2D(btn,fig,spn1,model));
end
%% Gráfico de scores matriz 2D
function plot_matriz2D(~,~,spn1,model)
pcs = spn1.Value;
T = model.T(:,1:pcs);
xnam = cell(pcs,1);
for ii = 1:pcs
    xnam{ii} = ['PC' num2str(ii)];
end
figure
gplotmatrix(T,[],model.amostras,[],[],20,[],'stairs',xnam)
end
