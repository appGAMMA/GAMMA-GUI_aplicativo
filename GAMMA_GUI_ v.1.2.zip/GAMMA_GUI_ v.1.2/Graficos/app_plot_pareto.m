function app_plot_pareto(res_pca)
%% Gr�fico de pareto para a vari�ncia explicada
%% Vers�o: 10/07/2020
%% Dados
explained = res_pca.explained;
%% Gr�fico
figure
pareto(explained(:,1))
xlabel('Componente Principal')
ylabel('Vari�ncia Explicada (%)')