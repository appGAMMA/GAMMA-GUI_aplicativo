%% Gr�fico dos res�duos da PCA
% Vers�o: 19/05/2023
function app_plot_Q(res_pca,saida)
%% Cria��o da janela gr�fica
pcs = size(res_pca.T,2);
texto = 'Gr�fico de Q';
pos = [300 300 200 90];
fig = uifigure('Name',texto,'Position',pos);
uilabel(fig,'Text','Quantidade de PCs','Position',[15 pos(4)-30 120 20]);
spn1 = uispinner(fig,'Limits',[1  pcs],'Value',1,'Position',[130 pos(4)-30 50 20]);
% Criar o bot�o de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Plotar','ButtonPushedFcn', @(btn,event) plot_Q(btn,fig,spn1,res_pca,saida));
end
%% Matriz de res�duos E, par�metro Q e matriz reconstru�da Xnew
function plot_Q(~,~,spn1,res_pca,saida)
pcs = spn1.Value;
x = res_pca.X;
ams = size(x,1);
[E,Xnew] = pcares(x,pcs);
Q = zeros(ams,1);
for ii = 1:size(x,1)
     Q(ii) = E(ii,:)*E(ii,:)';
end
Q = sqrt(Q);
% Gr�fico dos Res�duos
figure
plot(Q,'bo')
xlim([0 ams+1])
xlabel('Amostra')
ylabel('Res�duos - sqrt(Q)')
title(['PCs = ' num2str(pcs)])
% Salvar os dados
res_pca.Residuos.PCs = pcs;
res_pca.Residuos.Res = E;
res_pca.Residuos.Xprev = Xnew;
res_pca.Residuos.Q = Q;
assignin('base',saida,res_pca)
end