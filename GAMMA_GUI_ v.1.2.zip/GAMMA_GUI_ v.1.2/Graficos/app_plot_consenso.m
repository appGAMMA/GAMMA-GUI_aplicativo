%% Faz o gr�fico de scores de consenso - app
%% Vers�o: 18/07/2020
function app_plot_consenso(res,eixo)
%% Dados
if eixo(3) ~= 0
    op = 3;
    d1 = eixo(1);
    d2 = eixo(2);
    d3 = eixo(3);
elseif eixo(2) ~= 0
    op = 2;
    d1 = eixo(1);
    d2 = eixo(2);
else
    op = 1;
    d1 = eixo(1);
end
ncds = res.CDs;
score = res.T;
ams = size(score,1);
samples = res.data(1).i;
explained = res.explained(1,:);
%% Gr�ficos
switch op
    case 1 % 1D
        if d1 > ncds
            msgbox('CD inexistente!','Gr�fico de Consenso','warn');
            return
        end
        figure
        stem(score(:,d1),'filled')
        xlim([0 ams+1])
        text(1:ams,score(:,d1)+0.075*score(:,d1),samples)
        xlabel('Amostras')
        str = ['CD' num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        ylabel(str)
    case 2 % 2D
        if d1 > ncds || d2 > ncds
            msgbox('CD inexistente!','Gr�fico de Consenso','warn');
            return
        end
        figure
        plot(score(:,d1),score(:,d2),'bo')
        grid on
        axis equal
        emax = 1.1*(max([xlim ylim]));
        emin = 1.1*(min([xlim ylim]));
        xlim([emin emax])
        ylim([emin emax])
        str = ['CD' num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        xlabel(str)
        str = ['CD' num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
        ylabel(str)
        str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2),'%3.2f'),'%'];
        title(str)
        % Nome nas amostras
        text(score(:,d1),score(:,d2),samples)
        % Eixo horizontal
        xg = xlim;
        yg = [0 0];
        line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5)
        % Eixo vertical
        xg = [0 0];
        yg = ylim;
        line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5)
    case 3 % 3D
        if d1 > ncds || d2 > ncds || d3 > ncds
            msgbox('CD inexistente!','Gr�fico de Consenso','warn');
            return
        end
        figure
        plot3(score(:,d1),score(:,d2),score(:,d3),'bo')
        grid on
        axis equal
        emax = 1.1*(max([xlim ylim zlim]));
        emin = 1.1*(min([xlim ylim zlim]));
        xlim([emin emax])
        ylim([emin emax])
        zlim([emin emax])
        str = ['CD' num2str(d1) ' (' num2str(explained(d1),'%3.2f') '%)'];
        xlabel(str)
        str = ['CD' num2str(d2) ' (' num2str(explained(d2),'%3.2f') '%)'];
        ylabel(str)
        str = ['CD' num2str(d3) ' (' num2str(explained(d3),'%3.2f') '%)'];
        zlabel(str)
        str = ['Vari�ncia Total: ',num2str(explained(d1)+explained(d2)+explained(d3),'%3.2f'),'%'];
        title(str)
        % Nome nas amostras
        text(score(:,d1),score(:,d2),score(:,d3),samples)
end
