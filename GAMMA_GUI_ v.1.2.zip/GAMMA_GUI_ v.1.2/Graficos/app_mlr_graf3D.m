%% Gráfico de superfície ou contorno para MLR - APP
% Versão: 04/06/2021
% Tipo: 1 - Superfície; 2 - Contorno
function app_mlr_graf3D(modelo,tipo)
%% Criar a tabela com os preditores do modelo
npred = modelo.NumPredictors;
nvar = modelo.NumVariables;
if npred < 2
    msgbox('São necessárias pelo menos duas variáveis para esse tipo de gráfico!','MLR','warn');
    return
end
% Janela gráfica
if tipo == 1
    texto = 'Gráfico 3D';
elseif tipo == 2
    texto = 'Gráfico de contorno';
end
pos = [300 200 300 300];
fig = uifigure('Name',texto,'Position',pos);
% Texto explicativo
texto = "Para mais de duas variáveis, colocar o mesmo valor de mínimo e máximo para as variáveis que não serão variadas no gráfico";
wraptexto = "{" + replace(texto," ","} {") + "} ";
uilabel(fig,'Position',[10 pos(4)-55 pos(3)-10 50],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Tabela de dados
uit = uitable(fig,'Position',[10 50 pos(3)-20 pos(4)-110]);
uit.ColumnName = {'Variável';'Mínimo';'Máximo'}; 
dados = cell(npred,3);
for ii = 1:npred
    dados{ii,1} = modelo.PredictorNames{ii}; % nome das variáveis na primeira coluna
end
idx = 0;
for ii = 1:nvar-1 % ignora a última linha da variável dependente
    if modelo.VariableInfo{ii,3} == 1 % verifica se a variável foi incluída no modelo
        idx = idx + 1;
        faixa = modelo.VariableInfo{ii,2};
        dados{idx,2} = faixa{1}(1); % limite inferior
        dados{idx,3} = faixa{1}(2); % limite superior
    end
end
uit.Data = dados;
uit.ColumnEditable = [false true true]; % habilita a edição nas colunas 2 e 3
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Gerar Gráfico','ButtonPushedFcn', @(btn,event) gerargrafico(btn,uit,modelo,tipo));
end
%% Leitura dos dados após eventual alteração pelo usuário
function gerargrafico(~,uit,modelo,tipo)
    ptos = 30; % quantidade de pontos interpolados em cada eixo
    dados = uit.Data;
    nvar = size(dados,1);
    predname = cell(nvar,1);
    limites = zeros(nvar,2);
    Xnew = ones(ptos*ptos,nvar); % Matriz com as variáveis independentes para interpolar no modelo
    v = cell(nvar,1);
    vargraf = zeros(2,1);
    idx = 0;
    for ii = 1:nvar
        predname{ii} = dados{ii,1};
        limites(ii,1) = dados{ii,2};
        limites(ii,2) = dados{ii,3};
        h = (limites(ii,2) - limites(ii,1))/(ptos - 1);
        v{ii} = limites(ii,1):h:limites(ii,2);
        if isempty(v{ii}) % quando não existir variação
            v{ii} = limites(ii,1);
        else
            idx = idx + 1;
            vargraf(idx) = ii;
        end
    end
    if idx > 2
        msgbox('Não é possível representar mais do que duas variáveis no gráfico!','MLR','warn');
        return
    end
    [X,Y] = meshgrid(v{vargraf(1)},v{vargraf(2)});
    Xnew(:,vargraf(1)) = X(:);
    Xnew(:,vargraf(2)) = Y(:);
    titulo = '';
    for ii = 1:nvar
        if ii ~= vargraf(1) && ii ~= vargraf(2)
           Xnew(:,ii) = Xnew(:,ii)*v{ii};
           titulo = [titulo predname{ii} ' = ' num2str(v{ii}) ' '];
        end
    end
    ypred = predict(modelo,Xnew);
    Z = reshape(ypred,ptos,ptos);
    figure
    colormap jet
    if tipo == 1
        surfc(X,Y,Z,'FaceAlpha',0.75)
        zlabel('y previsto')
        colorbar
    elseif tipo == 2
        contourf(X,Y,Z,'ShowText','on')
    end
    xlabel(predname{vargraf(1)})
    ylabel(predname{vargraf(2)})
    title(titulo)
end