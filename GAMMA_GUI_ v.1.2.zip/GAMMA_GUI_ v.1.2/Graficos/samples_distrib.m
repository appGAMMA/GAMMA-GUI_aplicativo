function samples_distrib(d1,d2,x_label,R,C,xc,wn,pos_n,u_matrix)
%% Distribui��o das amostras sobre o mapa de pesos
%% Vers�o: 09/02/2017
nv = zeros(C,2);
u = zeros(C,1);
cont = 0;
for kk = 1:R
    xa = xc(kk,:)'; % Amostra escolhida
    d = zeros(d1,d2);
    % Localiza��o do neur�nio vencedor
    for ii = 1:d1
        for jj = 1:d2
            xn = zeros(C,1);
            xn(:,1) = wn(ii,jj,:);
            d(ii,jj) = sum((xa-xn).^2).^0.5;
        end
    end
    [y1,i1] = sort(d);
    [~,i2] = sort(y1(1,:));
    % Posi��o do neur�nio vencedor
    cont = cont + 1;
    ind1 = i1(1,i2(1));
    ind2 = i2(1);
    neuro = sub2ind(size(d),ind1,ind2);
    nv(cont,1) = pos_n(neuro,1);
    nv(cont,2) = pos_n(neuro,2);
    if nargin >= 9
        u(cont) = u_matrix(ind1,ind2);
    end
    am(cont) = cellstr(x_label(kk));
end
if nargin < 9
    text(nv(:,1),nv(:,2),am)
else
    text(nv(:,1),nv(:,2),u,am)
end