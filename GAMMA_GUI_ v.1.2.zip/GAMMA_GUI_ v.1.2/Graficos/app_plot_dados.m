function app_plot_dados(y,x,s,op_ams,textos,op_graf,temp)
%% Faz o gr�fico do espectro m�dio das amostras selecionadas - app
%% Vers�o: 08/03/2023
%% Verificar se o nome das amostras est�o em uma c�lula
if ~iscell(s)
    s = cellstr(s);
end
%% Intervalo do eixo X
if size(x,1) > 1
    xmax = max(max(x));
    xmin = min(min(x));
else
    xmax = max(x);
    xmin = min(x);
end
%% Plotar
if op_ams(1) == 1 % Todos os dados
    figure
    plot(x,y,'LineWidth',1.5)
    axis tight
    %xlim([xmin xmax]);
    xlabel(textos{1})
    ylabel(textos{2})
    title(textos{3})
    if op_graf(1) == 1
        set(gca,'XDir','reverse')
    end
    if op_graf(2) == 1
        legend(s)
    end
elseif op_ams(2) == 1 % Sele��o de amostras
    ns = length(temp);
    cont = 0;
    for ii = 1:ns
        if ~isempty(temp{ii})
            cont = cont + 1;
            sel_ams{cont} = temp{ii};
        end
    end
    ns = cont;
    m_data = zeros(ns,size(y,2));
    gn = cell(ns,1);
    for ii = 1:ns
        i_m = strncmpi(sel_ams{ii},s,size(sel_ams{ii},2));
        if sum(i_m) < 1
            msgbox('Amostra n�o foi encontrada','Plotar dados','warn');
            return
        elseif sum(i_m) == 1
            m_data(ii,:) = y(i_m,:);
        else
            m_data(ii,:) = mean(y(i_m,:));
        end
        gn(ii) = cellstr(sel_ams{ii});
    end
    figure
    plot(x,m_data,'LineWidth',1.5)
    axis tight
    %xlim([xmin xmax]);
    xlabel(textos{1})
    ylabel(textos{2})
    title(textos{3})
    if op_graf(1) == 1
        set(gca,'XDir','reverse')
    end
    if op_graf(2) == 1
        legend(gn)
    end
end
