%% Faz o gr�fico de correla��es: ComDim
%% Vers�o: 30/07/2020
function app_plot_correlations(res,te,temp,op_graf,itv)
%% Dados
cce = length(temp);
cont = 0;
for ii = 1:cce
    temp2 = str2double(temp{ii});
    if ~isnan(temp2)
        cont = cont + 1;
        eixo(cont) = temp2;
    end
end
cce = cont;
if cce < 1
    msgbox('CD n�o � v�lida!','Gr�fico de Loadings','warn');
    return
end
cds = res.CDs;
for ii = 1:cce
    if eixo(ii) > cds || eixo(ii) < 1
        msgbox('CD inexistente!','Gr�fico de Loadings','warn');
        return
    end
end
ntabs = length(res.data);
if te > ntabs
    msgbox('Tabela inexistente!','Gr�fico de Loadings','warn');
    return
end
if op_graf(1) == 1
    tipo = 0;
elseif op_graf(2) == 1
    tipo = 1;
elseif op_graf(3) == 1
    if cce < 2
        msgbox('Quantidade insuficiente de CDs!','Gr�fico de Loadings','warn');
        return
    elseif cce > 3
        msgbox('Quantidade m�xima de CDs excedida!','Gr�fico de Loadings','warn');
        return
    end
    tipo = 2;
elseif op_graf(4) == 1
    tipo = 3;
end
vname = res.data(te).v;
rc95 = res.correlation{te}.rc_95;
rc99 = res.correlation{te}.rc_99;
R = res.correlation{te}.r{:,:};
tabname = res.correlation{te}.tabela;
vrs = size(R,1); % quantidade de vari�veis
% Intervalo de confian�a
if itv(1) == 1
    rc = rc95;
    leg_texto = 'IC 95%';
elseif itv(2) == 1
    rc = rc99;
    leg_texto = 'IC 99%';
end
cc_leg = cell(cce+1,1);
y_plot = zeros(vrs,cce);
for ii = 1:cce
    cc_leg{ii} = ['CD' num2str(eixo(ii))];
    y_plot(:,ii) = R(:,eixo(ii));
end
switch tipo
    case 0 % discreto
        figure
        stem(y_plot,'filled')
        ylabel('Correla��o')
        title(tabname)
        % Muda os nomes das barras (TickLabel)
        ax = gca;
        xticks = vname;
        set(ax,'XTickLabel',xticks)
        set(ax,'XTick',1:vrs)
        set(ax,'XTickLabelRotation',90)
        xlim([0 vrs+1])
        % Intervalo de confian�a
        xg = xlim;
        yg = [rc rc];
        line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
        yg = [-rc -rc];
        line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
        cc_leg{cce+1} = leg_texto;
        legend(cc_leg,'Location','Best')
    case 1 % espectros (linha)
        x_plot = zeros(1,vrs);
        if ~iscell(vname)
            x_plot = vname;
        else
            for ii = 1:vrs
                x_plot(ii) = str2double(vname{ii}(2:end));
            end
        end
        figure
        hold on
        for ii = 1:cce
            plot(x_plot,y_plot(:,ii),'LineWidth',1.5)
        end
        hold off
        xlim([min(x_plot) max(x_plot)])
        title(tabname)
        % Intervalo de confian�a
        xg = xlim;
        yg = [rc rc];
        line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
        yg = [-rc -rc];
        line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
        cc_leg{cce+1} = leg_texto;
        % Eixo horizontal
        xg = xlim;
        yg = [0 0];
        line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5) 
        xlim(xg)
        ylabel('Correla��o')
        xlabel('Vari�veis')
        legend(cc_leg,'Location','Best')
    case 2 % dispers�o 2D
        figure
        % Gr�fico
        plot(y_plot(:,1),y_plot(:,2),'bo')
        % Intervalo de confian�a
        viscircles([0 0],rc,'LineStyle','--');
        text(y_plot(:,1),y_plot(:,2),vname)
        for ii = 1:vrs
            line([0 y_plot(ii,1)],[0 y_plot(ii,2)],'Color',[0 0 1])
        end
        xlim([-1 1])
        ylim([-1 1])
        axis equal
        str = ['CD',num2str(eixo(1))];
        xlabel(str)
        str = ['CD',num2str(eixo(2))];
        ylabel(str)
        title([tabname ' - ' leg_texto ' (--)'])
    case 3 % barras verticais
        x_plot = 1:vrs;
        figure
        bar(x_plot,y_plot)
        ylabel('Correla��es')
        % Muda os nomes das barras (TickLabel)
        ax = gca;
        xticks = vname;
        set(ax,'XTickLabel',xticks)
        set(ax,'XTick',1:vrs)
        set(ax,'XTickLabelRotation',90)
        xlim([0 vrs+1])
        % Intervalo de confian�a
        xg = xlim;
        yg = [rc rc];
        line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
        yg = [-rc -rc];
        line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
        cc_leg{cce+1} = leg_texto;
        legend(cc_leg,'Location','Best')
end
