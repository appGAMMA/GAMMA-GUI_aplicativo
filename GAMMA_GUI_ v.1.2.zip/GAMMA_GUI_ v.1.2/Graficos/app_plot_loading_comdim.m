%% Faz o gr�fico de loadings COMDIM - app
%% Vers�o: 19/07/2020
function app_plot_loading_comdim(res,tabela,temp,op_graf)
%% Dados
cce = length(temp);
cont = 0;
for ii = 1:cce
    temp2 = str2double(temp{ii});
    if ~isnan(temp2)
        cont = cont + 1;
        eixo(cont) = temp2;
    end
end
cce = cont;
if cce < 1
    msgbox('CD n�o � v�lida!','Gr�fico de Loadings','warn');
    return
end
cds = res.CDs;
for ii = 1:cce
    if eixo(ii) > cds || eixo(ii) < 1
        msgbox('CD inexistente!','Gr�fico de Loadings','warn');
        return
    end
end
ntabs = length(res.data);
if tabela > ntabs
    msgbox('Tabela inexistente!','Gr�fico de Loadings','warn');
    return
end
L = res.L{tabela};
vrs = size(L,1); % quantidade de vari�veis
T = res.Ti{tabela};
ams = size(T,1); % quantidade de amostras
if op_graf(1) == 1
    tipo = 0;
elseif op_graf(2) == 1
    tipo = 1;
elseif op_graf(3) == 1
    if cce < 2
        msgbox('Quantidade insuficiente de CDs!','Gr�fico de Loadings','warn');
        return
    elseif cce > 3
        msgbox('Quantidade m�xima de CDs excedida!','Gr�fico de Loadings','warn');
        return
    end
    tipo = 2;
    b_plot = zeros(ams,cce);
end
vname = res.data(tabela).v;
samples = res.data(tabela).i;
explained = res.explained(1,:);
tab_nam = res.data(tabela).info;
%% Gr�fico
cc_leg = cell(cce,1);
y_plot = zeros(vrs,cce);
for ii = 1:cce
    cc_leg{ii} = ['CD' num2str(eixo(ii))];
    y_plot(:,ii) = L(:,eixo(ii));
    if tipo == 2
        b_plot(:,ii) = T(:,eixo(ii));
    end
end
switch tipo
    case 0 % discreto
        figure
        stem(y_plot,'filled')
        ylabel('Loading')
        title(tab_nam)
        % Muda os nomes das barras (TickLabel)
        ax = gca;
        xticks = vname;
        set(ax,'XTickLabel',xticks)
        set(ax,'XTick',1:vrs)
        set(ax,'XTickLabelRotation',90)
        xlim([0 vrs+1])
        % Intervalo � 2 SD
        if cce < 2
            sd = std(y_plot);
            xg = xlim;
            yg = [2*sd 2*sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            yg = [-2*sd -2*sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            cc_leg{end+1} = '� 2 SD';
        end
        legend(cc_leg,'Location','Best')
    case 1 % espectros (linha)
        if iscell(vname)
            temp = zeros(1,vrs);
            for ii = 1:vrs
                temp(ii) = str2double(vname{ii}(2:end));
            end
            vname = temp;
        end
        figure
        hold on
        for ii = 1:cce
            plot(vname,y_plot(:,ii),'LineWidth',1.5)
        end
        hold off
        xlim([min(vname) max(vname)])
        % Intervalo � 2 SD
        if cce < 2
            sd = std(y_plot);
            xg = xlim;
            yg = [sd sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            yg = [-sd -sd];
            line(xg,yg,'LineStyle','--','Color','r','LineWidth',0.5)
            cc_leg{end+1} = '� 2 SD';
        end
        %legend(cc_leg,'Location','Best')
        % Eixo horizontal
        xg = xlim;
        yg = [0 0];
        line(xg,yg,'LineStyle','-','Color','k','LineWidth',0.5) 
        xlim(xg)
        ylabel('Loading')
        xlabel('Vari�veis')
        legend(cc_leg,'Location','Best')
        title(tab_nam)
    case 2 % biplot (escores do espa�o privado)
        figure
        if isnumeric(vname)
            temp = cell(length(vname),1);
            for ii = 1:length(vname)
                temp{ii} = num2str(vname(ii));
            end
        else
        temp = cellstr(vname);
        end
        h = biplot(y_plot,'scores',b_plot,'varlabels',temp,'obslabels',samples);
        axis equal
        emax = 1.1*(max([xlim ylim]));
        emin = 1.1*(min([xlim ylim]));
        xlim([emin emax])
        ylim([emin emax])
        str = ['CD',num2str(eixo(1)),' (',num2str(explained(eixo(1)),'%3.2f'),'%)'];
        xlabel(str)
        str = ['CD',num2str(eixo(2)),' (',num2str(explained(eixo(2)),'%3.2f'),'%)'];
        ylabel(str)
        if cce == 3
            str = ['CD',num2str(eixo(3)),' (',num2str(explained(eixo(3)),'%3.2f'),'%)'];
            zlabel(str)
            str = ['Vari�ncia Total: ',num2str(explained(eixo(1))+explained(eixo(2))+explained(eixo(3)),'%3.2f'),'%'];
        else
            str = ['Vari�ncia Total: ',num2str(explained(eixo(1))+explained(eixo(2)),'%3.2f'),'%'];
        end
        title(str)
        % Coloca o nome dos produtos no biplot
        ini = size(y_plot,1)*3;
        for ii = 1:size(b_plot,1)
            prop = get(h(ii+ini));
            px = prop.XData(1);
            py = prop.YData(1);
            if cce == 3
                pz = prop.ZData(1);
                text(px+0.005,py+0.010,pz+0.005,samples{ii})
            else
                text(px+0.005,py+0.010,samples{ii})
            end
        end
end
end