function plot_espec(espectros,w_number,samples,formato)
%% Faz o gr�fico do espectro m�dio das amostras selecionadas
% formato: completo (todas as op��es); simples (s� para visualizar o efeito
% dos pr�-tratamentos)
%% Vers�o: 08/02/2019
[lin,col] = size(espectros);
%% Faixa de aquisi��o vazia
if isempty(w_number)
    w_number = 1:col;
end
%% Nome de amostra vazio
if isempty(samples)
    samples = cell(lin,1);
    for ii = 1:lin
        samples{ii} = ['A' num2str(ii)];
    end
end
%% Verificar se o nome das amostras est�o em uma c�lula
if ~iscell(samples)
    samples = cellstr(samples);
end
%% Intervalo do eixo X
if size(w_number,1) > 1
    xmax = max(max(w_number));
    xmin = min(min(w_number));
else
    xmax = max(w_number);
    xmin = min(w_number);
end
%% Op��es de gr�fico
switch formato
    case 'completo'
        fprintf('\n')
        op = input('Plotar: (0) Todas as amostras (1) Escolher amostras ');
        fprintf('\n')
        tipo = input('Tipo de dados: (0) FTIR (1) Outros ');
    case 'simples'
        op = 0;
        tipo = 1;
end
%% Plotar
if op == 0 % Todos os espectros
    figure
    plot(w_number,espectros,'LineWidth',1.5)
    xlim([xmin xmax]);
    ylabel('Intensidade')
    if tipo == 0
        set(gca,'XDir','reverse')
        xlabel('N�mero de onda (cm^{-1})')
    elseif tipo == 1
        xlabel('Eixo X')
    else
        disp('Op��o inv�lida!')
    end
    if strcmp(formato,'completo')
        fprintf('\n')
        op2 = input('Colocar legenda? (0) N�o (1) Sim ');
        fprintf('\n')
    else
        op2 = 0;
    end
    if op2 == 1
        legend(samples)
    end
elseif op == 1 % Sele��o de amostras
    fprintf('\n')
    ns = input('Quantidade de amostras: ');
    fprintf('\n')
    disp('No caso de existirem v�rias amostras com o mesmo nome, ser� plotado o espectro m�dio!')
    fprintf('\n')
    % Verifica se a vari�vel samples � uma c�lula
    ver = iscell(samples);
    if ver == 0
        samples = cellstr(samples);
    end
    m_esp = zeros(ns,size(espectros,2));
    gn = cell(ns,1);
    for ii = 1:ns
        str = ['Amostra ' int2str(ii) ': '];
        ams = input(str,'s');
        i_m = strncmpi(ams,samples,size(ams,2));
        if sum(i_m) < 1
            disp('N�o foi encontrada nenhuma amostra com o nome indicado!!!')
            return
        elseif sum(i_m) == 1
            m_esp(ii,:) = espectros(i_m,:);
        else
            m_esp(ii,:) = mean(espectros(i_m,:));
        end
        gn(ii) = cellstr(ams);
    end
    figure
    plot(w_number,m_esp,'LineWidth',1.5)
    xlim([xmin xmax]);
    ylabel('Intensidade')
    legend(gn,'Location','Best')
    if tipo == 0
        set(gca,'XDir','reverse')
        xlabel('N�mero de onda (cm^{-1})')
    elseif tipo == 1
        xlabel('Eixo X')
    else
        disp('Op��o inv�lida!')
    end
else
    disp('Op��o inv�lida!')
end
