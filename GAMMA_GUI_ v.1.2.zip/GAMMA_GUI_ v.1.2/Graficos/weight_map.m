function weight_map(modelo,amostras,variaveis)
%% MAPA DE PESOS DE ACORDO COM A MATRIZ W
%% Vers�o: 09/02/2017
% Matriz de pesos sem normaliza��o
% Topologia: grid ou hexagonal
% Armazenamento dos pesos: w(dimens�o 1,dimens�o 2,vari�veis)
% Disposi��o autom�tica das amostras
% Interpola��o por Spline
% Regulariza��o da topologia hexagonal por Delaunay triangulation
% Gr�ficos de contorno e superf�cie
%% Par�metros
f_inter_hex = 'nearest';    % Fun��o interpoladora para regularizar a grade hexagonal
%f_inter = 'spline';         % Fun��o interpoladora
ref = 0.1;                  % Refinamento da grade para interpola��o
%% Prepara��o dos dados
[ams,vrs] = size(modelo.xc); % Quantidade de amostras e vari�veis
if isempty(amostras)
    amostras = cell(ams,1);
    for ii = 1:ams
        amostras{ii} = ['A' num2str(ii)];
    end
end
x_label = amostras;
if isempty(variaveis)
    variaveis = cell(vrs,1);
    for ii = 1:vrs
        variaveis{ii} = ['V' num2str(ii)];
    end
end
v_label = variaveis;
w = modelo.w;
pos_n = modelo.posn;
d1 = modelo.d1;
d2 = modelo.d2;
topologia = modelo.topologia;
xc = modelo.xc;
wn = modelo.wn;
%% Loop dos gr�ficos
op = 1;
while op == 1
    %arq = input('Arquivo da rede: ','s');
    %load(arq)
    iv = input('Vari�vel: ');
    %ref = input('Refinamento (entre 0 e 1): ');
    % Corre��o do grid hexagonal - Delaunay triangulation
    if strcmp(topologia,'hexagonal')
        wg = reshape(w(:,:,iv)',d1*d2,1);
        % Fun�ao interpoladora (linear,nearest,natural)
        %Fi = TriScatteredInterp(pos_n,wg,f_inter_hex);
        Fi = scatteredInterpolant(pos_n,wg,f_inter_hex);
        % Grid regularizado 
        [Y,X] = ndgrid(0:d1-1,0:d2-1);
        % Valores interpolados
        wi = zeros(size(X));
        for ii = 1:size(Y,1)
            for jj = 1:size(X,2)
                wi(ii,jj) = Fi([X(ii,jj) Y(ii,jj)]);
            end
        end
    else
        % Matriz de dados para interpola��o
        X = reshape(pos_n(:,1),d1,d2)';
        Y = reshape(pos_n(:,2),d1,d2)';
        wi = w(:,:,iv);
    end
    % Grid refinado
    [yi,xi] = ndgrid(0:ref:max(pos_n(:,2)),0:ref:max(pos_n(:,1)));
    % Interpola��o - Spline
    wgi = interp2(X,Y,wi',xi,yi,'spline');
    % Gr�fico de contorno
    figure
    contourf(xi,yi,wgi) % contorno
    colormap jet
    colorbar
    xlabel('Posi��o 1')
    ylabel('Posi��o 2')
    texto = ['Mapa de Pesos - ',v_label{iv}];
    title(texto)
    % Distribui��o das amostras
    samples_distrib(d1,d2,x_label,ams,vrs,xc,wn,pos_n)    
    %% Gr�fico de superf�cie
    figure
    surf(xi,yi,wgi)    % superf�cie
    colormap jet
    colorbar
    shading flat
    xlabel('Posi��o 1')
    ylabel('Posi��o 2')
    texto = ['Mapa de Pesos - ',v_label{iv}];
    zlabel(texto)
    % Distribui��o das amostras
    ws = w(:,:,iv);
    samples_distrib(d1,d2,x_label,ams,vrs,xc,wn,pos_n,ws)
    fprintf('\n')
    op = input('Deseja fazer outro gr�fico? (0) N�o (1) Sim ');
    fprintf('\n')
end