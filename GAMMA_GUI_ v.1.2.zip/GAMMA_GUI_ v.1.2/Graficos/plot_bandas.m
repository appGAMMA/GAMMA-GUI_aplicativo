function plot_bandas(espectros,wn,band)
%% Faz o gr�fico do espectro m�dio e plota as bandas selecionadas
%% Vers�o: 23/10/2016
%% Espectro m�dio
m_esp = mean(espectros);
figure;
colormap('jet')
plot(wn,m_esp,'-k','LineWidth',1.5)
%set(gca,'XDir','reverse')
xlabel('Comprimento de onda (nm)')
ylabel('Intensidade')
xmax = max(wn);
xmin = min(wn);
xlim([xmin xmax]);
hold on
% Marca��o das bandas de interesse
%dim = length(wn);
sel_band = find(band == 1);
x = zeros(4,1);
y = zeros(4,1);
for ii = 1:length(sel_band)
    if sel_band(ii)+1 <= length(wn)
        x(1) = wn(sel_band(ii));
        x(2) = wn(sel_band(ii)+1);
        x(3) = x(2);
        y(3) = m_esp(sel_band(ii)+1);
        x(4) = x(1);
        y(4) = m_esp(sel_band(ii));
        patch(x,y,[1,0,0],'EdgeColor','none')
    end
end
hold off
