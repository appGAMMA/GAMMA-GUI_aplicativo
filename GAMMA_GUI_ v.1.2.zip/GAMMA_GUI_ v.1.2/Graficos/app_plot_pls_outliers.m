%% Gráfico de outliers - PLS
% Versão: 26/03/2023
function app_plot_pls_outliers(model)
T2 = model.outliers.T2cal;
Qres = model.outliers.Qcal;
tlim = model.outliers.Tcrit;
qlim = model.outliers.Qcrit;
% Calibração
figure
plot(T2,Qres,'o')
ax = gca;
if tlim > ax.XLim(2)
    line([ax.XLim(1) ceil(tlim)],[qlim qlim],'Color','red','LineStyle','--','LineWidth',1.0)
else
    line([ax.XLim(1) ax.XLim(2)],[qlim qlim],'Color','red','LineStyle','--','LineWidth',1.0)
end
if qlim > ax.YLim(2)
    line([tlim tlim],[ax.YLim(1) ceil(qlim)],'Color','red','LineStyle','--','LineWidth',1.0)
else
    line([tlim tlim],[ax.YLim(1) ax.YLim(2)],'Color','red','LineStyle','--','LineWidth',1.0)
end
axis('tight')
xlabel ('Hotelling T^2')
ylabel ('Resíduos Q')
title ('Amostras de Calibração')
% Previsão
if ~isempty(model.xprev)
    T2p = model.outliers.T2pred;
    Qres_p = model.outliers.Qpred;
    figure
    plot(T2p,Qres_p,'o')
    ax = gca;
    if tlim > ax.XLim(2)
        line([ax.XLim(1) ceil(tlim*1.1)],[qlim qlim],'Color','red','LineStyle','--','LineWidth',1.0)
    else
        line([ax.XLim(1) ax.XLim(2)],[qlim qlim],'Color','red','LineStyle','--','LineWidth',1.0)
    end
    if qlim > ax.YLim(2)
        line([tlim tlim],[ax.YLim(1) ceil(qlim*1.1)],'Color','red','LineStyle','--','LineWidth',1.0)
    else
        line([tlim tlim],[ax.YLim(1) ax.YLim(2)],'Color','red','LineStyle','--','LineWidth',1.0)
    end
    axis('tight')
    xlabel ('Hotelling T^2')
    ylabel ('Resíduos Q')
    title ('Amostras de Previsão')
end