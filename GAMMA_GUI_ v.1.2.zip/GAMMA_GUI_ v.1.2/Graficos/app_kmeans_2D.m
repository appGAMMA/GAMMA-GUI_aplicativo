%% Gráfico de scores 2D - kmeans
% Versão: 01/05/2022
function app_kmeans_2D(km,pc)
% Dados para o gráfico
npcs = pc.pcs;
vrs = cell(npcs,1);
for ii = 1:npcs
    vrs{ii} = num2str(ii);
end
idx = km.indices;
S = pc.T;
% Interface gráfica
pos = [300 200 250 200];
fig = uifigure('Name','Scores 2D','Position',pos);
% Texto explicativo
texto = "Selecione uma PC para o eixo X";
uilabel(fig,'Position',[10 pos(4)-55 pos(3)-10 50],'Text',texto);
% Drop-down
dd1 = uidropdown(fig,'Position',[20 pos(4)-75 80 22],'Items',vrs,'ItemsData',1:length(vrs));
% Texto explicativo
texto = "Selecione uma PC para o eixo Y";
uilabel(fig,'Position',[10 pos(4)-120 pos(3)-10 50],'Text',texto);
% Drop-down
dd2 = uidropdown(fig,'Position',[20 pos(4)-140 80 22],'Items',vrs,'ItemsData',1:length(vrs));
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 20 100 30],'Text','Gerar Gráfico','ButtonPushedFcn', @(btn,event) gerargrafico(btn,dd1,dd2,idx,S));
end
%% Gerar gráfico
function gerargrafico(~,dd1,dd2,idx,S)
vr1 = dd1.Value;
texto1 = ['PC' num2str(vr1)];
vr2 = dd2.Value;
texto2 = ['PC' num2str(vr2)];
x = S(:,vr1);
y = S(:,vr2);
g = idx;
figure
gscatter(x,y,g,[],[],25,'on',texto1,texto2)
grid on
end