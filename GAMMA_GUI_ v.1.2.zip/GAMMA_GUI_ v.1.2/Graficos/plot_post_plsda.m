function plot_post_plsda(y,yp,GN,graf_data)
%% Plota a probabilidade a posteriori da sa�da do PLSDA
%% Vers�o: 01/02/2017
%% Prepara��o dos dados
nclass = size(y,2);
% Loop das classes
for ii = 1:nclass
    faixa = graf_data(ii).graf_post(:,1);
    p_classe = graf_data(ii).graf_post(:,2);
    p_nclasse = graf_data(ii).graf_post(:,3);
    limiar = graf_data(ii).threshold;
    % Faz a figura do tamanho da tela
    figure('units','normalized','outerposition',[0 0 1 1])
    hold on
    % Histogramas
    idx = y(:,ii) == 1;
    histogram(yp(idx,ii),'FaceColor','b','BinWidth',0.05)
    idx = y(:,ii) == 0;
    histogram(yp(idx,ii),'FaceColor','r','BinWidth',0.05)
    fmin = min(faixa);
    fmax = max(faixa);
    xlim([fmin fmax])
    xlabel('Sa�da do PLSDA')
    ylabel('Quantidade de amostras')
    legend(GN{ii},'Outras classes','Location','northoutside','Orientation','horizontal')
    % Gr�fico como um novo eixo y
    ax1 = gca; % current axes
    ax1_pos = ax1.Position; % position of first axes
    ax2 = axes('Position',ax1_pos,'XAxisLocation','top','YAxisLocation','right','Color','none');
    line(faixa,p_classe,'Parent',ax2,'Color','b')
    ylabel('Probabilidade a posteriori')
    line(faixa,p_nclasse,'Parent',ax2,'Color','r')
    xlim([fmin fmax])
    xg = [limiar limiar];
    yg = ylim;
    line(xg,yg,'LineStyle',':','Color','k') % Linha vertical
    hold off
end