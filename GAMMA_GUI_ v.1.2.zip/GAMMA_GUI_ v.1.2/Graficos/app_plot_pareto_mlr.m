%% Gráfico de pareto dos efeitos padronizados
% Versão: 30/05/2023
function app_plot_pareto_mlr(model)
ef = model.modelo.Coefficients{:,3};
ef_name = model.modelo.Coefficients.Properties.RowNames;
gl = model.modelo.DFE;
tcrit1 = abs(tinv(0.025,gl));
tcrit2 = abs(tinv(0.050,gl));
% eliminar o intercepto do gráfico
idx = contains(ef_name,'(Intercept)');
ef(idx) = [];
ef_name(idx) = [];
[v,idx] = sort(abs(ef));
figure
barh(v)
ax = gca;
yticks = ef_name(idx);
set(ax,'YTickLabel',yticks)
ax.XGrid = 'on';
xlabel('Efeito padronizado (valor absoluto)')
hold on
yg = ylim;
line([tcrit1 tcrit1],[yg(1) yg(2)],'Color','red','LineStyle','--','LineWidth',2)
line([tcrit2 tcrit2],[yg(1) yg(2)],'Color','black','LineStyle','--','LineWidth',2)
subtitle(['t_{crítico}(' num2str(gl) ', 0.050) e t_{crítico}(' num2str(gl) ', 0.025)'])