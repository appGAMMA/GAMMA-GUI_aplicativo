%% Faz os gr�ficos dos resultados do Path-ComDim
%% Vers�o: 29/01/2019
function plot_pathcomdim_out(est)
%% Retirada dos dados da estrutura
TIr = est.importancia;
Tlambdar = est.s_relative;
Trb = est.corr_block.r;
T = est.scores;
Ir = table2array(TIr);
samples = est.dados(1).i;
Ti = est.s_tab;
tab = size(est.dados,2);
tabname = cell(tab,1);
varname = cell(tab,1);
for ii = 1:tab
    tabname{ii} = est.dados(ii).info;
    varname{ii} = est.dados(ii).v;
end
LT = est.loadings;
corr_tab = est.corr_vars;
%% Sa�das na tela
disp(TIr)
disp(Tlambdar)
disp(Trb)
%% Gr�ficos
% Scores (espa�o comum)
op = input('Fazer o gr�fico dos scores no espa�o comum? (0) N�o (1) Sim ');
if op == 1
    plot_scores('Path-ComDim',T,Ir(2,:),samples)
end
% Scores (espa�o privado)
fprintf('\n')
op = input('Fazer o gr�fico dos scores no espa�o privado? (0) N�o (1) Sim ');
if op == 1
    plot_scores('Path-ComDim2',Ti,[],samples,tabname)
end
% Gr�fico dos loadings
fprintf('\n')
op = input('Fazer o gr�fico dos loadings de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_loading('Path-ComDim',LT,varname,Ti,samples,[],tabname)
end
% Gr�fico das correla��es
fprintf('\n')
op = input('Fazer o gr�fico das correla��es de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_correlation('Path-ComDim',corr_tab)
end