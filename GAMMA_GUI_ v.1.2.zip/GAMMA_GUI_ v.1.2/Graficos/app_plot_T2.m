%% Gr�fico de T2
% Vers�o: 19/05/2023
function app_plot_T2(res_pca,saida)
%% Cria��o da janela gr�fica
pcs = size(res_pca.T,2);
texto = 'Gr�fico de T2';
pos = [300 300 200 120];
fig = uifigure('Name',texto,'Position',pos);
uilabel(fig,'Text','Quantidade de PCs','Position',[15 pos(4)-30 120 20]);
spn1 = uispinner(fig,'Limits',[1  pcs],'Value',1,'Position',[130 pos(4)-30 50 20]);
uilabel(fig,'Text','Probabilidade','Position',[15 pos(4)-60 120 20]);
spn2 = uispinner(fig,'Limits',[1  99],'Value',95,'Position',[130 pos(4)-60 50 20]);
% Criar o bot�o de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Plotar','ButtonPushedFcn', @(btn,event) plot_T2(btn,fig,spn1,spn2,res_pca,saida));
end
%% Gr�fico T2
function plot_T2(~,~,spn1,spn2,res_pca,saida)
pcs = spn1.Value;
T = res_pca.T(:,1:pcs);
ams = size(res_pca.T,1);
prob = spn2.Value;
% Dist�ncia de Mahalanobis ou T2
dm2 = mahal(T,T);
t2crit = pcs*(ams-1)/(ams-pcs)*finv(prob/100,pcs,ams-pcs); % T2 cr�tico para 95%
res_pca.T2.T2 = dm2;
res_pca.T2.T2crit = t2crit;
res_pca.T2.PCs = pcs;
res_pca.T2.Probabilidade = prob;
samples = res_pca.amostras;
% Gr�fico
figure
plot(dm2,'bo')
xlim([0 ams+1])
xg = xlim;
yg = [t2crit t2crit];
line(xg,yg,'LineStyle',':','Color','r','LineWidth',2) % Linha horizontal
xlabel('Amostra')
str = ['Dist�ncia de Mahalanobis (T2) (' num2str(pcs) ' PCS)'];
ylabel(str)
% Nome das amostras acima do T2 cr�tico
idx = find(dm2 >= t2crit);
text(idx,dm2(idx),samples(idx));
res_pca.T2.outliers = idx;
assignin('base',saida,res_pca)
end