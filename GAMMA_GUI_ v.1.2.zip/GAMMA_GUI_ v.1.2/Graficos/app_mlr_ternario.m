%% Diagrama ternário para MLR - APP
% Versão: 28/06/2023
function app_mlr_ternario(modelo)
%% Criar a tabela com os preditores do modelo
npred = modelo.NumPredictors;
nvar = modelo.NumVariables;
if npred < 3
    msgbox('São necessárias pelo menos três variáveis para esse tipo de gráfico!','MLR','warn');
    return
end
pos = [300 200 300 300];
fig = uifigure('Name','Diagrama ternário','Position',pos);
% Texto explicativo
texto = "Para mais de três componentes, colocar zero como valor de mínimo e máximo para os componentes que não serão variados no diagrama";
wraptexto = "{" + replace(texto," ","} {") + "} ";
uilabel(fig,'Position',[10 pos(4)-55 pos(3)-10 50],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Tabela de dados
uit = uitable(fig,'Position',[10 50 pos(3)-20 pos(4)-110]);
uit.ColumnName = {'Variável';'Mínimo';'Máximo'}; 
dados = cell(npred,3);
for ii = 1:npred
    dados{ii,1} = modelo.PredictorNames{ii}; % nome das variáveis na primeira coluna
end
idx = 0;
for ii = 1:nvar-1 % ignora a última linha da variável dependente
    if modelo.VariableInfo{ii,3} == 1 % verifica se a variável foi incluída no modelo
        idx = idx + 1;
        faixa = modelo.VariableInfo{ii,2};
        dados{idx,2} = faixa{1}(1); % limite inferior
        dados{idx,3} = faixa{1}(2); % limite superior
    end
end
uit.Data = dados;
uit.ColumnEditable = [false true true]; % habilita a edição nas colunas 2 e 3
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Gerar Diagrama','ButtonPushedFcn', @(btn,event) gerargrafico(btn,uit,modelo));
end
%% Leitura dos dados após eventual alteração pelo usuário
function gerargrafico(~,uit,modelo)
    ptos = 400; % quantidade de pontos interpolados em cada eixo
    dados = uit.Data;
    nvar = size(dados,1);
    predname = cell(nvar,1);
    limites = zeros(nvar,2);
    vargraf = zeros(3,1);
    idx = 0;
    for ii = 1:nvar
        predname{ii} = dados{ii,1};
        limites(ii,1) = dados{ii,2};
        limites(ii,2) = dados{ii,3};
        if limites(ii,1) ~= limites(ii,2) % quando os limites forem diferentes
            idx = idx + 1;
            vargraf(idx) = ii;
        end
    end
    if idx > 3
        msgbox('Não é possível representar mais do que três variáveis no diagrama!','MLR','warn');
        return
    end
    % correção dos limites para considerar pseudo-componentes
    wlimits = ternary_axes_limits(1,'l',limites(vargraf(1),1),'low','r',limites(vargraf(2),1),'low','b',limites(vargraf(3),1),'low');
    [A,B,C] = ternary_arrays(ptos,wlimits); % retira as coordenadas dos pontos de cada lado
    Xnew = ones(length(A),nvar); % Matriz com as variáveis independentes para interpolar no modelo
    Xnew(:,vargraf(1)) = A;
    Xnew(:,vargraf(2)) = B;
    Xnew(:,vargraf(3)) = C;
    titulo = '';
    for ii = 1:nvar
        if ii ~= vargraf(1) && ii ~= vargraf(2) && ii ~= vargraf(3) 
           Xnew(:,ii) = Xnew(:,ii)*limites(ii,1);
           titulo = [titulo predname{ii} ' = ' num2str(limites(ii,1)) ' '];
        end
    end
    ypred = predict(modelo,Xnew);
    % opções para o diagrama
    %vgen  = {'wlimits',wlimits,'gridspaceunit',10,'titlelabels',{predname{vargraf(1)},predname{vargraf(2)},predname{vargraf(3)}},'titlerotation',[0,0,0]};
    vgen  = {'gridspaceunit',10,'titlelabels',{predname{vargraf(1)},predname{vargraf(2)},predname{vargraf(3)}},'titlerotation',[0,0,0]};
    figure
    H = ternary_axes(vgen); % cria os eixos do diagrama triangular
    dataplots(1).obj = ternary_surf([],'l',A,'b',B,ypred); % plota os dados no diagrama com colorbar
    colormap jet
    restack_dataplots(H,dataplots); % coloca o grid sobre o diagrama
    title(titulo)
end