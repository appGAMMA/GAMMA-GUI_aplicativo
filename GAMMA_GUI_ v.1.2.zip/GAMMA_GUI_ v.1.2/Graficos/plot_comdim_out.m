%% Faz os gr�ficos dos resultados do ComDim
%% Vers�o: 29/01/2019
function plot_comdim_out(est)
%% Retirada dos dados da estrutura
explained = est.explained(1,:);
sali = table2array(est.S);
tab = size(est.data,2);
tabname = cell(tab,1);
varname = cell(tab,1);
for ii = 1:tab
    tabname{ii} = est.data(ii).info;
    varname{ii} = est.data(ii).v;
end
T = est.T;
amsname = est.data(1).i;
Ti = est.Ti;
L = est.L;
corr_tab = est.correlation;
%% Gr�fico de Pareto
figure
pareto(explained)
xlabel('Dimens�o Comum')
ylabel('Vari�ncia Explicada (%)')
%% Sali�ncias
fprintf('Tabela das Sali�ncias \n')
fprintf('\n')
disp(est.S)
op = input('Fazer o gr�fico das sali�ncias: (0) N�o (1) Sim ');
if op == 1
    plot_saliences(sali,explained,tabname)
end
%% Gr�fico de consenso
fprintf('\n')
op = input('Fazer o gr�fico dos scores (espa�o comum)? (0) N�o (1) Sim ');
if op == 1
    plot_scores('ComDim',T,explained,amsname)
end
%% Espa�o privado de cada tabela
fprintf('\n')
op = input('Fazer o gr�fico dos scores no espa�o privado? (0) N�o (1) Sim ');
if op == 1
    plot_scores('ComDim2',Ti,[],amsname,tabname)
end
%% Gr�fico dos loadings
fprintf('\n')
op = input('Fazer o gr�fico dos loadings de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_loading('ComDim',L,varname,Ti,amsname,[],tabname)
end
%% Gr�fico das correla��es
fprintf('\n')
op = input('Fazer o gr�fico das correla��es de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_correlation('ComDim',corr_tab)
end