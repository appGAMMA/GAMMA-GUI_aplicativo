%% Gráfico de dispersão 2D - APP
% Versão: 11/08/2021
function app_dispersao_2D(estrutura)
pos = [300 200 270 200];
fig = uifigure('Name','Dispersão 2D','Position',pos);
% Texto explicativo
texto = "Selecione a primeira variável para o gráfico";
wraptexto = "{" + replace(texto," ","} {") + "} ";
uilabel(fig,'Position',[10 pos(4)-55 pos(3)-10 50],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Drop-down
vrs = estrutura.Dados.Properties.VariableNames;
vrs(1) = []; % exclui a primeira linha que corresponde aos grupos
dd1 = uidropdown(fig,'Position',[20 pos(4)-75 150 22],'Items',vrs,'ItemsData',1:length(vrs));
% Texto explicativo
texto = "Selecione a segunda variável para o gráfico";
wraptexto = "{" + replace(texto," ","} {") + "} ";
uilabel(fig,'Position',[10 pos(4)-120 pos(3)-10 50],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Drop-down
dd2 = uidropdown(fig,'Position',[20 pos(4)-140 150 22],'Items',vrs,'ItemsData',1:length(vrs));
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 20 100 30],'Text','Gerar Gráfico','ButtonPushedFcn', @(btn,event) gerargrafico(btn,dd1,dd2,estrutura));
end
%% Leitura da variável escolhida e geração do gráfico
function gerargrafico(~,dd1,dd2,estrutura)
vr1 = dd1.Value;
texto1 = dd1.Items(vr1);
vr2 = dd2.Value;
texto2 = dd1.Items(vr2);
x = estrutura.Dados{:,vr1+1};
y = estrutura.Dados{:,vr2+1};
g = estrutura.Dados{:,1};
figure
gscatter(x,y,g,[],[],25,'on',texto1,texto2)
end
