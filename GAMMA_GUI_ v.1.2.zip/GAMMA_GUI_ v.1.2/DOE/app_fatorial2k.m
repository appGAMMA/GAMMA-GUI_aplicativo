%% Gera um planejamento fatorial completo de dois níveis
% Versão: 10/06/2021
function app_fatorial2k(f,pc,op,saida)
%% Geração da matriz do planejamento
plan.planejamento = 'Fatorial completo (dois níveis)';
plan1 = ff2n(f); % gera com os níveis zero e um
plan2 = 2*(plan1 - 0.5); % correção para -1 e +1
mpc = zeros(pc,f); % pontos centrais
matriz = [plan2;mpc];
plan.matriz = matriz;
%% Descodificação da matriz do planejamento
if op == 1
    app_doe_descodifica(plan,saida);
else
    assignin('base',saida,plan)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end