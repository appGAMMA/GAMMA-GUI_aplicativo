%% Planejamento Simplex-Centroid - APP
% Versão: 08/02/2022
function app_simplex_centroid(p,ct,op,saida)
if p < 2
    msgbox('Um planejamento de misturas exige no mínimo 2 componentes!','DOE','warn');
    return
end
res.planejamento = 'Simplex Centroide';
% Componentes puros
plan = eye(p);
% Demais misturas
for ii = 2:p-1
    x = 1/ii;
    v = zeros(p,1);
    for jj = 1:ii
        v(jj) = x;
    end
    s = perms(v);
    c = size(s,1);
    temp = [];
    while c > 0
        temp = [temp;s(1,:)];
        idx = s(1,:) == s;
        idx2 = find(sum(idx,2) == p);
        s(idx2,:) = [];
        c = size(s,1);
    end
    plan = [plan;temp];
end
% Centroide
if ct > 1
    temp = ones(ct,p)*1/p;
else
    temp = ones(1,p)*1/p;
end
plan  = [plan;temp];
% Pontos axiais
if op(2) == 1
    d = (p - 1)/(2*p);
    a = 1/p + d;
    b = (1 - 1/p - d)/(p - 1);
    temp = ones(p)*b;
    for ii = 1:p
        temp(ii,ii) = a;
    end
    plan = [plan;temp];
end
res.matriz = plan;
%% Pseudo-componentes
if op(1) == 1
    app_pseudocomponentes(res,saida);
else
    assignin('base',saida,res)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end
