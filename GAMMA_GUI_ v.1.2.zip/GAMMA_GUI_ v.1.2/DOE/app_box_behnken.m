%% Gera um planejamento de Box-Behnken
% Versão: 17/12/2023
function saida = app_box_behnken(f,op,saida)
if f < 3
    msgbox('Não existe planejamento de Box-Behnken com menos de 3 fatores!','DOE','warn');
    return
end
plan.planejamento = 'Box-Behnken';
plan.matriz = bbdesign(f,'center',op(1));
%% Descodificação da matriz do planejamento
if op(2) == 1
    app_doe_descodifica(plan,saida);
else
    assignin('base',saida,plan)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end