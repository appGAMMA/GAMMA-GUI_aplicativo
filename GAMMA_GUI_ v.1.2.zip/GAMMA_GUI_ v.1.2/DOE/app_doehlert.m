%% Gera uma matriz de Doehlert - APP
% Versão: 17/08/2021
function app_doehlert(f,pc,op,saida)
plan.planejamento = 'Matriz de Doehlert';
DM=zeros(f+1,f);            
for ii = 1:f
    for jj = 1:ii
        if jj == ii
           DM(ii+1,jj) = sqrt(ii+1)/sqrt(2*ii);
        else
           DM(ii+1,ii-jj)=1/sqrt(2*(ii-(jj-1))*(ii-jj));
        end
    end
end
nf=0;
for ii = 1:f+1
    for jj = [2:ii-1,ii+1:f+1]
        nf = nf+1;
        DM(f+1+nf,:) = DM(ii,:) - DM(jj,:);
    end
end
if pc > 1
    plan.matriz = [zeros(pc-1,f);DM];
else
    plan.matriz = DM;
end
%% Descodificação da matriz do planejamento
if op == 1
    app_doe_descodifica(plan,saida);
else
    assignin('base',saida,plan)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end
