%% Planejamento Simplex-Lattice - APP
% Versão: 08/02/2022
function app_simplex_lattice(p,ct,m,op,saida)
if p < 2
    msgbox('Um planejamento de misturas exige no mínimo 2 componentes!','DOE','warn');
    return
end
res.planejamento = ['Simplex Lattice {' num2str(p) ',' num2str(m) '}'];
% Componentes puros
plan = eye(p);
% Demais misturas
v = 1/m:1/m:(m-1)/m;
temp = zeros(length(v)+1,p);
temp(2:end,1) = v;
for ii = 2:p
    for jj = 1:size(temp,1)
        for kk = 1:length(v)
            temp(end+1,:) = temp(jj,:);
            temp(end,ii) = v(kk);
        end
    end
end
idx = sum(temp,2) == 1; % combinações que seguem a restrição de misturas
plan = [plan;temp(idx,:)];
% Centroide
if ct > 0
    temp = ones(1,p)*1/p;
    idx = temp == plan;
    nc = sum(sum(idx,2) == p); % quantidade de centroides pré-existentes no planejamento
    if ct > nc
        temp = ones((ct-nc),p)*1/p;
        plan  = [plan;temp];
    end
end
% Pontos axiais
if op(2) == 1
    d = (p - 1)/(2*p);
    a = 1/p + d;
    b = (1 - 1/p - d)/(p - 1);
    temp = ones(p)*b;
    for ii = 1:p
        temp(ii,ii) = a;
    end
    plan = [plan;temp];
end
res.matriz = plan;
%% Pseudo-componentes
if op(1) == 1
    app_pseudocomponentes(res,saida);
else
    assignin('base',saida,res)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end


