%% Gera um planejamento fatorial fracionário de dois níveis
% Versão: 10/06/2021
function plan = app_fat2k_frac(f,R,pc,op,saida)
plan.planejamento = 'Fatorial fracionário (dois níveis)';
plan.resolucao = R;
fatores = eye(f); % uma matriz identidade garante os fatores principais como os mais importantes
generators = fracfactgen(fatores,[],R); % a opção [] gera o menor planejamento possível com a resolução indicada
plan.geradores = generators;
[dfF,confounding] = fracfact(generators); 
plan.confundimento = confounding;
mpc = zeros(pc,f); % pontos centrais
plan.matriz = [dfF;mpc];
%% Descodificação da matriz do planejamento
if op == 1
    app_doe_descodifica(plan,saida);
else
    assignin('base',saida,plan)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end