%% Descodifica a matriz de um planejamento experimental
% Versão: 23/08/2021
function app_pseudocomponentes(plan,saida)
%% Criar a tabela para a entrada dos modelos
X = plan.matriz;
nfat = size(X,2); % Quantidade de fatores no planejamento
texto = 'Pseudocomponentes - DOE';
pos = [300 200 450 300];
fig = uifigure('Name',texto,'Position',pos);
% Texto explicativo
%texto = "Otimização Simplex usando o algoritmo sequencial de Nelder-Mead (https://periodicos.uem.br/ojs/index.php/ActaSciTechnol/article/view/3012). Otimização simulatânea usando a função de desejabilidade de Derringer-Suich. Indicar a(s) estrutura(s) com o(s) modelo(s) a ser(em) otimizado(s).";
%wraptexto = "{" + replace(texto," ","} {") + "} ";
%uilabel(fig,'Position',[10 pos(4)-85 pos(3)-10 100],'Interpreter','latex','WordWrap','on','Text',wraptexto);
% Tabela de dados
uit = uitable(fig,'Position',[10 50 pos(3)-20 pos(4)-70]);
uit.ColumnName = {'Fator';'Mínimo'}; 
uit.ColumnWidth = {120,"auto"};
uit.ColumnEditable = [true true]; % habilita a edição nas colunas
dados = cell(nfat,2);
for ii = 1:nfat
    dados{ii,1} = ['x' num2str(ii)];
    dados{ii,2} = 0;
end
uit.Data = dados;
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Descodificar','ButtonPushedFcn', @(btn,event) descod_plan(btn,fig,uit,plan,saida));
end
%% Função que descodifica o planejamento
function descod_plan(~,fig,uit,plan,saida)
    X = plan.matriz;
    niveis = uit.Data;
    delete(fig)
    nfat = size(X,2);
    descod = zeros(size(X));
    rm = zeros(1,nfat);
    for ii = 1:nfat
        rm(ii) = niveis{ii,2};
    end
    srm = sum(rm);
    for ii = 1:nfat
        y = X(:,ii);
        descod(:,ii) = y*(1 - srm) + rm(ii);
    end
    plan.restricoes = rm;
    plan.descodificado = descod;
    assignin('base',saida,plan)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end