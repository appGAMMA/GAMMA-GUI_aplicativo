%% Gera um planejamento Central Composto Rotacional
% Versão: 10/06/2021
function app_dccr(f,pc,op,saida)
plan.planejamento = 'Central Composto Rotacional';
plan.matriz = ccdesign(f,'center',pc);
%% Descodificação da matriz do planejamento
if op == 1
    app_doe_descodifica(plan,saida);
else
    assignin('base',saida,plan)
    msgbox('Planejamento gerado com sucesso!','DOE','warn');
end