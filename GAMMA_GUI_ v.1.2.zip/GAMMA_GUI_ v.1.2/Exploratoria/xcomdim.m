function[Q, saliences, explained]=xcomdim(table,threshold,ndim)
%xcomdim				- Finding common dimensions in multitable data
% No direct use. Normally called with function "comdim"
% function[Q, saliences, explained]=xcomdim(col,threshold,ndim)
% Finding common dimensions in multitable according to method 'level3' 
% proposed by E.M. Qannari, I. Wakeling, P. Courcoux and H. J. H. MacFie
% in Food quality and Preference 11 (2000) 151-154
% table is an array of matrices with the same number of row
% threshold (optional): if the difference of fit<threshold then break the iterative loop 
% ndim : number of common dimensions
% default: threshold=1E-10; ndim=number of tables
% returns Q: nrow x ndim the observations loadings
if(nargin<2)
   threshold=1E-10;
end;   
ntable=size(table,2);
if(nargin<3)
   ndim=ntable;
end;   
nrow=size(table{1},1) ; % DNR No print
W=zeros(ntable+1,nrow,nrow);% average assoc. matrix in last element
prescale=zeros(ntable);
LAMBDA=zeros(ntable,ndim);
Q=zeros(nrow,ndim);

% centring and rescaling the tables ***************************
for(i=1:ntable)

% DNR = No print
%    disp([i ntable]);
%
   X=table{i};
   %
   % Changed by DNR (No need to create a vector of 'average')
   %    average{i}=mean(X);
   %    table{i}=X-ones(nrow,1)*average{i};
   %
   average=mean(X);
   table{i}=X-ones(nrow,1)*average;
   aux=table{i};
   xnorm=sqrt(sum(sum(aux.*aux)));
   %
   % Taken out by DNR  (Not used)
   %    initial_norm(i)= xnorm;
   %
   table{i}=table{i}/xnorm;
   W(i,:,:)=table{i}*table{i}';
   %
   % Taken out by DNR (Recalculated below)
   %    W(ntable+1,:,:)=W(ntable+1,:,:)+W(i,:,:);
   % 
end;
% end centring and rescaling	
% main loop
unexplained=ntable; % Warning!: true only because the tables were set to norm=1

wb=waitbar(0,'Calculando as dimens�es comuns...','Name','COMDIM');

for dim=1:ndim
    % DNR No print
    dim ;
    %
    previousfit=10000;
    %step a
    lambda=ones(ntable,1);
    %step b
    deltafit=1000000;
    while(deltafit>threshold)
        W(ntable+1,:,:)=zeros(1,nrow,nrow);
        %
        % Taken out by DNR (Not used)
        %       bid=0;
        %
        for ta=1:ntable
            W(ntable+1,:,:)=W(ntable+1,:,:)+lambda(ta)*W(ta,:,:);
        end
        %
        % Changed by DNR (Is 'reshape' better than 'squeeze' ?)
%         [UW, SW, VW]=svd(reshape(W(ntable+1,:,:),nrow,nrow));
        [UW, SW, VW]=svd(squeeze(W(ntable+1,:,:)));
        %
        q=UW(:,1);
        fit=0;
        for ta=1:ntable
            % estimating residuals
            %
            % Changed by DNR (Is 'reshape' better than 'squeeze' ?)
            %             lambda(ta)=q'*reshape(W(ta,:,:),nrow,nrow)*q;
            lambda(ta)=q'*squeeze(W(ta,:,:))*q;
            %
            %
            % Changed by DNR (Is 'reshape' better than 'squeeze' ?)
            %             aux=reshape(W(ta,:,:),nrow,nrow)-lambda(ta)*q*q';
            aux=squeeze(W(ta,:,:))-lambda(ta)*q*q';
            %
            fit=fit+sum(sum(aux.*aux));
        end
        deltafit=previousfit-fit;
        previousfit=fit;
    end %deltafit>threshold

    % DNR = No print
    fit ; 
    %
    explained(dim)=(unexplained-fit)/ntable*100;
    unexplained=fit;
    
    LAMBDA(:,dim)=lambda;
    Q(:,dim)=q;
    % updating residuals
    aux=eye(nrow,nrow)-q*q';
    for ta=1:ntable
        table{ta}=aux*table{ta};
        W(ta,:,:)=table{ta}*table{ta}';
    end
    
    waitbar(dim/ndim);
    
end

close(wb)

%
% Taken out by DNR (Not used)
% aux1=0;
% aux2=0;
%
saliences=LAMBDA;
