function[res]=comdim(col,ndim,threshold)
%comdim			- Finding common dimensions in multitable data (saisir format)
% function[res]=comdim(collection,(ndim),(threshold))
%
%Input arguments:
%---------------
%collection:vector of saisir files (the numbers "nrow" of rows in each table must be equal) . 
%ndim:number of common dimensions
%threshold (optional): if the "difference of fit"<threshold then break the
%iterative loop 
%
%Output arguments:
%-----------------
%res with fields:
%Q : observations scores (nrow x ndim)
%explained : 1 x ndim, percentage explanation given by each dimension  
%saliences : weight of the original tables in each
% dimensions (ntable x ndim).
%
%Method published by  E.M. Qannari, I. Wakeling, P. Courcoux and H. J. H. MacFie
%in Food quality and Preference 11 (2000) 151-154
%
%typical example (suppose 3 SAISIR matrices
%"spectra1","spectra2","spectra3")
%collection(1)=spectra1; collection(2)=spectra2; collection(3)=spectra3
%myresult=comdim(collection);
%map(myresult.Q,1,2);%% looking at the compromise scores
%figure;
%map(myresult.saliences,1,2);%% looking at the weights

ntable=size(col,2);
if(nargin<3)
   threshold=1E-10;
end;

if(nargin<2)
   ndim=ntable;
end;

for(i=1:ntable)
   s{i}=col(i).d;
end

[Q.d, saliences.d, explained.d]=xcomdim(s,threshold,ndim);

for i=1:ndim
   chaine=['D' num2str(i) '        '];
   bid(i,:)=chaine(1:6);
end

for i=1:ntable
   chaine1=['t' num2str(i) '        '];
   bid1(i,:)=chaine1(1:6);
end

Q.v=bid;
Q.i=col(1).i;

saliences.v=Q.v;% dimension
saliences.i=bid1;% table

explained.v=Q.v;
explained.i='% explained';

res.Q=Q;
res.saliences=saliences;
res.explained=explained;
