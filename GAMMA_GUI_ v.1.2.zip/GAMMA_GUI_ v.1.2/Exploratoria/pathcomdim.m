%% Path-ComDim
% Vers�o: 20/08/2019
% Algoritmo: Cariou et al. (2018) Food Quality and Preference, v.67, p.27-34.
function result_pc = pathcomdim(X,CD)
%% Par�metros
limiar = 1e-20; % Limiar para converg�ncia no ajuste das componentes
blk = length(X); % Quantidade de blocos
ams = size(X(1).d,1); % Quantidade de amostras
samples = X(1).i; % Nome das amostras
% Nome das tabelas e das vari�veis
tabname = cell(blk,1);
varname = cell(blk,1);
for ii = 1:blk
    tabname{ii} = X(ii).info;
    varname{ii} = X(ii).v;
end
%% Normaliza��o
XS = cell(1,blk);
lks = cell(1,blk); % armazena o link de cada bloco com os demais

% Autoescalamento das vari�veis de cada bloco
% Vari�ncia total dos blocos igualada dividindo-se cada elemento por sqrt(col)
% for ii = 1:blk
%     xt = X(ii).d;
%     [lin,col] = size(xt);
%     XS{ii} = zeros(lin,col);
%     xm = mean(xt);
%     xc = xt - ones(lin,1)*xm;
%     dp = std(xc);
%     for jj = 1:col
%         XS{ii}(:,jj) = xc(:,jj)./(dp(jj)*sqrt(col));
%     end
%     lks{ii} = X(ii).link;
% end
% 
% conferir se d� NaN no autoescalamento e avisar que a vari�vel foi  exclu�da.

% Centragem na m�dia e divis�o pela norma de Frobenius
for ii = 1:blk
    xt = X(ii).d;
    [lin,col] = size(xt);
    XS{ii} = zeros(lin,col);
    xm = mean(xt);
    xc = xt - ones(lin,1)*xm;
    xnorm = sqrt(sum(sum(xt.*xt)));
    XS{ii} = xc/xnorm;
    lks{ii} = X(ii).link;
end

%% Montagem das matrizes R
[R,NR,lks_name] = pathmodel(XS,lks);
%% Inicializa��o dos vetores de score (t) e demais matrizes de armazenamento
T = rand(lin,CD);
Ti = cell(1,blk);
U = zeros(lin,CD);
Ui = cell(1,blk);
lambda = zeros(NR,CD);
lambdar = zeros(NR,CD);
Ir = zeros(3,CD);
XSnew = XS;
for ii = 1:blk
    Ti{ii} = zeros(lin,CD);
    Ui{ii} = zeros(lin,CD);
end
DC_name = cell(1,CD);
for ii = 1:CD
    DC_name{ii} = ['CD' num2str(ii)];
end
%% C�lculo das dimens�es comuns
for ii = 1:CD
    deltaC = inf;
    C = 0;
    T(:,ii) = T(:,ii)./norm(T(:,ii)); % padroniza��o de t para norma unit�ria
    % Determina��o da dimens�o comum
    while deltaC > limiar
        soma = zeros(lin,lin);
        for jj = 1:NR
            soma = soma + R{jj}'*T(:,ii)*T(:,ii)'*R{jj};
        end
        [UR,~,~] = svd(soma); % atualiza��o de u
        U(:,ii) = UR(:,1);
        soma = zeros(lin,lin);
        for jj = 1:NR
            soma = soma + R{jj}*U(:,ii)*U(:,ii)'*R{jj}';
        end
        [UR,~,~] = svd(soma); % atualiza��o de t
        T(:,ii) = UR(:,1);
        soma = 0;
        % C�lculo das sali�ncias e do crit�rio de otimiza��o
        for jj = 1:NR
            lambda(jj,ii) = T(:,ii)'*R{jj}*U(:,ii);
            soma = soma + lambda(jj,ii)^2;
        end
        deltaC = soma - C;
        C = soma;
    end
    % Componentes dos blocos
    for jj = 1:blk
        Ti{jj}(:,ii) = XS{jj}*XS{jj}'*T(:,ii);
        Ui{jj}(:,ii) = XS{jj}*XS{jj}'*U(:,ii);
    end
    % Import�ncia relativa global dos componentes
    Ir(1,ii) = soma;
    % Defla��o dos blocos de dados
    aux = eye(lin,lin) - T(:,ii)*T(:,ii)';
    for jj = 1:blk
        XSnew{jj} = aux*XSnew{jj};
    end
    % Atualiza��o das matrizes R
    R = pathmodel(XSnew,lks);
end
%% Import�ncia relativa percentual
Ir(2,:) = 100*Ir(1,:)./sum(Ir(1,:));
Ir(3,:) = cumsum(Ir(2,:));
TIr = array2table(Ir,'VariableNames',DC_name);
TIr.Properties.RowNames = {'Import�ncia';'Import�ncia relativa';'Soma acumulada'};
%% Import�ncia relativa dos blocos em cada componente
row_lambda = cell(NR,1);
for ii = 1:NR
    row_lambda{ii} = ['lambda' lks_name{ii}];
end
for jj = 1:CD
   lambdar(:,jj) = (lambda(:,jj).^2)./Ir(1,jj);
end
Tlambdar = array2table(lambdar,'VariableNames',DC_name);
Tlambdar.Properties.RowNames = row_lambda;
Tlambda = array2table(lambda,'VariableNames',DC_name);
Tlambda.Properties.RowNames = row_lambda;
%% Calculo dos loadings por tabela
% Desnecess�rio uma vez que o loading equivale, exceto por um fator de
% escala, ao coeficiente de correla��o entre score vs. vari�veis originais
sT = (T'*T)\T';
% sU = (U'*U)\U';
LT = cell(1,blk);  % Loading
% LU = cell(1,blk);
% Tt = cell(1,blk); % Score
% Ut = cell(1,blk);
for ii = 1:blk
    % Autoescalada
    LT{ii} = XS{ii}'*sT';
%     LU{ii} = XS{ii}'*sU'; 
%     Tt{ii} = XS{ii}*LT{ii};
%     Ut{ii} = XS{ii}*LU{ii};
end
%% r cr�tico a 95% e 99%
tcrit = abs(tinv(0.025,ams-2));
rc95 = tcrit/sqrt(ams - 2 + tcrit^2);
tcrit = abs(tinv(0.005,ams-2));
rc99 = tcrit/sqrt(ams - 2 + tcrit^2);
%% Correla��o XS vs T
corr_tab = cell(1,blk);
for ii = 1:blk
    corr_tab{ii}.tabela = X(ii).info;
    mx = zeros(lin,size(XS{ii},2)+1);
    % Muda as vari�veis num�ricas para texto
    if ~iscell(X(ii).v)
        temp = cell(1,size(XS{ii},2));
        for kk = 1:size(XS{ii},2)
            temp{kk} = num2str(X(ii).v(kk));
        end
        X(ii).v = temp;
    end
    mr = zeros(size(XS{ii},2),CD);
    mp = zeros(size(XS{ii},2),CD);
    for jj = 1:CD
        mx(:,1) = T(:,jj);
        mx(:,2:end) = XS{ii};
        [r,p] = corrcoef(mx);
        mr(:,jj) = r(2:end,1);
        mp(:,jj) = p(2:end,1);         
    end
    corr_tab{ii}.r = array2table(mr,'VariableNames',DC_name);
    corr_tab{ii}.r.Properties.RowNames = X(ii).v;
    corr_tab{ii}.p = array2table(mp,'VariableNames',DC_name);
    corr_tab{ii}.p.Properties.RowNames = X(ii).v;
    corr_tab{ii}.rc_95 = rc95;
    corr_tab{ii}.rc_99 = rc99;
end
%% Correla��o entre os blocos
rb = zeros(NR,CD);
pb = zeros(NR,CD);
row_r = cell(NR,1);
row_p = cell(NR,1);
cont = 0;
for ii = 1:blk
    nlks = length(lks{ii});
    for jj = 1:nlks
        cont = cont + 1;
        row_r{cont} = ['r' lks_name{cont}];
        row_p{cont} = ['p_r' lks_name{cont}];
        for kk = 1:CD
            [r,p] = corrcoef(Ti{ii}(:,kk),Ti{lks{ii}(jj)}(:,kk));
            rb(cont,kk) = r(2,1);
            pb(cont,kk) = p(2,1);
        end
    end
end
Trb = array2table(rb,'VariableNames',DC_name);
Trb.Properties.RowNames = row_r;
Tpb = array2table(pb,'VariableNames',DC_name);
Tpb.Properties.RowNames = row_p;
%% Sa�das na tela
disp(TIr)
disp(Tlambdar)
disp(Trb)
%% Gr�ficos
% Scores (espa�o comum)
op = input('Fazer o gr�fico dos scores no espa�o comum? (0) N�o (1) Sim ');
if op == 1
    plot_scores('Path-ComDim',T,Ir(2,:),samples)
end
% Scores (espa�o privado)
fprintf('\n')
op = input('Fazer o gr�fico dos scores no espa�o privado? (0) N�o (1) Sim ');
if op == 1
    plot_scores('Path-ComDim2',Ti,[],samples,tabname)
end
% Gr�fico dos loadings
fprintf('\n')
op = input('Fazer o gr�fico dos loadings de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_loading('Path-ComDim',LT,varname,Ti,samples,[],tabname)
end
% Gr�fico das correla��es
fprintf('\n')
op = input('Fazer o gr�fico das correla��es de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_correlation('Path-ComDim',corr_tab)
end
%% Salva os dados
result_pc.dados = X;
result_pc.normalizado = XS;
result_pc.corr_vars = corr_tab;
result_pc.importancia = TIr;
result_pc.saliencias = Tlambda;
result_pc.s_relative = Tlambdar;
result_pc.loadings = LT;
result_pc.scores = T;
result_pc.s_tab = Ti;
result_pc.corr_block.r = Trb;
result_pc.corr_block.p = Tpb;
result_pc.corr_block.rc_95 = rc95;
result_pc.corr_block.rc_99 = rc99;