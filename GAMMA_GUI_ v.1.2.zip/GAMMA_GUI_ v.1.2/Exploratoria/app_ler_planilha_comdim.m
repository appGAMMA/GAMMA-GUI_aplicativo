%% Interface para leitura de dados de planilha - COMDIM
% Versão: 02/05/2022
function app_ler_planilha_comdim(saida)
pos = [100 200 350 100];
fig = uifigure('Name','Ler planilha','Position',pos);
% Campo de edição para salvar os dados da otimização
texto = 'Nome do arquivo (.xlsx)';
uilabel(fig,'Position',[10 60 150 30],'Text',texto);
namefld = uieditfield(fig,'text','Position',[150 60 180 25]);
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Ler arquivo','ButtonPushedFcn', @(btn,event) ler_excel(btn,fig,namefld,saida));
end