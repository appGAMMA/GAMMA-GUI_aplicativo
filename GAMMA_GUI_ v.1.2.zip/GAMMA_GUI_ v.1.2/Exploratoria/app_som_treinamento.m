%% TREINAMENTO - SOM BIDIMENSIONAL (Algoritmo de Kohonen - Haykin, 2001)
% Vers�o: 04/04/2023
% Algoritmo sequencial
% Normaliza��o: m�dia zero e vari�ncia unit�ria
% Topologia: grid ou hexagonal
% Armazenamento dos pesos: w(dimens�o 1,dimens�o 2,vari�veis)
% Fun��o de dist�ncia: Euclidiana
% Fun��o de vizinhan�a: Gaussiana
function saida = app_som_treinamento(x,top,d1,d2,epmax,eta0)
%% Par�metros do mapa
% Topologia (grid ou hexagonal)
switch top
    case 'Retangular'
        topologia = 'grid';
    case 'Hexagonal'
        topologia = 'hexagonal';
end
% Algoritmo de aprendizagem
s0 = (sqrt(d1*d2) - 1)/2; % Largura inicial da fun��o de vizinhan�a
tau1 = 1000/log10(s0);    % Constante de tempo para decaimento da vizinhan�a
tau2 = 1000;              % Constante de tempo para decaimento da aprendizagem
% Sa�da
saida.topologia = topologia;
saida.d1 = d1;
saida.d2 = d2;
saida.epocas = epmax;
saida.eta0 = eta0;
saida.s0 = s0;
saida.tau1 = tau1;
saida.tau2 = tau2;
% Quantidade de amostras (R) e vari�veis (C)
[R,C] = size(x);
%% Normaliza��o dos dados
xm = mean(x);
xs = std(x);
xc = zeros(R,C);
for jj = 1:C
    xc(:,jj) = (x(:,jj) - xm(jj))./xs(jj);
end
%% Inicializa��o do mapa
% Inicializa��o da matriz de pesos usando n�meros aleat�rios e normalmente
% distribu�dos
wn = randn(d1,d2,C);
w = zeros(d1,d2,C);
% Posi��o dos neur�nios no mapa
switch topologia
    case 'grid'
        pos_n = gridtop(d1,d2)';
    case 'hexagonal'
        pos_n = hextop(d1,d2)';
end
%% Inicializa��o do treinamento
eta = eta0;
s = s0;
mqe = zeros(1,epmax);     % Erro de quantiza��o m�dio
% Contagem de tempo
tic
% Loop das �pocas
wb=waitbar(0,'Treinamento do mapa auto-organiz�vel...','Name','Treinamento');
for ep = 1:epmax
    waitbar(ep/epmax);
    % Sorteio da ordem de apresenta��o das amostras
    a = rand(1,R);    
    [~,o] = sort(a);  % A ordem do sorteio fica armazenada no vetor "o"
    % Erro de quantiza��o
    qerror = 0;
    % Loop das amostras
    for am = 1:R
        xa = xc(o(am),:)'; % Amostra sorteada
        d = zeros(d1,d2);
        % Localiza��o do neur�nio vencedor
        for ii = 1:d1
            for jj = 1:d2
                xn = zeros(C,1);
                xn(:,1) = wn(ii,jj,:);
                d(ii,jj) = sum((xa-xn).^2).^0.5;
            end
        end
        [y1,i1] = sort(d);
        [y2,i2] = sort(y1(1,:));
        % Posi��o do neur�nio vencedor
        ind1 = i1(1,i2(1));
        ind2 = i2(1);
        neuro = sub2ind(size(d),ind1,ind2);
        nv(1) = pos_n(neuro,1);
        nv(2) = pos_n(neuro,2);
        % Atualiza��o dos pesos do mapa
        for ii = 1:d1
            for jj = 1:d2
                neuro = sub2ind(size(d),ii,jj);
                nm(1) = pos_n(neuro,1);
                nm(2) = pos_n(neuro,2);
                dn = sum((nv-nm).^2).^0.5;
                h = exp(-(dn^2)/(2*s^2));
                xn(:,1) = wn(ii,jj,:);
                xn = xn + eta*h*(xa-xn);
                wn(ii,jj,:) = xn(:,1);
            end
        end
        % Erro de quantiza��o
        qerror = qerror + y2(1);
    end % Loop das amostras
    % Atualiza��o dos par�metros do algoritmo de aprendizagem
    eta = eta0*exp(-(ep/tau2));
    s = s0*exp(-(ep/tau1));
    % Erro de quantiza��o m�dio
    mqe(ep) = qerror/C;
end % Loop das �pocas
% Descodifica��o da matriz de pesos
for kk = 1:C
    for ii = 1:d1
        for jj = 1:d2
            w(ii,jj,kk) = wn(ii,jj,kk)*xs(kk) + xm(kk);
        end
    end
end
close(wb);
% Tempo de treinamento
t = toc/60;
%% Sa�da
saida.tempo_treinamento = t;
saida.mqe = mqe;
saida.posn = pos_n;
saida.wn = wn;
saida.w = w;
saida.xc = xc;
saida.xmean = xm;
saida.xstd = xs;