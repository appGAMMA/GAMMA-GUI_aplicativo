function saida = app_estat_grupo(x,grp,vrs,alfa)
%% Estat�tica descritiva univariada por grupo - APP
%% Vers�o: 02/09/2021
% Matriz de Correla��o
% Estat�sticas descritivas: contagem, m�nimo, m�ximo, m�dia, desvio padr�o,
% intervalo de confian�a
% ANOVA: one-way
% Compara��o de m�dias: Tukey HSD
%% Prepara��o dos dados
nvrs = size(x,2); % Quantidade de amostras e vari�veis
% Transforma o grupo em um vetor coluna
[ll,cc] = size(grp);
if cc > ll
    grp = grp';
end
% Na vers�o R2021a do MATLAB n�o tem problemas com caracteres especiais no
% nome das vari�veis nas tabelas
% if isempty(vrs) % Aus�ncia do nome das vari�veis
%     vrs = cell(nvrs,1);
%     for ii = 1:nvrs
%         vrs{ii} = ['V' num2str(ii)];
%     end
% else 
%     for ii = 1:nvrs
%         % Verifica e elimina os espa�os no nome das vari�veis
%         idx = isspace(vrs{ii});
%         vrs{ii}(idx) = [];
%         % Verifica e elimina caracteres diferentes de letras ou n�meros
%         idx = ~isstrprop(vrs{ii},'alphanum');
%         vrs{ii}(idx) = [];
%     end
% end
T = array2table(x,'VariableNames',vrs);
temp = table(grp,'VariableNames',{'Grupo'});
T = [temp T];
saida.Dados = T;
tabelas = struct;
%% Matriz de correla��o
if nvrs > 1
    [r,p] = corrcoef(x);
    T = array2table(r,'VariableNames',vrs);
    T.Properties.RowNames = vrs;
    saida.Correlacao.r = T;
    T = array2table(p,'VariableNames',vrs);
    T.Properties.RowNames = vrs;
    saida.Correlacao.p = T;
end
%% Estat�sticas descritivas
saida.Alfa = alfa;
[grpMin,grpMean,grpMax,classes,quant,dp,mint] = grpstats(x,grp,{'min','mean','max','gname','numel','std','meanci'},'Alpha',alfa);
for ii = 1:nvrs
    tabelas(ii).Variavel = vrs{ii};
    if nvrs > 1
        T = table(quant(:,1),grpMin(:,ii),grpMax(:,ii),grpMean(:,ii),dp(:,ii),[mint(:,ii,1) mint(:,ii,2)],'VariableNames',{'Amostras' 'M�nimo' 'M�ximo' 'M�dia' 'Desvio Padr�o' 'Intervalo de Confian�a'});
    else
        T = table(quant(:,1),grpMin(:,ii),grpMax(:,ii),grpMean(:,ii),dp(:,ii),[mint(:,1) mint(:,2)],'VariableNames',{'Amostras' 'M�nimo' 'M�ximo' 'M�dia' 'Desvio Padr�o' 'Intervalo de Confian�a'});
    end
    T.Properties.RowNames = classes;
    tabelas(ii).Estatisticas = T;
end
%% ANOVA e teste de Tukey
for ii = 1:nvrs
    % Anova
    [~,tbl,S] = anova1(x(:,ii),grp,'off');
    tbl{1,6} = 'p';
    T = cell2table(tbl(2:end,:),'VariableNames',tbl(1,:));
    tabelas(ii).ANOVA = T;
    c = multcompare(S,'Display','off','Alpha',alfa);
    T = table([c(:,1) c(:,2)],c(:,4),[c(:,3) c(:,5)],c(:,6),'VariableNames',{'Grupo' 'Delta' 'IC' 'p'});
    tabelas(ii).Tukey = T;
    tabelas(ii).Stats = S; % essa vari�vel � usada para refazer o Tukey
    % Letras nas amostras usando o resultado do Tukey
    m = grpMean(:,ii); % m�dias
    ng  = length(classes); % quantidade de grupos
    letras = cell(ng,1);
    [~,idx] = sort(m);
    soma = 0;
    cont = 1;
    cont2 = 0;
    temp = [c(:,1) c(:,2) c(:,6)];
    while soma < ng
        idx2 = find(sum([idx(cont) == temp(:,1) idx(cont) == temp(:,2)],2) == 1);
        tuk = [temp(idx2,1) temp(idx2,2) temp(idx2,3)];
        temp(idx2,:) = [];
        soma = 0;
        for jj = 1:size(tuk,1)
            if tuk(jj,3) > alfa
                idx2 = tuk(jj,1);
                if idx2 == idx(cont)
                    idx2 = tuk(jj,2);
                end
                if isempty(letras{idx2})
                    soma = soma + 1;
                end
            end
        end
        if isempty(letras{idx(cont)}) || soma > 0
            cont2  = cont2 + 1;
            letras{idx(cont)} = [letras{idx(cont)} char(96+cont2)];
        end
        for jj = 1:size(tuk,1)
            if tuk(jj,3) > alfa
                idx2 = tuk(jj,1);
                if idx2 == idx(cont)
                    idx2 = tuk(jj,2);
                end
                if isempty(letras{idx2})
                    letras{idx2} = [letras{idx2} char(96+cont2)];
                elseif ~strcmp(letras{idx2}(end),char(96+cont2))
                    letras{idx2} = [letras{idx2} char(96+cont2)];
                end
            end
        end
        % atualiza��o do controle do loop
        soma = 0;
        for jj = 1:ng 
            soma = soma + ~isempty(letras{jj});
        end
        cont = cont + 1;
    end
    % Corre��o do �ltimo grupo caso tenha ficado sem letra
    if isempty(letras{idx(ng)})
        cont2  = cont2 + 1;
        letras{idx(ng)} = char(96+cont2);
    end
    tabelas(ii).Grupos = letras;
end
%% Sa�da
saida.Resultados = tabelas;
