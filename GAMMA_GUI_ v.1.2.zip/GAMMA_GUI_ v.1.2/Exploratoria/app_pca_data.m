function pca_out = app_pca_data(x,variaveis,samples,normaliza,algoritmo,pcs)
%% Faz a PCA - app
% Vers�o: 19/05/2023
%% Verifica��o dos dados
pca_out.dados = x; % matriz original
ams = size(x,1);
if isfloat(samples)
    temp = samples;
    samples = cell(ams,1);
    for ii = 1:ams
        samples{ii} = num2str(temp(ii));
    end
end
% Verifica se � c�lula
if ~iscell(samples)
    samples = cellstr(samples);
end
%% Normaliza��o
res = app_normaliza(x,normaliza);
x = res.x;
% Apaga colunas com NaN
temp = sum(isnan(x));
if sum(temp) > 0
    idx = find(temp>0);
    x(:,idx) = [];
    variaveis(idx) = [];
    pca_out.NaN.info = 'NaN identificado';
    pca_out.NaN.colunas = idx;
end
%% PCA svd - Dados centrados na m�dia
switch algoritmo
    case 'SVD'
        [lin,col] = size(x);
        pcs = min([lin col]) - 1;
        [coeff,score,latent] = pca(x,'Centered',false,'Rows','all','NumComponents',pcs);
    case 'NIPALS'
        [coeff,score,latent] = pca(x,'Centered',false,'Algorithm','als','NumComponents',pcs);
end

% Anota��o importante
% latent = S.^2./(n-1)    [U,S,V] = svd(x)
latent = latent*(ams - 1); % corre��o para voltar para a defini��o dos livros

% Vari�ncia capturada
% c�lculo baseado no tra�o de X'X
total = trace(x'*x);
explained(:,1) = 100*latent/total;
explained(:,2) = cumsum(explained);
%% Sa�da
pca_out.X = x; % matriz de dados normalizada
pca_out.normaliza = res;
pca_out.algoritmo = algoritmo;
pca_out.amostras = samples;
pca_out.variaveis = variaveis;
pca_out.P = coeff;
pca_out.T = score;
pca_out.latent = latent;
pca_out.explained = explained;