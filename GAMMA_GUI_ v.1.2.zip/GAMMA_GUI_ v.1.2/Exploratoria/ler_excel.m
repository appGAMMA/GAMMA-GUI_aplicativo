%% Faz a leitura de múltiplas planilhas do excel para estrutura COMDIM
% Versão: 02/05/2022
function ler_excel(~,fig,namefld,est)
arq = namefld.Value;
delete(fig)
% Opções de importação
opts = detectImportOptions(arq);
% preserva os nomes originais (problemas para Matlab anterior ao R2019b)
opts.VariableNamingRule = 'preserve';  
opts.MissingRule = 'omitvar'; % apaga as colunas com valores faltantes
% Nome das abas do arquivo
sheets = sheetnames(arq);
tab = length(sheets);
saida = struct;
% Leitura das abas
for ii = 1:tab
    opts.Sheet = ii;
    T = readtable(arq,opts);
    saida(ii).info = sheets{ii};
    saida(ii).i = T{:,1};
    temp = T.Properties.VariableNames;
    temp(1) = []; % exclui o nome da primeira coluna
    saida(ii).v = temp; 
    saida(ii).d = T{:,2:end};
end
assignin('base',est,saida)
msgbox('Leitura realizada com sucesso!','Ler planilha','warn');
end