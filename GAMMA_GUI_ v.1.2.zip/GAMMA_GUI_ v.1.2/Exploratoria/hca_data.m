function hca_out = hca_data(x,amostras)
%% Realiza a HCA e plot dendrograma
%% Vers�o: 01/06/2017
%% Par�metros
% Dist�ncia entre grupos
disp('Op��es para o m�todo de agrupamento')
disp('  average')
disp('  centroid')
disp('  complete')
disp('  median')
disp('  single')
disp('  ward')
disp('  weighted')
method = input('Escolha um m�todo: ','s');
fprintf('\n')
hca_out.method = method;
% M�trica
disp('Op��es para a m�trica de dist�ncia')
disp('  euclidean')
disp('  seuclidean')
disp('  cityblock')
disp('  minkowski')
disp('  chebychev')
disp('  mahalanobis')
disp('  cosine')
disp('  correlation')
disp('  spearman')
disp('  hamming')
disp('  jaccard')
metric = input('Escolha uma m�trica: ','s');
fprintf('\n')
hca_out.metric = metric;
%% HCA
Z = linkage(x,method,metric);
op = input('Deseja normalizar as dist�ncias: (0) N�o (1) Sim ');
if op == 1
    % Normaliza��o das dist�ncias - Dissimilaridade
    dmax = max(Z(:,3));
    Z(:,3) = Z(:,3)./dmax;
    hca_out.info = 'Dist�ncias normalizadas';
    str = 'Dissimilaridade';
else
    hca_out.info = 'Dist�ncias n�o normalizadas';
    str = 'Dist�ncia';
end
hca_out.link_dist = Z;
%% Dendrograma
figure
dendrogram(Z,0) % op��o 0 para plotar o dendrograma completo
ylabel(str)
str = ['M�todo: ' method ' - M�trica: ' metric];
title(str)
if isempty(amostras) == 0
    ax = gca;
    idx = str2num(get(ax,'XTickLabel'));
    xticks = amostras(idx);
    set(ax,'XTickLabel',xticks)
    set(ax,'XTickLabelRotation',90)
end
