function saida = ccswa(tabelas,CD)
%% An�lise de componentes comuns e pesos espec�ficos
%% Vers�o: 28/01/2019
% ComDim: E.M. Qannari, I. Wakeling, P. Courcoux and H. J. H. MacFie
% in Food quality and Preference 11 (2000) 151-154
%% Par�metros
tab = length(tabelas);      % Quantidade de tabelas
ams = length(tabelas(1).i); % Quantidade de amostras
%% Matrizes individuais
info = cell(5,1);
tab_nam = cell(1,tab);
varname = cell(1,tab);
xi = cell(1,tab);
% Centra na m�dia e escalona
for ii = 1:tab
    xi{ii} = tabelas(ii).d;
    average = mean(xi{ii});
    xi{ii} = xi{ii} - ones(ams,1)*average;
    % Escalonamento
    xnorm = sqrt(sum(sum(xi{ii}.*xi{ii})));
    xi{ii} = xi{ii}/xnorm;
    tab_nam{ii} = tabelas(ii).info;
    varname{ii} = tabelas(ii).v;
end
ams_nam = cell(1,ams);
ams_tab_nam = cell(ams,tab);
for ii = 1:ams
    ams_nam{ii} = tabelas(1).i{ii};
    for jj = 1:tab
        ams_tab_nam{ii,jj} = [ams_nam{ii} tab_nam{jj}];
    end
end
DC_name = cell(1,CD);
for ii = 1:CD
    DC_name{ii} = ['CD' num2str(ii)];
end
%% ComDim
[res] = comdim(tabelas,CD);
% Scores
T = res.Q.d;
info{1} = 'T(amostras,componentes comuns): matriz de escores';
% Saliences
S = res.saliences.d;
info{2} = 'S(tabelas,componentes comuns): matriz das sali�ncias';
% Vari�ncia
explained = res.explained.d;
explained(2,:) = cumsum(explained);
info{3} = 'explained: vari�ncia de cada componente comum (linha 1) e acumulada (linha 2)';
% Calculo dos loadings e escores por tabela
scaling = (res.Q.d'*res.Q.d)\res.Q.d';
L = cell(1,tab);  % Loading
Ti = cell(1,tab); % Score 
for ii = 1:tab
    % Original
    %L{ii} = tabelas(ii).d'*scaling';
    %Ti{ii} = tabelas(ii).d*L{ii};
    % A menos de um fator de escala, as duas equa��es resultam em um mesmo
    % conjunto de loadings
    % Autoescalada
    L{ii} = xi{ii}'*scaling'; % Matriz
    Ti{ii} = xi{ii}*L{ii}; % Matriz
end
info{4} = 'L{1,tabela}: matriz de pesos por tabela(vari�veis,componentes comuns)';
info{5} = 'Ti{1,tabela}: matriz de escores por tabela(amostras,componentes comuns)';
%% r cr�tico a 95% e 99%
tcrit = abs(tinv(0.025,ams-2));
rc95 = tcrit/sqrt(ams - 2 + tcrit^2);
tcrit = abs(tinv(0.005,ams-2));
rc99 = tcrit/sqrt(ams - 2 + tcrit^2);
%% Correla��o xi vs T
% A menos de um fator de escala, correla��o e loadings apresentam o mesmo perfil
corr_tab = cell(1,tab);
for ii = 1:tab
    corr_tab{ii}.tabela = tabelas(ii).info;
    mx = zeros(ams,size(xi{ii},2)+1);
    % Muda as vari�veis num�ricas para texto
    if ~iscell(tabelas(ii).v)
        temp = cell(1,size(xi{ii},2));
        for kk = 1:size(xi{ii},2)
            temp{kk} = num2str(tabelas(ii).v(kk));
        end
        tabelas(ii).v = temp;
    end
    mr = zeros(size(xi{ii},2),CD);
    mp = zeros(size(xi{ii},2),CD);
    for jj = 1:CD
        mx(:,1) = T(:,jj);
        mx(:,2:end) = xi{ii};
        [r,p] = corrcoef(mx);
        mr(:,jj) = r(2:end,1);
        mp(:,jj) = p(2:end,1);         
    end
    corr_tab{ii}.r = array2table(mr,'VariableNames',DC_name);
    corr_tab{ii}.r.Properties.RowNames = tabelas(ii).v;
    corr_tab{ii}.p = array2table(mp,'VariableNames',DC_name);
    corr_tab{ii}.p.Properties.RowNames = tabelas(ii).v;
    corr_tab{ii}.rc_95 = rc95;
    corr_tab{ii}.rc_99 = rc99;
end
%% Gr�fico de Pareto
figure
pareto(res.explained.d)
xlabel('Dimens�o Comum')
ylabel('Vari�ncia Explicada (%)')
%% Sali�ncias
fprintf('Tabela das Sali�ncias \n')
fprintf('\n')
DC_name = cell(1,CD);
for ii = 1:CD
    DC_name{ii} = ['CD' num2str(ii)];
end
tS = array2table(S,'VariableNames',DC_name);
tS.Properties.RowNames = tab_nam;
disp(tS)
op = input('Fazer o gr�fico das sali�ncias: (0) N�o (1) Sim ');
if op == 1
    plot_saliences(S,explained(1,:),tab_nam)
end
%% Gr�fico de consenso
fprintf('\n')
op = input('Fazer o gr�fico dos scores (espa�o comum)? (0) N�o (1) Sim ');
if op == 1
    plot_scores('ComDim',T,explained(1,:),ams_nam)
end
%% Espa�o privado de cada tabela
fprintf('\n')
op = input('Fazer o gr�fico dos scores no espa�o privado? (0) N�o (1) Sim ');
if op == 1
    plot_scores('ComDim2',Ti,[],ams_nam,tab_nam)
end
%% Gr�fico dos loadings
fprintf('\n')
op = input('Fazer o gr�fico dos loadings de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_loading('ComDim',L,varname,Ti,ams_nam,[],tab_nam)
end
%% Gr�fico das correla��es
fprintf('\n')
op = input('Fazer o gr�fico das correla��es de cada tabela? (0) N�o (1) Sim ');
if op == 1
    plot_correlation('ComDim',corr_tab)
end
%% Saida de dados
% saida.results = res;
saida.correlation = corr_tab;
saida.info = info;
saida.CC = CD;
saida.data = tabelas;
%saida.scaling = scaling;
saida.L = L;
saida.T = T;
saida.Ti = Ti;
saida.S = tS;
saida.explained = explained;
