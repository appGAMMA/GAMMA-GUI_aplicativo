function saida = estatistica_grupo(x,grp,vrs)
%% Estat�tica descritiva univariada por grupo
%% Vers�o: 01/04/2019
% Matriz de Correla��o
% Estat�sticas descritivas: contagem, m�nimo, m�ximo, m�dia, desvio padr�o,
% intervalo de confian�a (95%)
% ANOVA: one-way
% Compara��o de m�dias: Tukey HSD sem/com sa�da gr�fica
% Quando existir uma diferen�a grande entre a quantidade de amostras nos grupos o teste Tukey Unequal N HSD � mais recomendado (n�o achei esse teste no MATLAB)

% Fazer gr�ficos de distribui��o 2D e 3D por grupos (gscatter)

%% Prepara��o dos dados
nvrs = size(x,2); % Quantidade de amostras e vari�veis
% Transforma o grupo em um vetor coluna
[ll,cc] = size(grp);
if cc > ll
    grp = grp';
end
if isempty(vrs) % Aus�ncia do nome das vari�veis
    vrs = cell(nvrs,1);
    for ii = 1:nvrs
        vrs{ii} = ['V' num2str(ii)];
    end
else 
    for ii = 1:nvrs
        % Verifica e elimina os espa�os no nome das vari�veis
        idx = isspace(vrs{ii});
        vrs{ii}(idx) = [];
        % Verifica e elimina caracteres diferentes de letras ou n�meros
        idx = ~isstrprop(vrs{ii},'alphanum');
        vrs{ii}(idx) = [];
    end
end
T = array2table(x,'VariableNames',vrs);
temp = table(grp,'VariableNames',{'Grupo'});
T = [temp T];
saida.Dados = T;
tabelas = struct;
%% Matriz de correla��o
[r,p] = corrcoef(x);
T = array2table(r,'VariableNames',vrs);
T.Properties.RowNames = vrs;
saida.Correlacao.r = T;
T = array2table(p,'VariableNames',vrs);
T.Properties.RowNames = vrs;
saida.Correlacao.p = T;
tela = input('Apresentar a matriz de correla��o na tela: (0) N�o (1) Sim ');
if tela == 1
    disp('Coeficiente de correla��o')
    disp(saida.Correlacao.r)
    fprintf('\n')
    disp('p-valor para cada coeficiente de correla��o')
    disp(saida.Correlacao.p)
    fprintf('\n')
end
fprintf('\n')
%% Estat�sticas descritivas
[grpMin,grpMean,grpMax,classes,quant,dp,mint] = grpstats(x,grp,{'min','mean','max','gname','numel','std','meanci'});
% Tabelas
tela = input('Apresentar estat�sticas descritivas na tela: (0) N�o (1) Sim ');
fprintf('\n')
for ii = 1:nvrs
    tabelas(ii).Variavel = vrs{ii};
    T = table(quant(:,1),grpMin(:,ii),grpMax(:,ii),grpMean(:,ii),dp(:,ii),[mint(:,ii,1) mint(:,ii,2)],'VariableNames',{'Amostras' 'Minimo' 'Maximo' 'Media' 'DesvPad' 'IC95'});
    T.Properties.RowNames = classes;
    tabelas(ii).Estatisticas = T;
    if tela == 1
        disp(vrs{ii})
        disp(T)
        fprintf('\n')
    end
end
%% ANOVA e teste de Tukey
for ii = 1:nvrs
    % Anova
    [~,tbl,S] = anova1(x(:,ii),grp,'off');
    tbl{1,6} = 'p';
    T = cell2table(tbl(2:end,:),'VariableNames',tbl(1,:));
    tabelas(ii).ANOVA = T;
    fprintf('ANOVA %s (p-valor): %6.4f \n',vrs{ii},tbl{2,6})
    % Compara��o de m�dias
    op = input('Teste de compara��o de m�dias: (0) N�o realizar (1) Tukey (2) Tukey com gr�fico ');
    fprintf('\n')
    if op == 1 || op == 2
        if op == 1
            c = multcompare(S,'Display','off');
        else
            figure
            c = multcompare(S); % Tukey HSD
            %c = multcompare(S,'CType','scheffe'); % Scheffe � mais
            %conservador
        end
        T = table([c(:,1) c(:,2)],c(:,4),[c(:,3) c(:,5)],c(:,6),'VariableNames',{'Grupo' 'Delta' 'IC95' 'p'});
        tabelas(ii).Tukey = T;
    end
end
%% Box-plot
% Formatar melhor para o caso de muitas classes
op = input('Fazer box-plot: (0) N�o (1) Sim ');
if op == 1
    for ii = 1:nvrs
        figure
        boxplot(x(:,ii),grp)
        ylabel(vrs{ii})
    end
end
%% Sa�da
saida.Resultados = tabelas;
