function hca_out = app_hca_data(x,amostras,method,metric,normaliza,escala)
%% Realiza a HCA e plot dendrograma
%% Vers�o: 13/07/2020
%% Normaliza��o
nams = size(x,1);
switch normaliza
    case 'centrar na m�dia'
        mu = mean(x);
        x = x - ones(nams,1)*mu;
    case 'autoescalamento'
        x = zscore(x);
    case 'pareto'
        [x,~,sigma] = zscore(x);
        x = x.*(ones(nams,1)*sqrt(sigma));
end
%% HCA
Z = linkage(x,method,metric);
if escala == 1
    % Normaliza��o das dist�ncias - Dissimilaridade
    dmax = max(Z(:,3));
    Z(:,3) = Z(:,3)./dmax;
    hca_out.info = 'Dist�ncias normalizadas';
    str = 'Dissimilaridade';
else
    hca_out.info = 'Dist�ncias n�o normalizadas';
    str = 'Dist�ncia';
end
hca_out.link_dist = Z;
%% Dendrograma
figure
dendrogram(Z,0) % op��o 0 para plotar o dendrograma completo
ylabel(str)
str = ['M�todo: ' method ' - M�trica: ' metric];
title(str)
if isempty(amostras) == 0
    ax = gca;
    idx = str2num(get(ax,'XTickLabel'));
    xticks = amostras(idx);
    set(ax,'XTickLabel',xticks)
    set(ax,'XTickLabelRotation',90)
end
%% Sa�da
hca_out.X = x;
hca_out.amostras = amostras;
hca_out.method = method;
hca_out.metric = metric;
hca_out.normaliza = normaliza;