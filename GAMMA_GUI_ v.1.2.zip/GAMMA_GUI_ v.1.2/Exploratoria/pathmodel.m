%% Fun��o que gera o path-model
% Vers�o: 15/07/2018
function [R,NR,lks_name] = pathmodel(XS,lks)
blk = length(XS);
cont = 0;
for ii = 1:blk
    nlks = length(lks{ii});
    for jj = 1:nlks
        cont = cont + 1;
        R{cont} = XS{ii}*XS{ii}'*XS{lks{ii}(jj)}*XS{lks{ii}(jj)}';
        lks_name{cont} = [num2str(ii) num2str(lks{ii}(jj))];
    end
end
NR = cont;