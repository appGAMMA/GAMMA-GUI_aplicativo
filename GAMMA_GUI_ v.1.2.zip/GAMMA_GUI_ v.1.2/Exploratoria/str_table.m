%% Cria a estrutura de dados para o ComDim ou Path-ComDim
% Vers�o: 16/07/2018
function estrutura = str_table(tab,ams,dados,var_name,tab_name,lks)
estrutura = struct;
if isempty(ams)
    na = size(dados{1},1);
    ams = cell(na,1);
    for ii = 1:na
        ams{ii} = ['A' num2str(ii)];
    end
end
for ii = 1:tab
    % Nome da tabela
    if isempty(tab_name{ii})
        tab_name{ii} = ['Tabela ' num2str(ii)];
    end
    estrutura(ii).info = tab_name{ii};
    % Nome das amostras
    estrutura(ii).i = ams;
    % Nome das vari�veis
    nv = size(dados{ii},2);
    if isempty(var_name{ii})
        vrs = cell(nv,1);
        for kk = 1:nv
            vrs{kk} = ['V' num2str(kk)];
        end
        estrutura(ii).v = vrs;
    else
        estrutura(ii).v = var_name{ii};
    end
    % Dados
    estrutura(ii).d = dados{ii};
    if ~isempty(lks) % Path-ComDim
        estrutura(ii).link = lks{ii};
    end
end
