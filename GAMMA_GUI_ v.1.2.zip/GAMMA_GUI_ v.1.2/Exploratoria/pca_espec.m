function pca_out = pca_espec(espectros,w_number,samples)
%% Faz a PCA
%% Vers�o: 08/02/2019
% Para op��es e significado das vari�veis verificar help pca
% dm2: dist�ncia de Mahalanobis usando k PCs (valor cr�tico a 95%)
% Elipse de confian�a (95%) no gr�fico dos escores
% E: matriz de res�duos
% Xnew: matriz de espectros reconstru�da
% Q: soma quadr�tica dos elementos de cada linha da matriz de res�duos.
% Para rota��o varimax ver help rotatefactors
% Op��o de biplot
%% Verifica as vari�veis
ams = size(espectros,1);    % amostras
% Faixa do espectro ou nome das vari�veis
if isempty(w_number)
    w_number = 1:size(espectros,2);
end
% Nome das amostras
if isempty(samples)
    samples = cell(ams,1);
    for ii = 1:ams
        samples{ii} = num2str(ii);
    end
end
% Verifica se o nome das amostras � string
if isfloat(samples)
    temp = samples;
    samples = cell(ams,1);
    for ii = 1:ams
        samples{ii} = num2str(temp(ii));
    end
end
% Verifica se � c�lula
if ~iscell(samples)
    samples = cellstr(samples);
end
%% PCA svd - Dados centrados na m�dia
%[coeff,score,latent] = pca(espectros);
Xcm = espectros - ones(ams,1)*mean(espectros);
[U,S,V] = svd(Xcm);
coeff = V;
latent = diag(S);
score = U*S;
% Vari�ncia explicada
explained = (latent/sum(latent))*100;
% Adi��o da coluna de porcentagem acumulada na matriz EXPLAINED
explained(1,2) = explained(1,1);
for i = 2:size(explained,1)
    explained(i,2) = explained(i-1,2)+explained(i,1);
end
%% Gr�fico de Pareto
figure
subplot(1,2,1)
pareto(explained(:,1))
xlabel('Componente Principal')
ylabel('Vari�ncia Explicada (%)')
%% Gr�fico de scree
subplot(1,2,2)
plot(1:length(latent),latent)
xlabel('Componente Principal')
ylabel('Autovalor')
%% Defini��o da quantidade de PCs
pc = input('Quantidade de PCs selecionadas: ');
fprintf('\n')
%% Dist�ncia de Mahalanobis ou T2
dm2 = mahal(score(:,1:pc),score(:,1:pc));
t2crit = pc*(ams-1)/(ams-pc)*finv(0.95,pc,ams-pc); % T2 cr�tico para 95%
figure
plot(dm2,'b+')
xlim([0 ams+1])
xg = xlim;
yg = [t2crit t2crit];
line(xg,yg,'LineStyle',':','Color','r','LineWidth',2) % Linha horizontal
xlabel('Amostra')
str = ['Dist�ncia de Mahalanobis (' num2str(pc) ' PCS)'];
ylabel(str)
% Nome das amostras acima do T2 cr�tico
idx = find(dm2 >= t2crit);
text(idx,dm2(idx),samples(idx));
%% Matriz de res�duos E, par�metro Q e matriz reconstru�da Xnew
[E,Xnew] = pcares(espectros,pc);
Q = zeros(size(espectros,1),1);
for ii = 1:size(espectros,1)
    Q(ii) = E(ii,:)*E(ii,:)';
end
% figure
% plot(Q,'b+')
% xlabel('Amostra')
% ylabel('Par�metro Q')
%% Rota��o varimax normalizada
% op = input('Deseja fazer uma rota��o varimax? (0) N�o (1) Sim ');
% fprintf('\n')
% if op == 1
%     [LR,R] = rotatefactors(coeff(:,1:pc));
%     TR = Xnew*LR;
%     coeff = LR;
%     score = TR;
%     pca_out.Rvarimax = R;
% end
%% Gr�fico dos escores
op = input('Fazer o gr�fico dos scores? (0) N�o (1) Sim ');
if op == 1
    plot_scores('PCA',score,explained(:,1),samples)
end
%% Gr�fico dos loadings
fprintf('\n')
op = input('Fazer o gr�fico dos loadings? (0) N�o (1) Sim ');
if op == 1
    plot_loading('PCA',coeff,w_number,score,samples,explained(:,1))
end
%% Sa�da
pca_out.loadings = coeff;
pca_out.score = score;
pca_out.latent = latent;
pca_out.explained = explained;
pca_out.T2 = dm2;
pca_out.T2critico = t2crit;
pca_out.E = E;
pca_out.Xnew = Xnew;
pca_out.Q = Q;
pca_out.pcs = pc;
