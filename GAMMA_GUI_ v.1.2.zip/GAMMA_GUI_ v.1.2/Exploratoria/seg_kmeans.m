%% Segmentação das amostras usando o algoritmo kmeans
% Versão: 01/05/2022
% Acrescentar a possibilidade de outras medidas de distância
% default = sqeuclidean
function saida = seg_kmeans(x,ams,grp,rep)
[idx,C,sumd,D] = kmeans(x,grp,'Replicates',rep);
saida.k = grp;
saida.metrica = 'sqeuclidean';
saida.repiticoes = rep;
saida.indices = idx;
saida.medias = C;
saida.SQC = sumd;
saida.distancias = D;
grupos = cell(grp,1);
for ii = 1:grp
    a = idx == ii;
    grupos{ii} = ams(a); 
end
saida.grupos = grupos;
end