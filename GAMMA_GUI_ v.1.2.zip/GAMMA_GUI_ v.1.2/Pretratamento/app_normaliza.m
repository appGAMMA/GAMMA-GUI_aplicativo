%% Normalização dos dados - APP
% Versão: 29/04/2023
% Se os parametros forem fornecidos a rotina apenas aplica a normalização
function saida = app_normaliza(x,normaliza,param)
saida.tipo = normaliza;
nx = size(x,1);
switch normaliza
    case 'Centrar na média'
        if nargin < 3
            mu = mean(x);
            saida.mu = mu;
        else
            mu = param.mu;
        end
        x = x - ones(nx,1)*mu;
        saida.x = x;
    case 'Autoescalamento'
        if nargin < 3
            mu = mean(x);
            sigma = std(x);
            saida.mu = mu;
            saida.sigma = sigma;
        else
            mu = param.mu;
            sigma = param.sigma;
        end
        x = (x - ones(nx,1)*mu)./(ones(nx,1)*sigma);
        saida.x = x;
    case 'Pareto'
        if nargin < 3
            mu = mean(x);
            sigma = std(x);
            saida.mu = mu;
            saida.sigma = sigma;
        else
            mu = param.mu;
            sigma = param.sigma;
        end
        x = (x - ones(nx,1)*mu)./(ones(nx,1)*sqrt(sigma));
        saida.x = x;
    case 'Poisson' % foi usado o absoluto da média para evitar problemas com média negativa
        if nargin < 3
            mu = mean(x);
            saida.mu = mu;
        else
            mu = param.mu;
        end
        x = (x - ones(nx,1)*mu)./(ones(nx,1)*sqrt(abs(mu)));
        saida.x = x;
    case 'Intervalo [-1 +1]'
        if nargin < 3
            xmin = min(x);
            xmax = max(x);
            delta = xmax - xmin;
            saida.xmin = xmin;
            saida.xmax = xmax;
        else
            xmin = param.xmin;
            xmax = param.xmax;
            delta = xmax - xmin;
        end
        x = 2*(x - xmin)./delta - 1;
        saida.x = x;
    case 'PCA'
        if nargin < 3
            [P,T,~,~,exp,mu] = pca(x);
            va = cumsum(exp);
            idx = find(va > 95,1);
            saida.mu = mu;
            saida.P = P(:,1:idx);
            saida.var_acum = va(idx);
            saida.x = T(:,1:idx);
        else
            mu = param.mu;
            P = param.P;
            x = x - ones(nx,1)*mu;
            T = x*P;
            saida.x = T;
        end
end
