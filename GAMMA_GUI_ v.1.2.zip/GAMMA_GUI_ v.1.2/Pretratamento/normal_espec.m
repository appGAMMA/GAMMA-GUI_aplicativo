function normaesp_out = normal_espec(op,espectros,faixa)
%% Faz a normaliza��o de cada espectro
%% Vers�o: 15/05/2020
[lin,col] = size(espectros);
new_data = zeros(size(espectros));
switch op
    case 0
        for ii = 1:lin
            x = espectros(ii,:);
            xmax = max(abs(x));
            new_data(ii,:) = x./xmax;
        end
        normaesp_out.metodo = 'Norma infinita';
    case 1
        for ii = 1:lin
            x = espectros(ii,:);
            modulo = sum(abs(x));
            new_data(ii,:) = x./modulo;
        end
        normaesp_out.metodo = 'Norma 1';
    case 2
        for ii = 1:lin
            x = espectros(ii,:);
            new_data(ii,:) = x./norm(x);
        end
        normaesp_out.metodo = 'Norma 2';
    case 3
        if isempty(faixa)
            faixa = 1:col;
        end
        area = zeros(lin,1);
        for ii = 1:lin
            x = espectros(ii,:);
            area(ii) = trapz(faixa,x);
            new_data(ii,:) = x./area(ii);
        end
        normaesp_out.area = area;
        normaesp_out.metodo = '�rea unit�ria';
    otherwise
        disp('Op��o inv�lida!')
end
normaesp_out.new_data = new_data;