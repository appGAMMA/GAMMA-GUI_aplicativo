function base_out = baseline_espec(espectros,w_number)
%% Faz a corre��o de linha base usando ajuste de fun��o ou derivadas
%% Vers�o: 23/03/2020
% Op��es: (1) 1� derivada (2) 2� derivada (3) ajuste de fun��o
% Ajuste de fun��o (essa op��o est� desativada - 4): ver o help da fun��o 
% msbackadj, a fun��o padr�o � shape-preserving piecewise cubic interpolation
% 1� e 2� derivada: algoritmo de Savitsky-Golay
% Ajuste de fun��o linear
op = input('Escolha uma op��o: (1) 1� derivada (2) 2� derivada (3) fun��o linear ');
fprintf('\n')
switch op
    case 1 % 1� derivada
        janela = input('Janela (�mpar): ');
        fprintf('\n')
        pol = input('Ordem do polin�mio (< janela - 1): ');
        fprintf('\n')
        [~,g] = sgolay(pol,janela);
        HalfWin  = ((janela+1)/2) - 1;
        SG1 = zeros(1,length(w_number));
        dx = w_number(2) - w_number(1);
        new_espec = zeros(size(espectros));
        for jj = 1:size(espectros,1)
            y = espectros(jj,:);
            for ii = (janela+1)/2:length(w_number)-(janela+1)/2
                % 1� derivada
                SG1(ii) = dot(g(:,2),y(ii - HalfWin:ii + HalfWin));
            end
            SG1 = SG1/dx;         % Turn differential into derivative
            new_espec(jj,:) = SG1;
        end
        base_out.metodo = '1� derivada';
        base_out.janela = janela;
        base_out.polinomio = pol;
    case 2 % 2� derivada
        janela = input('Janela (�mpar): ');
        fprintf('\n')
        pol = input('Grau polin�mio (< janela - 1): ');
        fprintf('\n')
        [~,g] = sgolay(pol,janela);
        HalfWin  = ((janela+1)/2) - 1;
        SG2 = zeros(1,length(w_number));
        dx = w_number(2) - w_number(1);
        new_espec = zeros(size(espectros));
        for jj = 1:size(espectros,1)
            y = espectros(jj,:);
            for ii = (janela+1)/2:length(w_number)-(janela+1)/2
                % 2� derivada
                SG2(ii) = 2*dot(g(:,3)',y(ii - HalfWin:ii + HalfWin))';
            end
            SG2 = SG2/(dx*dx);         % Turn differential into 2nd derivative
            new_espec(jj,:) = SG2;
        end
        base_out.metodo = '2� derivada';
        base_out.janela = janela;
        base_out.polinomio = pol;
    case 3 % fun��o linear
        janela = input('Faixa para regress�o [min1 max1;min2 max2]): ');
        fprintf('\n')
        [lin,col] = size(w_number);
        if col > lin % tem que ser um vetor linha
            w_number = w_number';
        end
        [new_espec,b] = linha_base_p1(espectros,w_number,janela);
        base_out.metodo = 'Ajuste de fun��o';
        base_out.faixa = janela;
        base_out.betas = b;
    case 4 % fun��o interna do matlab - rever aplica��o
        janela = input('Janela (Padr�o = 200): ');
        fprintf('\n')
        passo = input('Passo (Padr�o = 200): ');
        fprintf('\n')
        funcao = input('Escolha a fun��o: (0) pchip (1) linear (2) spline ');
        switch funcao
            case 0
                funcao = 'pchip';
            case 1
                funcao = 'linear';
            case 2
                funcao = 'spline';
        end    
        % A faixa tem que ser um vetor coluna
        [ii,jj] = size(w_number);
        if jj > ii
            w_number = w_number';
        end
        % Corre��o
        temp = msbackadj(sort(w_number),espectros','WindowSize',janela,'StepSize',passo,'RegressionMethod',funcao,'ShowPlot',1);
        new_espec = temp';
        base_out.metodo = 'Ajuste de fun��o';
        base_out.janela = janela;
        base_out.passo = passo;
        base_out.funcao = funcao;
    otherwise
        disp('Op��o inv�lida!')
end
base_out.new_espec = new_espec;
%% Sa�da na tela
op = input('Deseja plotar os espectros corrigidos? (0) N�o (1) Sim ');
if op == 1
    plot_espec(new_espec,w_number,[],'simples')
end
