function norma_out = normal_var(espectros)
%% Faz a normaliza��o das vari�veis (colunas)
%% Vers�o: 14/02/2017
disp('Normaliza��es dispon�veis')
disp('  (0) Centragem na m�dia')
disp('  (1) Escalamento pela vari�ncia')
disp('  (2) Autoescalamento')
disp('  (3) Escalamento pela amplitude [0 1]')
disp('  (4) M�ximo e M�nimo [-1 1]')
op = input('Escolha uma op��o: ');
fprintf('\n')
switch op
    case 0
        lin = size(espectros,1);
        var_mean = mean(espectros);
        norma_out.metodo = 'Centragem na m�dia';
        norma_out.var_norma = espectros - ones(lin,1)*var_mean;
        norma_out.var_mean = var_mean;
    case 1
        var_norma = zeros(size(espectros));
        dp = std(espectros);
        for ii = 1:size(espectros,2)
            var_norma(:,ii) = espectros(:,ii)./dp(ii);
        end
        % Corre��o de NaN
        idx = isnan(var_norma);
        var_norma(idx) = 0;
        norma_out.metodo = 'Escalamento pela vari�ncia';
        norma_out.var_norma = var_norma;
        norma_out.var_dp = dp;
    case 2
        lin = size(espectros,1);
        var_mean = mean(espectros);
        var_norma = espectros - ones(lin,1)*var_mean;
        dp = std(espectros);
        for ii = 1:size(espectros,2)
            var_norma(:,ii) = var_norma(:,ii)./dp(ii);
        end
        % Corre��o de NaN
        idx = isnan(var_norma);
        var_norma(idx) = 0;
        norma_out.metodo = 'Autoescalamento';
        norma_out.var_norma = var_norma;
        norma_out.var_dp = dp;
        norma_out.var_mean = var_mean;
    case 3
        var_min = min(espectros);
        var_max = max(espectros);
        var_norma = zeros(size(espectros));
        for ii = 1:size(espectros,2)
            var_norma(:,ii) = (espectros(:,ii) - var_min(ii))./(var_max(ii) - var_min(ii));
        end
        % Corre��o de NaN
        idx = isnan(var_norma);
        var_norma(idx) = 0;
        norma_out.metodo = 'Escalamento pela amplitude';
        norma_out.var_norma = var_norma;
        norma_out.var_min = var_min;
        norma_out.var_max = var_max;
    case 4
        var_min = min(espectros);
        var_max = max(espectros);
        var_norma = zeros(size(espectros));
        for ii = 1:size(espectros,2)
            var_norma(:,ii) = 2*(espectros(:,ii) - var_min(ii))/(var_max(ii) - var_min(ii)) - 1;
        end
        % Corre��o de NaN
        idx = isnan(var_norma);
        var_norma(idx) = 0;
        norma_out.metodo = 'M�ximo e M�nimo';
        norma_out.var_norma = var_norma;
        norma_out.var_min = var_min;
        norma_out.var_max = var_max;
    otherwise
        disp('Op��o inv�lida!')
end