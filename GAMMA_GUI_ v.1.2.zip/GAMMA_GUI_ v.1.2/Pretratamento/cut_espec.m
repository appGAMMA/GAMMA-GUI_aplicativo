function cut_out = cut_espec(espectros,w_number)
%% Rotina para cortar os espectros
%% Vers�o: 23/03/2020
ns = input('Quantidade de segmentos: ');
fprintf('\n')
cortes = zeros(ns,2);
for ii = 1:ns
    str = ['Corte ' int2str(ii)];
    disp(str);
    cortes(ii,1) = input('Posi��o 1: ');
    cortes(ii,2) = input('Posi��o 2: ');
    fprintf('\n')
end
%% Primeiro corte
[lin,col] = size(w_number);
if lin > col % tem que ser um vetor linha
    w_number = w_number';
end
% Localiza��o da posi��o do cut
[~,ini] = min(abs(w_number - cortes(1,1))); % Posi��o inicial
[~,fim] = min(abs(w_number - cortes(1,2))); % Posi��o final
% Coloca as posi��es em ordem crescente
if fim < ini
    temp = ini;
    ini = fim;
    fim = temp;
end
% Corte
lin = size(espectros,1);
col = fim - ini + 1;
new_number = w_number(ini:fim);
new_espec = zeros(lin,col);
for ii = 1:lin
    new_espec(ii,:) = espectros(ii,ini:fim);
end
%% Demais cortes
for ii = 2:ns
    % Localiza��o da posi��o do cut
    [~,ini] = min(abs(w_number - cortes(ii,1))); % Posi��o inicial
    [~,fim] = min(abs(w_number - cortes(ii,2))); % Posi��o final
    % Coloca as posi��es em ordem crescente
    if fim < ini
        temp = ini;
        ini = fim;
        fim = temp;
    end
    % Corte
    col = fim - ini + 1;
    new_number = [new_number w_number(ini:fim)];
    cut_espec = zeros(lin,col);
    for ii = 1:lin
        cut_espec(ii,:) = espectros(ii,ini:fim);
    end
    new_espec = [new_espec cut_espec];
end
cut_out.new_espec = new_espec;
cut_out.new_faixa = new_number;
%% Sa�da na tela
op = input('Deseja plotar as regi�es recortadas? (0) N�o (1) Sim ');
if op == 1
    plot_espec(new_espec,new_number,[],'simples')
end
