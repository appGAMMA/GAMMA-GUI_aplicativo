function kenston_out = split_data(opt,X,pt,sss)
%% Faz a divis�o das amostras em treinamento e teste
%% Vers�o: 03/05/2017
% Algoritmo de KENNARD and STONE
% Op��es
if nargin < 4
    [m,~]=size(X); % Amostras de X
    k = round(m*pt/100);  % Amostras de treinamento
    kenston_out = kenston(X,k,opt);
else
    [ii,jj] = size(sss);
    if ii < jj % Transposta para vetor coluna
        sss = sss';
    end
    [~,GN] = grp2idx(sss);
    classes = size(GN,1);
    cal = cell(classes,1);
    val = cell(classes,1);
    kenston_out.classe_cal_val_total = cell(classes,4);
    for ii = 1:classes
        kenston_out.classe_cal_val_total{ii,1} = GN{ii};
        idx = strcmp(sss,GN{ii});
        kenston_out.classe_cal_val_total{ii,4} = sum(idx);
        k = round(sum(idx)*pt/100);
        kenston_out.classe_cal_val_total{ii,2} = k;
        kenston_out.classe_cal_val_total{ii,3} = sum(idx) - k;
        out = kenston(X(idx,:),k,opt);
        if opt == 1
            str = ['Amostras da classe ' GN{ii}];
            title(str)
        end
        aaa = find(idx == 1);
        cal{ii,1} = aaa(out.cal);
        val{ii,1} = aaa(out.val);
    end
    kenston_out.cal = cell2mat(cal);
    kenston_out.prev = cell2mat(val);
end
