function kenston_out = kenston(X,k,opt)
%% Faz a divis�o das amostras em treinamento e teste
%% Vers�o: 17/05/2016
% Algoritmo de KENNARD and STONE
% Faz a divis�o com base nos scores da matriz original
% Input:
% X, matrix (n,p), predictor variables in columns
% k, number of objects to be selected to the model set
% -------------------------------------------------------------------------
% Output:
% model, vector (k,1), list of objects selected to model set
% val, vector (n-k,1), list of objects selected to test set (optionally)
% -----------------------------------------------------------------------
% References:
% [1] R.W. Kennard, L.A. Stone, Computer aided design of experiments, 
% Technometrics 11 (1969) 137-148
% [2] M. Daszykowski, B. Walczak, D.L. Massart, Representative subset selection,
% Analytica Chimica Acta 468 (2002) 91-103
% -------------------------------------------------------------------------
[m,~]=size(X);

if k>=m || k<=0  
    h=errordlg('Wrongly specified number of objects to be selected to model set.','Error');
    model=[];
    if nargout==2
        val=[];
    end
    waitfor(h)
    return
end

% PCA
[~,X] = pca(X);

model = zeros(1,k);

x=[(1:size(X,1))' X];
n=size(x,2);
[~,ind1]=min(fastdist(mean(x(:,2:n)),x(:,2:n)));
model(1)=x(ind1,1);
x(ind1,:)=[];

cont = 1;

[~,ind2]=max(fastdist(X(model(1),:),x(:,2:n)));
model(2)=x(ind2,1);
x(ind2,:)=[];

cont = cont + 1;

for d=3:k
    [~,ww]=max(min(fastdist(x(:,2:n),X(model(1:cont),:))));
	model(d)=x(ww,1);
	x(ww,:)=[];
    
    cont = cont + 1;
end

val=1:size(X,1);
val(model)=[];

% Gr�ficos
if opt == 1
    figure
    plot(X(val,1),X(val,2),'ko')
    hold on
    plot(X(model,1),X(model,2),'kx')
    legend('Previs�o','Calibra��o','Location','Best')
    xlabel('PC 1')
    ylabel('PC 2')
    title('Amostragem Kennard-Stone')
    hold off
end

kenston_out.cal = model';
kenston_out.val = val';
kenston_out.x = X;

% ---> 

function D=fastdist(x,y)

% Calculates squared Euclidean distances between two sets of objetcs

D=((sum(y'.^2))'*ones(1,size(x,1)))+(ones(size(y,1),1)*(sum(x'.^2)))-2*(y*x');