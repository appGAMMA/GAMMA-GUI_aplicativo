%% Alisamento por média móvel - APP
% Versão: 26/03/2023
function saida = app_media_movel(X,janela,graf)
saida.metodo = 'Média móvel';
saida.janela = janela;
alisado = zeros(size(X));
for ii = 1:size(X,1)
    y = X(ii,:)';
    a = smooth(y,janela,'moving');
    alisado(ii,:) = a';
end
saida.dados = alisado;
%% Gráficos
if graf(1) == 1
    figure
    plot(X')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Dados antes do alisamento')
end
if graf(2) == 1
    figure
    plot(alisado')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title(['Média Móvel - Janela = ' num2str(janela) ' pontos'])
end