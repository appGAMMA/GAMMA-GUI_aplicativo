function cut_out = app_sel_var(x,f,c)
%% Rotina para selecionar vari�veis - app
%% Vers�o: 30/07/2020
ns = length(c)/2;
cortes = reshape(c,[2,ns])';
%% Primeiro corte
[lin,col] = size(f);
if lin > col % tem que ser um vetor linha
    f = f';
end
% Localiza��o da posi��o do cut
[~,ini] = min(abs(f - cortes(1,1))); % Posi��o inicial
[~,fim] = min(abs(f - cortes(1,2))); % Posi��o final
% Coloca as posi��es em ordem crescente
if fim < ini
    temp = ini;
    ini = fim;
    fim = temp;
end
% Corte
lin = size(x,1);
col = fim - ini + 1;
new_number = f(ini:fim);
new_espec = zeros(lin,col);
for ii = 1:lin
    new_espec(ii,:) = x(ii,ini:fim);
end
%% Demais cortes
for ii = 2:ns
    % Localiza��o da posi��o do cut
    [~,ini] = min(abs(f - cortes(ii,1))); % Posi��o inicial
    [~,fim] = min(abs(f - cortes(ii,2))); % Posi��o final
    % Coloca as posi��es em ordem crescente
    if fim < ini
        temp = ini;
        ini = fim;
        fim = temp;
    end
    % Corte
    col = fim - ini + 1;
    new_number = [new_number f(ini:fim)];
    cut_espec = zeros(lin,col);
    for ii = 1:lin
        cut_espec(ii,:) = x(ii,ini:fim);
    end
    new_espec = [new_espec cut_espec];
end
cut_out.dados = new_espec;
cut_out.faixa = new_number;
