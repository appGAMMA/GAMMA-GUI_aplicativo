%% Função que faz a interpolação de dados
% Versão: 01/03/2022
function saida = interpola(dados,f,ini,fim,dx,met,op)
% Interpolação
n = size(dados,1);
xit = ini:dx:fim;
col = length(xit);
Vit = zeros(n,col);
[lin,col] = size(f);
if lin > col
    f = f';
end
for ii = 1:n
    if lin > 1 && col > 1
        x = f(ii,:);
    else
        x = f;
    end
    v = dados(ii,:);
    vq = interp1(x,v,xit,met,'extrap');
    Vit(ii,:) = vq;
end
% Gráfico
if op == 1
    figure
    plot(xit,Vit')
    axis tight
    xlabel('Faixa de aquisição')
    ylabel('Sinal')
    title('Sinal interpolado')
end
saida.X = Vit;
saida.faixa = xit;
saida.metodo = met;
end