%% SPXY - Sele��o de amostras
%% Vers�o: 12/08/2020
function saida = spxy(x,y,pcal,graf)
ams = size(x,1); % quantidade de amostras
ncal = round(ams*pcal/100);  % Amostras de calibra��o
m = zeros(ncal,1); % amostras selecionadas
samples = 1:ams;
Dx = zeros(ams,ams); % dist�ncias da matriz X
Dy = zeros(ams,ams); % dist�ncias da matriz Y
for ii = 1:ams-1
    xa = x(ii,:);
    ya = y(ii,:);
    for jj = ii+1:ams
        xb = x(jj,:);
        yb = y(jj,:);
        Dx(ii,jj) = norm(xa - xb);
        Dy(ii,jj) = norm(ya - yb);
    end
end
Dxmax = max(max(Dx));
Dymax = max(max(Dy));
D = Dx/Dxmax + Dy/Dymax; % matriz de dist�ncias do m�todo spxy
[maxD,lin] = max(D);
[~,col] = max(maxD);
% Duas amostras inicialmente selecionadas - maior dist�ncia no conjunto completo
m(1) = lin(col);
m(2) = col;
for ii = 3:ncal
    pool = setdiff(samples,m); % �ndice das amostras que ainda n�o foram selecionadas
    dmin = zeros(ams-ii+1,1); % dist�ncia m�nima das amostras no pool em rela��o as amostras selecionadas
    for jj = 1:ams-ii+1
        idxa = pool(jj);
        d = zeros(ii-1,1);
        for kk = 1:ii-1
            idxb = m(kk);
            if idxa < idxb
                d(kk) = D(idxa,idxb);
            else
                d(kk) = D(idxb,idxa);
            end
        end
        dmin(jj) = min(d);
    end
    [~,idx] = max(dmin);
    m(ii) = pool(idx);
end
saida.Cal = m;
saida.Pred = setdiff(samples,m)';
[~,x] = pca(x);
saida.x = x;
% Gr�ficos
if graf == 1
    figure
    plot(x(saida.Pred,1),x(saida.Pred,2),'ko')
    hold on
    plot(x(saida.Cal,1),x(saida.Cal,2),'kx')
    legend('Previs�o','Calibra��o','Location','Best')
    xlabel('PC 1')
    ylabel('PC 2')
    title('Amostragem SPXY')
    hold off
end
end