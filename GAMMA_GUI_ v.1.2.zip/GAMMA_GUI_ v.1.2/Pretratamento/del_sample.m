function del_out = del_sample(espectros,samples,y)
%% Apaga amostras selecionadas
%% Vers�o: 03/05/2016
ns = input('Quantidade de amostras: ');
ams = zeros(ns,1);
for ii = 1:ns
    str = ['Amostra ' int2str(ii) ': '];
    ams(ii) = input(str);
end
ams = sort(ams,'descend');
% Verifica se a vari�vel samples � uma c�lula
ver = iscell(samples);
if ver == 0
    samples = cellstr(samples);
end
for ii = 1:ns
    espectros(ams(ii),:) = [];
    samples(ams(ii)) = [];
    if nargin > 2
        y(ams(ii),:) = [];
    end
end
del_out.new_espec = espectros;
del_out.new_samples = samples;
if nargin > 2
    del_out.new_y = y;
end