%% Cria a caixa de texto para fazer correção de linha base
% Versão: 01/03/2022
function app_linhabase
%% Elementos da caixa de diálogo
pos = [300 200 260 420];
fig = uifigure('Name','Correção de linha base','Position',pos);
% Caixas de edição
uilabel(fig,'Text','X (amostras x variáveis)','Position',[10 pos(4)-30 150 20]);
edt1 = uieditfield(fig,'Position',[150 pos(4)-30 100 20]);
uilabel(fig,'Text','Faixa de aquisição','Position',[10 pos(4)-60 150 20]);
edt2 = uieditfield(fig,'Position',[150 pos(4)-60 100 20]);
uilabel(fig,'Text','Saída','Position',[10 pos(4)-90 150 20]);
edt3 = uieditfield(fig,'Position',[150 pos(4)-90 100 20],'Value','base_out');
uilabel(fig,'Text','Selecione uma ou mais regiões para usar','Position',[10 pos(4)-120 250 20]);
uilabel(fig,'Text','como referência para corrigir a linha base','Position',[10 pos(4)-140 250 20]);
% Tabela de dados
uit = uitable(fig,'Position',[10 pos(4)-300 240 141]);
uit.ColumnName = {'Início';'Fim'}; 
uit.ColumnEditable = [true true]; 
dados = cell(5,2);
uit.Data = dados;
% Seleção de gráficos
cbx1 = uicheckbox(fig,'Text','Gráfico antes da correção','Value', 1,'Position',[10 pos(4)-330 240 20]);
cbx2 = uicheckbox(fig,'Text','Gráfico após a correção','Value', 1,'Position',[10 pos(4)-360 240 20]);
% Criar o botão que executa a correção
btn = uibutton(fig,'Position',[pos(3)/2-50 pos(4)-400 100 30],'Text','Corrigir','ButtonPushedFcn', @(btn,event) corrigir(btn,edt1,edt2,edt3,uit,cbx1,cbx2));
end
%% Carrega os dados para fazer a correção da linha base
function corrigir(~,edt1,edt2,edt3,uit,cbx1,cbx2)
    X = evalin('base',edt1.Value);
    f = evalin('base',edt2.Value);
    d = uit.Data;
    faixas = zeros(5,2);
    for ii = 1:5
        if ~isempty(d{ii,1})
            faixas(ii,1) = str2double(d{ii,1});
            faixas(ii,2) = str2double(d{ii,2});
        end
    end
    idx = faixas(:,1) == 0;
    faixas(idx,:) = [];
    [newspec,b,idx] = linha_base_p1(X,f,faixas);
    res.X = newspec;
    res.faixa = f;
    res.intervalos = faixas;
    res.coef = b;
    res.indices = idx;
    assignin('base',edt3.Value,res)
    % Gráfico dos espectros antes da correção
    if cbx1.Value == 1
        figure
        plot(f,X')
        axis tight
        ylabel('Sinal')
        xlabel('Faixa de aquisição')
        title('Antes da correção de linha base')
    end
    % Gráfico dos espectros após a correção
    if cbx2.Value == 1
        figure
        plot(f,newspec')
        axis tight
        ylabel('Sinal')
        xlabel('Faixa de aquisição')
        title('Após a correção de linha base')
    end
    msgbox('Correção realizada com sucesso','Linha Base','warn');
end

