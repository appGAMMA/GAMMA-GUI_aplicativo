%% Correção do espalhamento multiplicativo - MSC
% Versão: 02/06/2021
function saida = app_snv(X,graf)
saida.metodo = 'SNV';
[lin,col] = size(X);
xcor = zeros(lin,col);
for ii = 1:lin
    y = X(ii,:)';
    xm = ones(col,1)*mean(y);
    xc = y - xm;
    s = sqrt(xc'*xc);
    xsnv = (1/s)*xc;
    xcor(ii,:) = xsnv';
end
saida.dados = xcor;
%% Gráficos
if graf(1) == 1
    figure
    plot(X')
    xlim([1 col])
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Dados antes da correção')
end
if graf(2) == 1
    figure
    plot(xcor')
    xlim([1 col])
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Padronização normal de sinal - SNV')
end