function del_out = app_del_sample(a,m)
%% Apaga amostras selecionadas - app
%% Vers�o: 30/07/2020
del_out.excluidas = a;
nm = length(m);
d = cell(nm,1);
am = max(a);
for ii = 1:nm
    temp = m{ii};
    if am > size(temp,1)
        msgbox('Amostra n�o encontrada!','Excluir amostras','warn');
        del_out.dados = [];
        return
    end
    temp(a,:) = [];
    d{ii} = temp;
end
del_out.dados = d;
