%% Alisamento Savitsky-Golay - APP
% Versão: 23/03/2023
function saida = app_savgol(X,janela,ordem,graf)
saida.metodo = 'Savitsky-Golay';
saida.janela = janela;
saida.ordem = ordem;
if ordem > janela
    msgbox('A ordem não pode ser maior que a janela! O valor da ordem foi corrigido!','Alisamento','warn');
    ordem = janela - 1;
end
alisado = zeros(size(X));
for ii = 1:size(X,1)
    y = X(ii,:)';
    a = smooth(y,janela,'sgolay',ordem);
    alisado(ii,:) = a';
end
saida.dados = alisado;
%% Gráficos
if graf(1) == 1
    figure
    plot(X')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Dados antes do alisamento')
end
if graf(2) == 1
    figure
    plot(alisado')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title(['Savitsky-Golay - Janela = ' num2str(janela) ' - Ordem = ' num2str(ordem)])
end