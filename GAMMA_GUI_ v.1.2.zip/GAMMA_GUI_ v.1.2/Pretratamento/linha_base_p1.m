function [newspec,b,idx] = linha_base_p1(spec,freqs,range)
%% Corrige linha de base usando um polin�mio de primeira ordem
%% Vers�o: 03/06/2022

% Localizar os �ndices das faixas selecionadas
lin = size(range,1);
idx = [];
for ii = 1:lin
  tmp = find(freqs <= max(range(ii,:)) & freqs >= min(range(ii,:)));
  [mt,nt] = size(tmp);
  if min([mt nt]) == 0
    s = sprintf('A regi�o %g at� %g n�o foi localizada',...
	    range(ii,1),range(ii,2));
    msgbox(s,'Linha Base','warn');
  else
    idx = [idx;tmp];
  end
end
idx = sort(idx);
if isempty(idx)
  error('Nenhuma regi�o foi identificada!')
elseif max(idx)>size(spec,2)
  error('A regi�o indicada ultrapassa o espectro!')
end

% Ajuste linear e subtra��o em cada espectro
newspec = spec;
[lin,col] = size(spec);
xb = ones(col,2);
xb(:,2) = freqs;
xr = xb(idx,:);
b = zeros(2,lin);
for ii = 1:lin
  b(:,ii) = xr\spec(ii,idx)';
  newspec(ii,:) = spec(ii,:) - (xb*b(:,ii))';
end