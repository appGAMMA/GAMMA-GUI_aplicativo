function cms_out = corr_multip_espec(tipo,espectros,y,amcal,amval)
%% Corre��o multiplicativa de sinal com MSC, SNV ou OSC
%% Vers�o: 31/08/2017
nOSC = 5;
switch tipo
    case 1 % MSC usando o espectro m�dio
        jj = size(espectros,2);
        xm = [ones(jj,1) mean(espectros)'];
        coef = (xm'*xm)\xm'*espectros';
        xmsc = (espectros' - ones(jj,1)*coef(1,:))./(ones(jj,1)*coef(2,:));
        new_espec = xmsc';
        cms_out.metodo = 'MSC';
    case 2 % SNV
        jj = size(espectros,2);
        new_espec = zeros(size(espectros));
        for ii = 1:size(espectros,1)
            y = espectros(ii,:)';
            xm = ones(jj,1)*mean(y);
            xc = y - xm;
            s = sqrt(xc'*xc);
            xsnv = (1/s)*xc;
            new_espec(ii,:) = xsnv';
        end
        cms_out.metodo = 'SNV';
    case 3 % OSC using Fearn's method
        new_espec = zeros(size(espectros));
        saida = oscfearn(espectros(amcal,:),y(amcal),espectros(amval,:),nOSC);
        new_espec(amcal,:) = saida.Zcal;
        new_espec(amval,:) = saida.Ztest;
        cms_out.metodo = 'OSC';
    case 4 % OPLS
        new_espec = zeros(size(espectros));
        saida = opls(espectros(amcal,:),y(amcal),espectros(amval,:),nOSC);
        new_espec(amcal,:) = saida.Zcal;
        new_espec(amval,:) = saida.Ztest;
        cms_out.metodo = 'OPLS';
    otherwise
        disp('Op��o inv�lida!')
end
cms_out.new_espec = new_espec;