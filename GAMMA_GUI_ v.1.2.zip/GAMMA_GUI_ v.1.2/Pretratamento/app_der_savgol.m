%% Derivadas Savitsky-Golay - APP
% Versão: 24/08/2021
function saida = app_der_savgol(X,faixa,derivada,janela,ordem,graf)
saida.metodo = 'Savitsky-Golay';
saida.derivada = derivada;
saida.janela = janela;
saida.ordem = ordem;
if ordem > janela
    msgbox('A ordem não pode ser maior que a janela! O valor da ordem foi corrigido!','Alisamento','warn');
    ordem = janela - 1;
end
% faixa deve ser um vetor coluna
[lin,col] = size(faixa);
if col > lin
    faixa = faixa';
end
[lin,col] = size(X);
x_derivada = zeros(lin,col);
[~,g] = sgolay(ordem,janela);
HalfWin  = ((janela+1)/2) - 1;

% acrescenta 1 para não faltar pontos (parece criar uma distorção nos dados)
%dx = [diff(faixa);1]';

dx = diff(faixa);
dx = [dx;dx(end)]'; % testando repetir o último ponto

switch derivada
    case '1ª derivada'
        SG1 = zeros(1,col);
        for ii = 1:lin
            y = X(ii,:);
            for jj = (janela+1)/2:col-(janela+1)/2
                % 1ª derivada
                SG1(jj) = dot(g(:,2),y(jj - HalfWin:jj + HalfWin));
            end
            SG1 = SG1./dx;         % Turn differential into derivative
            x_derivada(ii,:) = SG1;
        end
    case '2ª derivada'
        SG2 = zeros(1,col);
        for ii = 1:lin
            y = X(ii,:);
            for jj = (janela+1)/2:col-(janela+1)/2
                % 2ª derivada
                SG2(jj) = 2*dot(g(:,3)',y(jj - HalfWin:jj + HalfWin))';
            end
            SG2 = SG2./(dx.*dx);         % Turn differential into 2nd derivative
            x_derivada(ii,:) = SG2;
        end
end
saida.dados = x_derivada;
%% Gráficos
if graf(1) == 1
    figure
    plot(X')
    xlim([1 col])
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Dados originais')
end
if graf(2) == 1
    figure
    plot(x_derivada')
    xlim([1 col])
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title([derivada ' - Janela = ' num2str(janela) ' - Ordem = ' num2str(ordem)])
end