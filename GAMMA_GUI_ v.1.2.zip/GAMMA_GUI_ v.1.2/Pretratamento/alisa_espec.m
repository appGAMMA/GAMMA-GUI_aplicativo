function alisa_out = alisa_espec(espectros)
%% Faz alisamento de espectros por m�dia m�vel ou Savitsky-Golay
%% Vers�o: 16/03/2019
op = input('Escolha uma op��o: (1) m�dia m�vel (2) Savitsky-Golay ');
fprintf('\n')
switch op
    case 1
        janela = input('Janela (�mpar): ');
        fprintf('\n')
        new_espec = zeros(size(espectros));
        for jj = 1:size(espectros,1)
            y = espectros(jj,:)';
            yy = smooth(y,janela,'moving');
            new_espec(jj,:) = yy';
        end
        alisa_out.metodo = 'M�dia m�vel';
        alisa_out.janela = janela;
    case 2
        janela = input('Janela (�mpar): ');
        fprintf('\n')
        pol = input('Ordem do polin�mio (< janela - 1): ');
        fprintf('\n')
        new_espec = zeros(size(espectros));
        for jj = 1:size(espectros,1)
            y = espectros(jj,:)';
            yy = smooth(y,janela,'sgolay',pol);
            new_espec(jj,:) = yy';
        end
        alisa_out.metodo = 'Savitsky-Golay';
        alisa_out.janela = janela;
        alisa_out.polinomio = pol;
    otherwise
        disp('Op��o inv�lida!')
end
alisa_out.new_espec = new_espec;
%% Sa�da na tela
op = input('Deseja plotar os espectros alisados? (0) N�o (1) Sim ');
if op == 1
    plot_espec(new_espec,[],[],'simples')
end
