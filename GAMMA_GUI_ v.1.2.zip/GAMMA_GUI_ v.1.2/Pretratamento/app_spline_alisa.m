%% Alisamento (smoothinspline) e Derivadas  (diferenças finitas centrais)
% Versão: 26/03/2023
function saida = app_spline_alisa(x,y,p,op)
[lin,col] = size(x);
if col > lin
    x = x';
end
ft = fittype('smoothingspline');
if p >= 0
    opts = fitoptions('Method','SmoothingSpline');
    opts.SmoothingParam = p;
end
lin = size(y,1);
esp_alisado = zeros(size(y));
d1 = zeros(size(y));
d2 = zeros(size(y));
wb = waitbar(0,'Alisando os dados...','Name','Alisamento');
for ii = 1:lin
    if p >= 0
        fitresult = fit(x,y(ii,:)',ft,opts);
    else
        fitresult = fit(x,y(ii,:)',ft);
    end
    esp_alisado(ii,:) = feval(fitresult,x);
    [fx,fxx] = differentiate(fitresult,x);
    d1(ii,:) = fx;
    d2(ii,:) = fxx;
    waitbar(ii/lin);
end
close(wb)
%% Saída dos resultados
saida.metodo = 'Spline alisadora';
saida.p = p;
saida.dados = esp_alisado;
if op(3) == 1
    saida.d1 = d1;
    saida.d2 = d2;
end
%% Gráficos
if op(1) == 1
    figure
    plot(y')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Dados antes do alisamento')
end
if op(2) == 1
    figure
    plot(esp_alisado')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title(['Spline alisadora - p = ' num2str(p)])
end
if op(3) == 1
    figure
    plot(d1')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title(['1ª derivada - p = ' num2str(p)])
    figure
    plot(d2')
    axis tight
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title(['2ª derivada - p = ' num2str(p)])
end
