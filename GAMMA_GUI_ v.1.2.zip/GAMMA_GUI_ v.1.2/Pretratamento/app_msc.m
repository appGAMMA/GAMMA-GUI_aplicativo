%% Correção multiplicativa de espalhamento - MSC
% Versão: 02/06/2021
function saida = app_msc(X,graf)
saida.metodo = 'MSC';
col = size(X,2);
xm = [ones(col,1) mean(X)'];
coef = (xm'*xm)\xm'*X';
xmsc = (X' - ones(col,1)*coef(1,:))./(ones(col,1)*coef(2,:));
saida.dados = xmsc';
%% Gráficos
if graf(1) == 1
    figure
    plot(X')
    xlim([1 col])
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Dados antes da correção')
end
if graf(2) == 1
    figure
    plot(xmsc)
    xlim([1 col])
    xlabel('Eixo X')
    ylabel('Eixo Y')
    title('Correção multiplicativa de espalhamento - MSC')
end