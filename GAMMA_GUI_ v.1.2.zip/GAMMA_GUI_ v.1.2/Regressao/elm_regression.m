function saida = elm_regression(x,y,amcal,amprev)
%% Extreme Learning Machine - Regress�o
%% Vers�o: 15/08/2017
saida = struct;
saida.X = x;
saida.Y = y;
saida.acal = amcal;
saida.aprev = amprev;
%% Prepara��o dos dados
xcal = x(amcal,:); % x de calibra��o
ncal = length(amcal); % quantidade de amostras de calibra��o
ycal = y(amcal,:); % y de calibra��o
if ~isempty(amprev)
    xprev = x(amprev,:); % x de previs�o   
    yprev = y(amprev,:); % y de previs�o
end
%% Par�metros
opt.type = 'regression';
opt.inputsize = size(x,2);
opt.orthogonal = false; % transforma em uma base ortonormal
% Fun��o de ativa��o
fprintf('\n')
op = input('Fun��o de ativa��o: (0) sigmoide (1) tangente hiperb�lica ');
switch op
    case 0
        opt.activefunction = 'sigmoid';
    case 1
        opt.activefunction = 'tanh';
    otherwise
        disp('Op��o inv�lida!')
end
% Algoritmo
fprintf('\n')
fprintf('Algoritmo de treinamento: \n')
fprintf('\t (0) ELM \n')
fprintf('\t (1) RELM \n')
fprintf('\t (2) WRELM \n')
fprintf('\t (3) ORELM \n')
op = input('Escolha uma op��o: ');
switch op
    case 0
        opt.method = 'ELM';
    case 1
        opt.method = 'RELM';
        opt.C = 0.0001;
    case 2
        opt.method = 'WRELM';
        opt.wfun = '1';
        opt.scale_method = 1;
        opt.C = 2^(-20);
    case 3
        opt.method = 'ORELM';
        opt.C = 2^(-40);
    otherwise
        disp('Op��o inv�lida!')
end
% Neur�nios ocultos
fprintf('\n')
hn = input('Quantidade m�xima de neur�nios ocultos = ');
opt.max_hn = hn;
% Salva as op��es
saida.opt = opt;
% Valida��o cruzada
fprintf('\n')
tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
if tipo_vc == 1
    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
    saida.tipo_vc = 'k-fold';
    cvidx = crossvalind('Kfold',ncal,kfold);
else
    kfold = ncal;
    saida.tipo_vc = 'leave-one-out';
    cvidx = 1:kfold;
end
%% Valida��o cruzada - defini��o da quantidade de neur�nios ocultos
RMSECV = zeros(hn,1);
r2 = zeros(hn,1);
cont = 0;
ypcv = zeros(ncal,1);
saidaCV = zeros(ncal,hn);
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
for ii = 1:hn % loop dos neur�nios ocultos
    opt.hiddensize = ii;
    for kk = 1:kfold  % Loop da valida��o cruzada
        % Separa��o das amostras
        idx = cvidx ~= kk;
        xcv_cal = xcal(idx,:);
        ycv_cal = ycal(idx);
        idx = cvidx == kk;
        xcv_val = xcal(idx,:);
        ycv_val = ycal(idx);
        % Inicializa��o
        opt = elm_initialization(opt);
        % Calibra��o
        [temp,~] = elm_train(xcv_cal',ycv_cal',opt);
        % Previs�o
        [nn,~] = elm_test(xcv_val',ycv_val',temp);
        ypcv(idx,:) = nn.testlabel';
        % Atualiza��o da barra de execu��o
        cont = cont + 1;
        waitbar(cont/(kfold*hn));
    end
    % FOM
    temp = fom(ycal,ypcv);
    saidaCV(:,ii) = ypcv;
    RMSECV(ii) = temp.RMSE;
    r2(ii) = temp.r2;
end
saida.faixa_hn = 1:hn;
saida.RMSECV = RMSECV;
saida.r2_cv = r2;
close(wb);
% Gr�ficos para RMSECV e r2
figure
xgraf = 1:hn;
hAx = plotyy(xgraf,RMSECV,xgraf,r2);
title('Valida��o Cruzada')
xlabel('Neur�nios ocultos')
ylabel(hAx(1),'RMSECV') % left y-axis
ylabel(hAx(2),'r^{2}') % right y-axis
%% Calibra��o
op = 1;
cont = 1;
%model = struct;
while op == 1
    fprintf('\n')
    hn = input('Neur�nios ocultos: ');
    saida(cont).hn = hn;
    % Calibra��o
    opt.hiddensize = hn;
    opt = elm_initialization(opt);
    [elm,~] = elm_train(xcal',ycal',opt);
    saida(cont).model = elm;
    % Previs�o
    yp = zeros(size(y));
    yp(amcal) = elm.trainlabel';
    if ~isempty(amprev)
        [temp,~] = elm_test(xprev',yprev',elm);
        yp(amprev) = temp.testlabel';
    end
    saida(cont).yp = yp;
    %% Figuras de m�rito
    % Calibra��o
    saida(cont).FOMcal = fom(ycal,yp(amcal));
    fprintf('RMSEC  = %8.4f \t r\xB2 = %8.4f \n',saida(cont).FOMcal.RMSE,saida(cont).FOMcal.r2)
    % Valida��o cruzada
    ypcv = saidaCV(:,hn);
    saida(cont).ypcv = ypcv;
    saida(cont).FOMcv = fom(ycal,ypcv);
    fprintf('RMSECV = %8.4f \t r\xB2 = %8.4f\n',saida(cont).FOMcv.RMSE,saida(cont).FOMcv.r2)
    % Previs�o
    if ~isempty(amprev)
        saida(cont).FOMprev = fom(yprev,yp(amprev));
        fprintf('RMSEP  = %8.4f \t r\xB2 = %8.4f \n',saida(cont).FOMprev.RMSE,saida(cont).FOMprev.r2)
    end
    %% Gr�ficos de performance
    fprintf('\n')
    op = input('Deseja plotar as respostas do ELR? (0) N�o (1) Sim ');
    if op == 1
        if ~isempty(amprev)
            graf_out = pls_reg_graf(ncal,ycal,yp(amcal),yprev,yp(amprev));
        else
            graf_out = pls_reg_graf(ncal,ycal,ypcv,[],[]);
        end
        saida(cont).graf_perf = graf_out;
    end
    %% Retorno
    fprintf('\n')
    op = input('Deseja construir outro modelo? (0) N�o (1) Sim ');
    cont = cont + 1;
end
