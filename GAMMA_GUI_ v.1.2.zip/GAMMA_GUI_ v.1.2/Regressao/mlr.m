function out = mlr(x,y)
%% Regress�o Linear Multivariada - MLR
%% Vers�o: 20/07/2016
%% Regress�o
lm = fitlm(x,y,'linear');
%% Sa�da
% Par�metros estat�sticos
disp(lm)
% Anova
ANOVA_table = anova(lm,'summary')
%disp(ANOVA_table)
% Gr�fico do ajuste
figure
plot(lm)
% Leverage
figure
plotDiagnostics(lm)
% Res�duos vs. Previsto
figure
plotResiduals(lm,'fitted')
% Gr�fico normal dos res�duos
figure
plotResiduals(lm,'probability')
out = lm;