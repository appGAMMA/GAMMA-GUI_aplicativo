function model = pls(x,y,am_treina,am_teste,nvl)
%% PLS usando as rotinas do MATLAB
%% Vers�o: 30/06/2017
model = struct;
%% Dados
x_treina = x(am_treina,:);
y_treina = y(am_treina);
model.xcal = x_treina;
model.ycal = y_treina;
model.amcal = am_treina;
acal = length(am_treina);
if ~isempty(am_teste)
    x_teste = x(am_teste,:);
    y_teste = y(am_teste);
    model.xprev = x_teste;
    model.yprev = y_teste;
    model.amprev = am_teste;
end
%% Valida��o cruzada
tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
if tipo_vc == 1
    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
    model.tipo_vc = 'k-fold';
else
    kfold = length(am_treina);
    model.tipo_vc = 'Leave-one-out';
end
model.kfold = kfold;
%% Defini��o da quantidade de VL
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
cont = 0;
saidaCV = zeros(acal,nvl);
RMSECV = zeros(nvl,1);
r2 = zeros(nvl,1);
for jj = 1:nvl % Loop das vari�veis latentes
    ycv = zeros(size(y_treina));
    % Valida��o cruzada
    if kfold < acal
        % K-fold
        cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
    else
        % Leave-one-out
        cvidx = 1:acal;
    end
    for kk = 1:kfold  % Loop da valida��o cruzada
        % Separa��o das amostras
        idx = cvidx ~= kk;
        xcv_treina = x_treina(idx,:);
        ycv_treina = y_treina(idx,:);
        idx = cvidx == kk;
        xcv_teste = x_treina(idx,:);
        [~,~,~,~,beta] = plsregress(xcv_treina,ycv_treina,jj);
        ycv(idx,:) = [ones(size(xcv_teste,1),1) xcv_teste]*beta;
        % Atualiza��o da barra de execu��o
        cont = cont + 1;
        waitbar(cont/(nvl*kfold));
    end
    % FOM
    FOM = fom(y_treina,ycv);
    saidaCV(:,jj) = ycv;
    RMSECV(jj) = FOM.RMSE;
    r2(jj) = FOM.r2;
end
model.RMSECV = RMSECV;
model.r2_cv = r2;
close(wb)
% Gr�ficos para RMSECV e r2
figure
xgraf = 1:nvl;
hAx = plotyy(xgraf,RMSECV,xgraf,r2);
title('Valida��o Cruzada')
xlabel('Vari�veis latentes')
ylabel(hAx(1),'RMSECV') % left y-axis
ylabel(hAx(2),'r^{2}') % right y-axis
%% Constru��o do modelo
op = 1;
cont = 1;
while op == 1
    fprintf('\n')
    VL = input('Vari�veis Latentes: ');
    model(cont).VL = VL;
    model(cont).rmsecv = RMSECV(VL);
    [xl,yl,xs,ys,beta,model(cont).pctvar,~,stats] = plsregress(x_treina,y_treina,model(cont).VL);
    % FOM calibra��o
    yp_treina = [ones(size(x_treina,1),1) x_treina]*beta;
    model(cont).ypcal = yp_treina;
    model(cont).FOMcal = fom(y_treina,yp_treina);
    fprintf('RMSEC  = %8.4f \t r\xB2 = %8.4f \n',model(cont).FOMcal.RMSE,model(cont).FOMcal.r2)
    % FOM valida��o cruzada
    ypcv = saidaCV(:,VL);
    model(cont).ypcv = ypcv;
    model(cont).FOMcv = fom(y_treina,ypcv);
    fprintf('RMSECV = %8.4f \t r\xB2 = %8.4f\n',model(cont).FOMcv.RMSE,model(cont).FOMcv.r2)
    % FOM previs�o
    if ~isempty(am_teste)
        yp_teste = [ones(size(x_teste,1),1) x_teste]*beta;
        model(cont).FOMprev = fom(y_teste,yp_teste);
        fprintf('RMSEP  = %8.4f \t r\xB2 = %8.4f \n',model(cont).FOMprev.RMSE,model(cont).FOMprev.r2)
    end
    % Salva o modelo
    model(cont).xl = xl;
    model(cont).yl = yl;
    model(cont).xscal = xs;
    model(cont).ys = ys;
    model(cont).beta = beta;
    model(cont).stats = stats;
    % Gr�ficos de performance
    fprintf('\n')
    op = input('Deseja plotar as respostas do PLSR? (0) N�o (1) Sim ');
    if op == 1
        if ~isempty(am_teste)
            graf_out = pls_reg_graf(model(cont).FOMcal.amostras,y_treina,yp_treina,y_teste,yp_teste);
        else
            graf_out = pls_reg_graf(model(cont).FOMcal.amostras,y_treina,ypcv,[],[]);
        end
        model(cont).graf_perf = graf_out;
    end
    % Loop de retorno
    fprintf('\n')
    op = input('Deseja construir outro modelo? (0) N�o (1) Sim ');
    fprintf('\n')
    cont = cont + 1;
end
