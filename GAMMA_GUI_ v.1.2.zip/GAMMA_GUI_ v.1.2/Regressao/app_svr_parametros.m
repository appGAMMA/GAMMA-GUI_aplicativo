%% Cria uma tabela com os parâmetros da SVR
% Versão: 28/04/2023
function app_svr_parametros(tipo,kernel,app)
%% Cria os valores iniciais da tabela
lista{1} = 'C';
valor(1) = 1;
otm(1) = 0;
vmin(1) = 1;
vmax(1) = 100;
switch tipo
    case 'epsilon-SVR'
        lista{2} = 'Epsilon';
        valor(2) = 0.1;
        otm(2) = 0;
        vmin(2) = 0.001;
        vmax(2) = 0.1;
    case 'nu-SVR'
        lista{2} = 'Nu';
        valor(2) = 0.5;
        otm(2) = 0;
        vmin(2) = 0.1;
        vmax(2) = 0.9;
end
switch kernel
    case 'polinomial'
        lista{3} = 'Gamma';
        valor(3) = 0.1;
        otm(3) = 0;
        vmin(3) = 0.00001;
        vmax(3) = 0.1;
        lista{4} = 'Intercepto';
        valor(4) = 0;
        otm(4) = 0;
        vmin(4) = -1;
        vmax(4) = 1;
        lista{5} = 'Grau';
        valor(5) = 3;
        otm(5) = 0;
        vmin(5) = 2;
        vmax(5) = 5;
    case 'base radial'
        lista{3} = 'Gamma';
        valor(3) = 0.1;
        otm(3) = 0;
        vmin(3) = 0.0001;
        vmax(3) = 0.1;
    case 'sigmoide'
        lista{3} = 'Gamma';
        valor(3) = 0.1;
        otm(3) = 0;
        vmin(3) = 0.00001;
        vmax(3) = 0.1;
        lista{4} = 'Intercepto';
        valor(4) = 0;
        otm(4) = 0;
        vmin(4) = -1;
        vmax(4) = 1;
end
%% Criação da janela gráfica
texto = ['Parâmetros - ' tipo ' - ' kernel];
pos = [300 200 450 300];
fig = uifigure('Name',texto,'Position',pos);
% Tabela de dados
uit = uitable(fig,'Position',[10 50 pos(3)-20 pos(4)-70]);
uit.ColumnName = {'Parâmetro';'Valor';'Otimizar';'Mínimo';'Máximo'}; 
uit.ColumnEditable = [false true true true true]; % habilita a edição nas colunas
uit.ColumnFormat = {[] [] 'logical' [] []};
nparam = length(lista);
dados = cell(nparam,5);
for ii = 1:nparam
    dados{ii,1} = lista{ii};
    dados{ii,2} = valor(ii);
    dados{ii,3} = otm(ii);
    dados{ii,4} = vmin(ii);
    dados{ii,5} = vmax(ii);
end
uit.Data = dados;
% Criar o botão de leitura dos dados
btn = uibutton(fig,'Position',[pos(3)/2-50 10 100 30],'Text','Salvar','ButtonPushedFcn', @(btn,event) salva_param(btn,fig,uit,app));
end
%% Saída dos valores alterados pelo usuário
function salva_param(~,fig,uit,app) 
dados = uit.Data;
delete(fig)
nparam = size(dados,1);
lista = cell(nparam,1);
valor = zeros(nparam,1);
otm = zeros(nparam,1);
vmin = zeros(nparam,1);
vmax = zeros(nparam,1);
for ii = 1:nparam
    lista{ii} = dados{ii,1};
    valor(ii) = dados{ii,2};
    otm(ii) = dados{ii,3};
    vmin(ii) = dados{ii,4};
    vmax(ii) = dados{ii,5};
end
saida.parametros = lista;
saida.valor = valor;
saida.otimizar = otm;
saida.minimo = vmin;
saida.maximo = vmax;
app.param = saida;
end