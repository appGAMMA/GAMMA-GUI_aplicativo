function fom = fom(ref,estm)
%% Vers�o: 09/05/2023
% Calcula as figuras de m�rito para regress�o
%
% Entradas:
%        ref= valores de refer�ncia
%        estm = valores estimados
%
% Saidas:variavel estruturada fom
%           amostras = quantidade de amostras avaliadas
%           raw_residual = res�duos crus
%           RMSE = raiz quadrada do erro quadr�tico m�dio
%           RPD = desvio residual da previs�o
%           MAE = erro absoluto m�dio
%           RSD = realtive standard deviation
%           bias = bias ASTM E1655
%           sdv = desvio padr�o dos res�duos de previs�o
%           t_bias = valor do teste t para o bias
%           p_bias = probabilidade para o teste t do bias
%           r2 = coeficiente de correla��o ao quadrado
%%------------------------------------------------------------------------------------------------
%% Amostras
[L1,~] = size(ref);
fom.amostras = L1;
%% Res�duos crus
res = ref - estm;
fom.raw_residual = res;
%% RMSE
rmse = sqrt((res'*res)/L1);
fom.RMSE = rmse;
%% RPD
rpd = std(ref)/rmse;
fom.rpd = rpd;
%% MAE
dsvab = mean(abs(res));
fom.mae = dsvab;
%% RSD
fom.RSD = 100*rmse/mean(ref);
%% Bias
bias = sum(res)/L1;
sdv = sqrt(sum((res - bias).^2)/(L1-1)); 
tbias = (abs(bias)*sqrt(L1))/sdv;
pbias = (1 - tcdf(tbias,L1))*2;
fom.bias = bias;
fom.sdv = sdv;
fom.t_bias = tbias;
fom.p_bias = pbias;
%% r2
r2 = (corrcoef(ref,estm));
r2 = r2(2,1).^2;
fom.r2 = r2;
