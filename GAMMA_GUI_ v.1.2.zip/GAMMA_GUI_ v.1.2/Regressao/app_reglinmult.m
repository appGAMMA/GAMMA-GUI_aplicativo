%% Regressão linear múltipla - APP
% Versão: 30/05/2023
function saida = app_reglinmult(X,y,eq)
saida.X = X;
saida.y = y;
saida.equacao = eq;
%% Regressão
modelo = fitlm(X,y,eq);
saida.modelo = modelo;
%% ANOVA
ANOVAmodelo = anova(modelo,'summary');

% Correção dos graus de liberdade para o modelo de misturas
if contains(eq,'-1')
    temp = ANOVAmodelo{:,:};
    temp(1,2) = temp(1,2) - 1;
    temp(2,2) = temp(2,2) - 1;
    temp(1,3) = temp(1,1)/temp(1,2);
    temp(2,3) = temp(2,1)/temp(2,2);
    temp(2,4) = temp(2,3)/temp(5,3);
    temp(2,5) = 1 - fcdf(temp(2,4),temp(2,2),temp(5,2));
    T = array2table(temp,'VariableNames',ANOVAmodelo.Properties.VariableNames,'RowNames',ANOVAmodelo.Properties.RowNames);
    ANOVAmodelo = T;
end

ANOVAefeitos = anova(modelo);
saida.ANOVAmodelo = ANOVAmodelo;
saida.ANOVAefeitos = ANOVAefeitos;
%% Desvio relativo
res = -1*modelo.Residuals{:,1};
desvio = 100*res./y;
saida.desvio = desvio;
%% Figuras de mérito analíticas
