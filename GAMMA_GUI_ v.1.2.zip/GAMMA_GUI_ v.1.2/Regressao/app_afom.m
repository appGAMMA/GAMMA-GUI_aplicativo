%% Figuras de m�rito anal�ticas para modelos PLS
%% Vers�o: 30/03/2023
function saida = app_afom(model)
%% Recupera��o dos dados do modelo
Xcal = model.xcal;
Xtest = model.xprev;
[J,I] = size(Xcal);
Xcalres = model.stats.Xresiduals;
Ycalres = model.stats.Yresiduals;
bk = model.beta(2:end);
%bk = model.beta;
w = model.stats.W;
T = model.xs;
ycal = model.ycal;
%% Vari�ncias
rescal = norm(Xcalres(:))/sqrt(J*I);
rescon = norm(Ycalres(:))/sqrt(J-1);
%% Sensibilidade
sen = 1/norm(bk);
analsen = sen/rescal;
saida.SEN = sen;
saida.AnalSEN = analsen;
%% LOD e LOQ
Tt = Xtest*w;
lever = Tt*pinv(T);
ntest = size(Xtest,1);
sdt = zeros(ntest,1);
for ii = 1:ntest
    ht = norm(lever(ii,:))^2;
    sdt(ii) = sqrt(rescal^2*(1 + ht)/sen^2 + ht*rescon^2);
end
meanycal = mean(ycal);
huni = meanycal^2/norm(ycal)^2;
hcal0 = zeros(1,J);
for ii = 1:J
    hcal = norm(pinv(T')*T(ii,:)')^2;
    hcal0(ii) = hcal + huni*(1 - (ycal(ii)/meanycal).^2);
end
hmax = 1/J + max(hcal0);
hmin = 1/J + huni;
LODmin = 3.3*sqrt(rescal^2*(1 + hmin)/sen^2 + hmin*rescon^2);
LODmax = 3.3*sqrt(rescal^2*(1 + hmax)/sen^2 + hmax*rescon^2);
LOQmin = 3*LODmin;
LOQmax = 3*LODmax;
saida.LODmin = LODmin;
saida.LODmax = LODmax;
saida.LOQmin = LOQmin;
saida.LOQmax = LOQmax;