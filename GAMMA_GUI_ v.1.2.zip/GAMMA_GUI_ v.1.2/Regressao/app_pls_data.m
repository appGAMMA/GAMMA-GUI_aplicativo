%% PLS usando as rotinas do MATLAB - app
% Vers�o: 05/04/2023
function model = app_pls_data(x,y,normaliza,am_treina,am_teste,nvl)
model = struct;
model.x = x;
model.y = y;
model.Cal = am_treina;
model.Pred = am_teste;
%% Dados
x_treina = x(am_treina,:);
y_treina = y(am_treina);
if ~isempty(am_teste)
    x_teste = x(am_teste,:);
    y_teste = y(am_teste);
else
    x_teste = [];
    y_teste = [];
end
%% Normaliza��o
% Conjunto de calibra��o
norma_cal = app_normaliza(x_treina,normaliza);
model.normaliza = norma_cal;
x_treina = norma_cal.x;
% Conjunto de teste
if ~isempty(am_teste)
    norma_prev = app_normaliza(x_teste,normaliza,norma_cal);
    x_teste = norma_prev.x;
end
model.xcal = x_treina;
model.ycal = y_treina;
model.xprev = x_teste;
model.yprev = y_teste;
%% Detec��o de outliers
outliers = app_pls_outliers(x_treina,x_teste,y_treina,nvl);
% corre��o dos outliers para a numera��o geral das amostras
outliers.outliers_cal = am_treina(outliers.outliers_cal);
if ~isempty(am_teste)
    outliers.outliers_pred = am_teste(outliers.outliers_pred);
end
model.outliers = outliers;
%% Constru��o do modelo
model.VLs = nvl;
[xl,yl,xs,ys,beta,pctvar,~,stats] = plsregress(x_treina,y_treina,nvl);
% Vari�ncia acumulada
temp = sum(pctvar,2);
varx = temp(1);
vary = temp(2);
%% Armazenamento do modelo
model.xl = xl;
model.yl = yl;
model.xs = xs;
model.ys = ys;
model.beta = beta;
model.pctvar = pctvar;
model.varX = varx;
model.varY = vary;
model.stats = stats;
%% Figuras de m�rito
% FOM anal�ticas
if ~isempty(am_teste)
    model.AFOM = app_afom(model);
end
% Estat�sticas de calibra��o
yp_treina = [ones(size(x_treina,1),1) x_treina]*beta;
model.ypcal = yp_treina;
model.STATcal = fom(y_treina,yp_treina);
% Estat�sticas de previs�o
if ~isempty(am_teste)
    yp_teste = [ones(size(x_teste,1),1) x_teste]*beta;
    model.ypteste = yp_teste;
    model.STATprev = fom(y_teste,yp_teste);
end