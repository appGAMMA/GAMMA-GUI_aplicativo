function elp_conf(X,Y,alfa,tit)
%% Gr�fico da elipse de confian�a
%% Vers�o: 01/11/2016

% Quantidade de amostras
Iv=size(X,1);

% Regress�o linear
R=[Iv, sum(X);sum(X), sum(X.^2)]; % X'X
f=[sum(Y),sum(X.*Y)]'; % X'Y
b=inv(R)*f;
    
% m (inclina��o) e n (intercepto) 
m=b(2);
n=b(1);
sfit=sqrt(sum((Y-b(2)*X-b(1)).^2)/(Iv-2)); % Desvio padr�o da estimativa
  
iR=inv(R);
% sm y sn son los desvios est!ndar en pendiente y ordenada
sn=sqrt(iR(1,1))*sfit; % erro padr�o de b1
sm=sqrt(iR(2,2))*sfit; % erro padr�o de b2
   
lc1=tinv(1-alfa/2,Iv-2)*sm; % IC b1
lc2=tinv(1-alfa/2,Iv-2)*sn; % IC b2
    
% a1, b1, c1 y d1 son los parametros de la ecuacion de la elipse
d1 = 2*sfit^2*finv(1-alfa/2,2,Iv-2);
a1=sum(X.^2);
b1=2*sum(X);
c1=Iv;
   
% Fija los limites de la elipse y calcula las tres columnas para dibujarla
% (el eje x y las dos mitades de la elipse)
limx1=sqrt(4*c1*d1/(-b1^2+4*a1*c1));
step1=2*limx1/100;
xx1=[limx1,limx1-step1:-step1:-limx1+step1,-limx1];
yy11=(-b1*xx1+sqrt(b1^2*xx1.^2-4*(a1*xx1.^2-d1)*c1))/(2*c1);
yy21=(-b1*xx1-sqrt(b1^2*xx1.^2-4*(a1*xx1.^2-d1)*c1))/(2*c1);
elipse=[xx1+m;real(yy11)+n;real(yy21)+n]';

%disp('  ')
%disp(['Pendiente: ',num2str(m),' � ',num2str(lc1),' Desv�o est�ndar: ',num2str(sm)])
%disp(['Ordenada: ',num2str(n),' � ',num2str(lc2),' Desv�o est�ndar: ',num2str(sn)])
%disp('  ')
%rmse=norm(X-Y)/sqrt(Iv);
%disp(['RMSE : ',num2str(rmse)])

% Grafica datos
% figure
% plot(X,Y,'o',[min(X),max(X)],m*[min(X),max(X)]+n,'-')
% title(tit)
% xlabel('Observado')
% ylabel('Previsto')
% legend('Dados','Ajuste',0)

% Grafica elipse
figure
plot(1,0,'+b',elipse(:,1),elipse(:,2),'-r',elipse(:,1),elipse(:,3),'-r')
title(tit)
xlabel('Inclina��o')
ylabel('Intercepto')
legend('Ponto ideal','Elipse')

end