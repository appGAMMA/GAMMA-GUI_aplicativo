%% Previsão usando modelo PLS
% Versão: 05/04/2023
function saida = app_pls_prediction(xprev,model)
saida = struct;
saida.X = xprev;
saida.model = model;
nprev = size(xprev,1);
%% Normalização
normaliza = model.normaliza.tipo;
norm_prev = app_normaliza(xprev,normaliza,model.normaliza);
xprev = norm_prev.x;
%% Previsão
beta = model.beta;
yprev = [ones(nprev,1) xprev]*beta;
saida.Xnorm = xprev;
saida.yprev = yprev;
