%% Treinamento de SVR - versão app
% libsvm 3.3
% Versão: 29/04/2023
function saida = app_treina_svr(model)
%% Transferência e preparação dos dados
saida = model;
tipo = model.tipo;
kernel = model.kernel;
otimiza = logical(model.parametros.otimizar);
v_param = model.parametros.valor;
v_min = model.parametros.minimo;
v_max = model.parametros.maximo;
normaliza = model.normalizacao.tipo;
am_treina = model.Cal;
am_teste = model.Pred;
x = model.X;
y = model.y;
kfold = model.CV.k;
opt_pso = model.PSO.opt;
% Amostragem
x_treina = x(am_treina,:);
y_treina = y(am_treina);
if ~isempty(am_teste)
    x_teste = x(am_teste,:);
    y_teste = y(am_teste);
else
    x_teste = [];
    y_teste = [];
end
% Normalização
% Conjunto de calibração
norma_cal = app_normaliza(x_treina,normaliza);
saida.normalizacao = norma_cal;
x_treina = norma_cal.x;
% Conjunto de teste
if ~isempty(am_teste)
    norma_prev = app_normaliza(x_teste,normaliza,norma_cal);
    x_teste = norma_prev.x;
end
saida.xcal = x_treina;
saida.ycal = y_treina;
saida.xprev = x_teste;
saida.yprev = y_teste;
%% Otimização PSO ou definição dos parâmetros
if sum(otimiza) > 0 % Otimização PSO dos parâmetros escolhidos
    ni = sum(otimiza);
    lb = v_min(otimiza);
    ub = v_max(otimiza);
    [p_otm,fval,~,output] = particleswarm(@(p) app_pso_svr(p,x_treina,y_treina,kfold,tipo,kernel,otimiza,v_param),ni,lb,ub,opt_pso);
    clc
    saida.PSO.p_otm = p_otm;
    saida.PSO.RMSECVmin = fval;
    saida.PSO.output = output;
    % Tipo de SVR
    cont = 1;
    switch tipo
        case 'epsilon-SVR'
            opt = '-s 3';
            if otimiza(1) == 1
                opt = [opt ' -c ' num2str(p_otm(cont))];
                cont = cont + 1;
            else
                opt = [opt ' -c ' num2str(v_param(1))];
            end
            if otimiza(2) == 1
                opt = [opt ' -p ' num2str(p_otm(cont))];
                cont = cont + 1;
            else
                opt = [opt ' -p ' num2str(v_param(2))];
            end
        case 'nu-SVR'
            opt = '-s 4';
            if otimiza(1) == 1
                opt = [opt ' -c ' num2str(p_otm(cont))];
                cont = cont + 1;
            else
                opt = [opt ' -c ' num2str(v_param(1))];
            end
            if otimiza(2) == 1
                opt = [opt ' -n ' num2str(p_otm(cont))];
                cont = cont + 1;
            else
                opt = [opt ' -n ' num2str(v_param(2))];
            end
    end
    % Tipo de kernel
    switch kernel
        case 'linear'
            opt = [opt ' -t 0 -q'];
        case 'polinomial'
            opt = [opt ' -t 1'];
            if otimiza(3) == 1
                opt = [opt ' -g ' num2str(p_otm(cont))];
                cont = cont + 1;
            else
                opt = [opt ' -g ' num2str(v_param(3))];
            end
            if otimiza(4) == 1
                opt = [opt ' -r ' num2str(p_otm(cont))];
                cont = cont + 1;
            else
                opt = [opt ' -r ' num2str(v_param(4))];
            end
            if otimiza(5) == 1
                opt = [opt ' -d ' num2str(round(p_otm(cont)))];
            else
                opt = [opt ' -d ' num2str(v_param(5))];
            end
            opt = [opt ' -q'];
        case 'base radial'
            opt = [opt ' -t 2'];
            if otimiza(3) == 1
                opt = [opt ' -g ' num2str(p_otm(cont))];
            else
                opt = [opt ' -g ' num2str(v_param(3))];
            end
            opt = [opt ' -q'];
        case 'sigmoide'
            opt = [opt ' -t 3'];
            if otimiza(3) == 1
                opt = [opt ' -g ' num2str(p_otm(cont))];
                cont = cont + 1;
            else
                opt = [opt ' -g ' num2str(v_param(3))];
            end
            if otimiza(4) == 1
                opt = [opt ' -r ' num2str(p_otm(cont))];
            else
                opt = [opt ' -r ' num2str(v_param(4))];
            end
            opt = [opt ' -q'];
    end
else % treina com os parâmetros indicados pelo usuário
    switch model.tipo
        case 'epsilon-SVR'
            opt = ['-s 3 -c ' num2str(v_param(1)) ' -p ' num2str(v_param(2))];
        case 'nu-SVR'
            opt = ['-s 4 -c ' num2str(v_param(1)) ' -n ' num2str(v_param(2))];
    end
    switch model.kernel
        case 'linear'
            opt = [opt ' -t 0 -q'];
        case 'polinomial'
            opt = [opt ' -t 1 -d ' num2str(v_param(5)) ' -g ' num2str(v_param(3)) ' -r ' num2str(v_param(4)) ' -q'];
        case 'base radial'
            opt = [opt ' -t 2 -g ' num2str(v_param(3)) ' -q'];
        case 'sigmoide'
            opt = [opt ' -t 3 -g ' num2str(v_param(3)) ' -r ' num2str(v_param(4)) ' -q'];
    end
end
saida.svr_opt = opt;
%% Validação cruzada
ntreina = length(y_treina);
ypcv = zeros(ntreina,1);
if kfold < ntreina
    % K-fold
    cvidx = crossvalind('Kfold',ntreina,kfold);
else
    % Leave-one-out
    cvidx = 1:ntreina;
end
wb = waitbar(0,'Construindo os modelos...','Name','Validação cruzada');
for kk = 1:kfold  % Loop da validação cruzada
    % Separação das amostras
    idx = cvidx ~= kk;
    xcv_treina = x_treina(idx,:);
    ycv_treina = y_treina(idx,:);
    idx = cvidx == kk;
    xcv_teste = x_treina(idx,:);
    ycv_teste = y_treina(idx);
    svm = svmtrain(ycv_treina,xcv_treina,opt);
    ypcv(idx) = svmpredict(ycv_teste,xcv_teste,svm);
    % Atualização da barra de execução
    waitbar(kk/kfold);
end
close(wb)
clc
% FOM
FOM = fom(y_treina,ypcv);
saida.CV.ypcv = ypcv;
saida.CV.FOMcv = FOM;
%% Calibração
svm = svmtrain(y_treina,x_treina,opt);
ypcal = svmpredict(y_treina,x_treina,svm);
FOM = fom(y_treina,ypcal);
saida.svm = svm;
saida.ypcal = ypcal;
saida.FOMcal = FOM;
%% Previsão
ypprev = svmpredict(y_teste,x_teste,svm);
FOM = fom(y_teste,ypprev);
saida.ypteste = ypprev;
saida.FOMprev = FOM;