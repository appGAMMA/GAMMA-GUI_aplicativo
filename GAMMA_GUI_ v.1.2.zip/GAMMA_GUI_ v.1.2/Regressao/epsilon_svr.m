function model = epsilon_svr(x,y,am_treina,am_teste,opt,kfold)
%% M�quina de vetor suporte para regress�o
% epsilon-SVR
% Rotinas do pacote libsvm 3.2
%% Vers�o: 09/08/2017

yo = y;
ymin = min(yo);
ymax = max(yo);
delta = ymax - ymin;
y = 2*(y - ymin)/delta - 1;


%% Prepara��o dos dados
x = sparse(x);
x_treina = x(am_treina,:);
y_treina = y(am_treina,1);  
x_teste = x(am_teste,:);
y_teste = y(am_teste,1);
acal = size(x_treina,1); % amostras de calibra��o
%% Valida��o cruzada
if kfold < acal
    % K-fold
    cvidx = crossvalind('Kfold',acal,kfold);
else
    % Leave-one-out
    cvidx = 1:acal;
end
ypcv = zeros(acal,1);
for kk = 1:kfold  % Loop da valida��o cruzada
    % Separa��o das amostras
    idx = cvidx ~= kk;
    xcv_treina = x_treina(idx,:);
    ycv_treina = y_treina(idx);
    idx = cvidx == kk;
    xcv_teste = x_treina(idx,:);
    ycv_teste = y_treina(idx);
    svr = svmtrain(ycv_treina,xcv_treina,opt);
    ypcv(idx,:) = svmpredict(ycv_teste,xcv_teste,svr);
    clc
end

ypcv = ((ypcv + 1)/2)*delta + ymin;
y_treina = ((y_treina + 1)/2)*delta + ymin;
%fom_cv = fom(yo,ypcv);

model.yp_cv = ypcv;
% FOM CV
fom_cv = fom(y_treina,ypcv);
model.fom_cv = fom_cv;
y_treina = 2*(y_treina - ymin)/delta - 1;
%% Calibra��o
svr = svmtrain(y_treina,x_treina,opt);
model.svr = svr;
yp_treina = svmpredict(y_treina,x_treina,svr);
yp_treina = ((yp_treina + 1)/2)*delta + ymin;
y_treina = ((y_treina + 1)/2)*delta + ymin;
model.yp_cal = yp_treina;
% FOM calibra��o
fom_cal = fom(y_treina,yp_treina);
model.fom_cal = fom_cal;
%% Previs�o
if ~isempty(am_teste)
    yp_teste = svmpredict(y_teste,x_teste,svr);
    yp_teste = ((yp_teste + 1)/2)*delta + ymin;
    y_teste = ((y_teste + 1)/2)*delta + ymin;
    model.yp_prev = yp_teste;
    % FOM previs�o
    fom_prev = fom(y_teste,yp_teste);
    model.fom_prev = fom_prev;
end
%% Gr�ficos de performance
fprintf('\n')
op = input('Deseja plotar as respostas do SVR? (0) N�o (1) Sim ');
if op == 1
    if ~isempty(am_teste)
        graf_out = svm_reg_graf(svr,acal,y_treina,yp_treina,y_teste,yp_teste);
    else
        graf_out = svm_reg_graf(svr,acal,y_treina,ypcv,[],[]);
    end
    model.graf_perf = graf_out;
end
