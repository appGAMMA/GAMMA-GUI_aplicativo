function model = app_pls_cv(x,y,normaliza,am_treina,nvl,kfold)
%% Valida��o cruzada para PLS usando as rotinas do MATLAB - appGAMMA
%% Vers�o: 28/04/2023
% Valida��o cruzada: leave-one-out ou k-fold
%% Par�metros do algoritmo
ntreina = length(am_treina); % quantidade de amostras de valida��o
model = struct;
%% Dados
% Calibra��o
x_treina = x(am_treina,:);
y_treina = y(am_treina,:);
%% Normaliza��o
norma_cv = app_normaliza(x_treina,normaliza);
x_treina = norma_cv.x;
model.Xcal = x_treina;
model.Ycal = y_treina;
model.normaliza = normaliza;
%% Defini��o da quantidade de VL
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
cont = 0;
saidaCV = zeros(ntreina,nvl);
RMSECV = zeros(nvl,1);
r2 = zeros(nvl,1);
for jj = 1:nvl % Loop das vari�veis latentes
    ycv = zeros(size(y_treina));
    % Valida��o cruzada
    if kfold < ntreina
        % K-fold
        cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
        model.metodo = 'k-fold';
        model.k = kfold;
    else
        % Leave-one-out
        cvidx = 1:ntreina;
        model.metodo = 'leave-one-out';
    end
    for kk = 1:kfold  % Loop da valida��o cruzada
        % Separa��o das amostras
        idx = cvidx ~= kk;
        xcv_treina = x_treina(idx,:);
        ycv_treina = y_treina(idx,:);
        idx = cvidx == kk;
        xcv_teste = x_treina(idx,:);
        [~,~,~,~,beta,pctvar] = plsregress(xcv_treina,ycv_treina,jj);
        ycv(idx,:) = [ones(size(xcv_teste,1),1) xcv_teste]*beta;
        % Atualiza��o da barra de execu��o
        cont = cont + 1;
        waitbar(cont/(nvl*kfold));
    end
    % FOM
    FOM = fom(y_treina,ycv);
    saidaCV(:,jj) = ycv;
    RMSECV(jj) = FOM.RMSE;
    r2(jj) = FOM.r2;
end
model.NVLS = 1:nvl;
model.RMSECV = RMSECV;
model.r2_cv = r2;
model.var_acum = pctvar;
close(wb)
%% Gr�ficos para RMSECV e r2
figure
subplot(1,2,1)
plot(1:nvl,cumsum(100*pctvar(1,:)),'-bo','LineWidth',2)
hold on
plot(1:nvl,cumsum(100*pctvar(2,:)),'-ro','LineWidth',2)
axis tight
%set(gca,'FontSize',10,'FontWeight','bold')
grid on
xlabel('Vari�veis latentes')
ylabel('Vari�ncia acumulada (%)')
legend('X','Y','Location','best')
title(model.metodo);
subplot(1,2,2)
yyaxis left
plot(1:nvl,RMSECV,'-bo','linewidth',2)
axis("tight")
ylabel('RMSECV')
xlabel('Vari�veis latentes')
yyaxis right
plot(1:nvl,r2,'-ro','LineWidth',2)
ylabel('r^{2}')
legend('RMSECV','r^{2}','Location','best')
grid on
title(model.metodo)