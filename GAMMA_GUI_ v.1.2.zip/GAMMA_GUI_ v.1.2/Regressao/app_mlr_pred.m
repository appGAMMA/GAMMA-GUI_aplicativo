%% Previsão usando modelo de regressão linear múltipla - APP
% Versão: 03/06/2021
function saida = app_mlr_pred(modelo,xnew,alfa)
saida.modelo = modelo;
saida.Xprev = xnew;
saida.alfa = alfa;
[yprev,yic] = predict(modelo,xnew,'Alpha',alfa);
saida.yPrev = yprev;
saida.yIC = yic;