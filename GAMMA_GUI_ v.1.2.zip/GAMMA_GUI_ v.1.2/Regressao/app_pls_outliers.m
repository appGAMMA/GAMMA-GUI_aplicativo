function saida = app_pls_outliers(Xcal,Xpred,Ycal,nvl)
%% Identifica��o de outliers
% Vers�o: 26/03/2023
% Gr�fico de T2 vs Q
%% Par�metros
lev_conf = 0.95;
nams = size(Xcal,1);
nteste = size(Xpred,1);
%% Ajuste do modelo
% T: scores de X
% P: loadings de X
[P,~,T,~,~,~,~,stats] = plsregress(Xcal,Ycal,nvl);
Qcont = stats.Xresiduals;
% Amostras de previs�o
if ~isempty(Xpred)
    Tp = Xpred/P';
    Xp = Tp*P';
    Qcont_p = Xpred - Xp;
end
%% T2
fvar = sqrt(1./(diag(T'*T)/(size(Xcal,1) - 1)));
T2 = sum((T*diag(fvar)).^2,2);
if ~isempty(Xpred)
    T2p = sum((Tp*diag(fvar)).^2,2);
end
% T2 cr�tico
F = finv(lev_conf,nvl,nams-nvl);
tlim = (nvl*(nams - 1)/(nams - nvl))*F;
%% Q
% Calibra��o
Qres = zeros(nams,1);
for ii = 1:nams
    Qres(ii) = Qcont(ii,:)*Qcont(ii,:)';
end
% Previs�o
if ~isempty(Xpred)
    Qres_p = zeros(nteste,1);
    for ii = 1:nteste
        Qres_p(ii) = Qcont_p(ii,:)*Qcont_p(ii,:)';
    end
end
% Q cr�tico
s = svd(Qcont');
s = s.^2/(nams - 1);
Qcont = s;
[m,n] = size(Qcont);
if n > m
    s = s';
    m   = n;
end
Qcont=s;
t1 = sum(Qcont(0+1:m,1));
t2 = sum(Qcont(0+1:m,1).^2);
t3 = sum(Qcont(0+1:m,1).^3);
ho = 1 - 2*t1*t3/3/(t2.^2);
if ho < 0.001
    ho = 0.001;
end
ca = sqrt(2)*erfinv(2*lev_conf - 1);
term1    = ca*sqrt(2*t2*ho.^2)/t1;
term2    = t2*ho*(ho-1)/(t1.^2);
qlim = t1*(1+term1+term2).^(1/ho);
%% Identifica��o dos outliers
% Calibra��o
outliers_Q = find(Qres >= qlim);
outliers_T2 = find(T2 >= tlim);
a = ismember(outliers_Q,outliers_T2);
outliers_cal = outliers_Q(a);
% Previs�o
if ~isempty(Xpred)
    outliers_Q = find(Qres_p >= qlim);
    outliers_T2 = find(T2p >= tlim);
    a = ismember(outliers_Q,outliers_T2);
    outliers_pred = outliers_Q(a);
end
%% Sa�da
saida.Tcrit = tlim;
saida.Qcrit = qlim;
saida.T2cal = T2;
saida.Qcal = Qres;
saida.outliers_cal = outliers_cal;
if ~isempty(Xpred)
    saida.outliers_pred = outliers_pred;
    saida.T2pred = T2p;
    saida.Qpred = Qres_p;
end
