function model = epsilon_svr_feature(x,y,am_treina,am_teste,opt)
%% epsilon-SVR com sele��o de vari�veis
% Rotinas do pacote libsvm 3.2
%% Vers�o: 01/11/2016
%% Prepara��o dos dados
% Normaliza��o [-1 1]
% Tem que ser esparso para a LIBSVM
%x = sparse(mapminmax(x',-1,1)'); 
x = sparse(x);
x_treina = x(am_treina,:);
y_treina = y(am_treina,1);  
x_teste = x(am_teste,:);
y_teste = y(am_teste,1);
%% Vetor informativo
% Usa apenas as amostras de calibra��o
disp('Vetores informativos dispon�veis')
disp('  (0) Correla��o entre X e y')
disp('  (1) Covari�ncia entre X e y')
disp('  (2) Vetor sinal-ru�do')
op = input('Escolha uma op��o: ');
fprintf('\n')
switch op
    case 0
        info_vec = corr_vec(x_treina,y_treina);
    case 1
        info_vec = cov_vec(x_treina,y_treina);
    case 2
        info_vec = sr_vec(x_treina,y_treina);
    otherwise
        disp('Op��o inv�lida!')
end
%% Ordena��o das vari�veis usando o vetor informativo
[~,ordem] = sort(abs(info_vec.dados),'descend');
info_vec.ordem = ordem;
model.info_vec = info_vec;
%% Sele��o de vari�veis
min_v = input('Quantidade m�nima de vari�veis: ');
step_v = input('Incremento: ');
fprintf('\n')
nv = size(x_treina,2);
cont = 1;
opt2 = [opt ' -v 10 -q'];
for ii = min_v:step_v:nv
    x = x_treina(:,ordem(1:ii));
    msecv = svmtrain(y_treina,x,opt2);
    nvar(cont) = ii;
    rmsecv(cont) = sqrt(msecv);
    cont = cont + 1;
end
figure
plot(nvar,rmsecv,'-bo')
xlabel('Vari�veis utilizadas')
ylabel('RMSECV')
% Marca��o do ponto de m�nimo
[mv,idx] = min(rmsecv);
hold on
xg = xlim;
yg = [mv mv];
line(xg,yg,'LineStyle',':','Color','r','LineWidth',1) % Linha horizontal
xg = [nvar(idx) nvar(idx)];
yg = ylim;
line(xg,yg,'LineStyle',':','Color','r','LineWidth',1) % Linha vertical
hold off
model.rmsecv(1,:) = nvar;
model.rmsecv(2,:) = rmsecv;
%% Constru��o dos modelos com as vari�veis selecionadas
op = 1;
cont = 1;
while op == 1
    fprintf('\n')
    nv = input('Vari�veis utilizadas: ');
    model(cont).nvar = nv;
    % Marca��o das vari�veis selecionadas
    x = x_treina(:,ordem(1:nv));
    model(cont).feat_sel = zeros(size(x_treina,2),1);
    model(cont).feat_sel(ordem(1:nv)) = 1;
    % Treinamento
    model(cont).x_treina = x;
    svr = svmtrain(y_treina,x,opt);
    model(cont).svr = svr;
    yp_treina = svmpredict(y_treina,x,svr);
    model(cont).yp_cal = yp_treina;
    % Previs�o
    xt = x_teste(:,ordem(1:nv));
    model(cont).x_teste = xt;
    yp_teste = svmpredict(y_teste,xt,svr);
    model(cont).yp_prev = yp_teste;
    % FOM
    fom_cal = fom(y_treina,yp_treina);
    model(cont).fom_cal = fom_cal;
    fom_prev = fom(y_teste,yp_teste);
    model(cont).fom_prev = fom_prev;
    % Resumo na tela
    idx = find(nvar == nv);
    fprintf('\n')
    fprintf('RMSECV = %8.4f \n',model(1).rmsecv(2,idx))
    fprintf('RMSEC = %8.4f \t r\xB2 = %8.4f \n',model(cont).fom_cal.RMSE,model(cont).fom_cal.r2)
    fprintf('RMSEP = %8.4f \t r\xB2 = %8.4f \n',model(cont).fom_prev.RMSE,model(cont).fom_prev.r2)
    % Gr�ficos de performance
    graf_out = svm_reg_graf(svr,model(cont).fom_cal.amostras,y_treina,yp_treina,y_teste,yp_teste);
    model(cont).graf_perf = graf_out;
    fprintf('\n')
    op = input('Deseja construir outro modelo? (0) N�o (1) Sim ');
    cont = cont + 1;
end
