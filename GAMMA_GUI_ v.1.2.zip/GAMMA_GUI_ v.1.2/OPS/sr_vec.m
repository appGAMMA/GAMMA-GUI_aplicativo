function info_vec = sr_vec(x,y)
%% Vetor de sinal-ru�do
%% Vers�o: 23/10/2016
info_vec.tipo = 'Vetor de sinal-ru�do';
%% Vetor de sinal-ru�do
[lin,col] = size(x);
dados = zeros(col,1);
for ii = 1:col
    if abs(sum(x(:,ii))) > 1e-10 % Evita fazer o c�lculo para colunas nulas
        xj = [ones(lin,1) x(:,ii)];
        b = xj\y;
        e = y - xj*b;
        dados(ii) = b(2)/(e'*e);
    end
end
info_vec.dados = dados;