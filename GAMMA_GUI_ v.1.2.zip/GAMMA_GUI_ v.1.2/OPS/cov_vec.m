function info_vec = cov_vec(x,y)
%% Vetor de covari�ncia entre X e y
%% Vers�o: 22/10/2016
info_vec.tipo = 'Vetor de covari�ncia';
%% Vetor de covari�ncia
dados = diag(x'*(y*y')*x);
info_vec.dados = dados;