function info_vec = corr_vec(x,y)
%% Vetor de correla��o entre X e y
%% Vers�o: 22/10/2016
info_vec.tipo = 'Vetor de correla��o';
%% Autoescalamento
% Autoescalamento de X
[lin,col] = size(x);
xm = mean(x);
x0 = x - ones(lin,1)*xm;
xdp = std(x);
xa = zeros(lin,col);
for ii = 1:col
    xa(:,ii) = x0(:,ii)./xdp(ii);
end
% Autoescalamento de y
ym = mean(y);
y0 = y - ones(lin,1)*ym;
ydp = std(y);
ya = y0/ydp;
%% Vetor de correla��o
dados = (xa'*ya)/(lin - 1);
% Corre��o para NaN
masc = isnan(dados);
dados(masc) = 0;
info_vec.dados = dados;