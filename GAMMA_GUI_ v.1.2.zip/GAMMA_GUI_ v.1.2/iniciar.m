%% Conjunto de rotinas para an�lise multivariada
%% Vers�o: 25/02/2022
%% Di�logo inicial
clc
fprintf('GAMMA - ROTINAS PARA AN�LISE MULTIVARIADA \n')
fprintf('Para obter ajuda ler o arquivo info.txt \n')
fprintf('Desenvolvido por Evandro Bona - Vers�o: 25/02/2022 \n')
fprintf('\n')
fprintf('Visualiza��o e manipula��o dos dados \n')
fprintf('   (1)  Plotar dados      \t (2)  Apagar amostras\n')
fprintf('   (3)  Cortar o espectro \t (4)  Sele��o de amostras\n')
fprintf('\n')
fprintf('Prepara��o dos dados \n')
fprintf('   (5)  Alisamento         \t (6)  Corre��o de linha base \n')
fprintf('   (7)  Corre��o de sinal  \t (8)  Normaliza��o das amostras \n')
fprintf('   (9)  Corre��o de drifts \t (10) Normaliza��o das vari�veis \n')
fprintf('\n')
fprintf('An�lise Explorat�ria \n')
fprintf('   (11) Estat�sticas descritivas por grupo \t (12) Componentes principais (PCA)\n')
fprintf('   (13) An�lise hier�rquica (HCA)          \t (14) An�lise de dimens�es comuns (ComDim)\n')
fprintf('   (15) Path-ComDim                        \t (16) Mapas Auto-organiz�veis (SOM) \n')
fprintf('\n')
fprintf('Regress�o Multivariada \n')
fprintf('   (17) Regress�o linear m�ltipla (MLR) \t (18) Quadrados m�nimos parciais (PLSR) \n')
fprintf('   (19) M�quina de vetor suporte (\x03B5-SVR) \t (20) Extreme learning regression (ELR) \n')
fprintf('\n')
fprintf('M�todos de Classifica��o Supervisionada \n')
fprintf('   (21) An�lise discriminante pelo m�todo PLS (PLSDA) \n')
fprintf('   (22) M�quina de vetor suporte (C-SVC) \t (23) Mistura de gaussianas (GMM) \n')
fprintf('   (24) Regress�o log�stica (LR)         \t (25) An�lise discriminante linear (LDA) \n')
fprintf('   (26) Extreme learning classification (ELC) \n')
fprintf('\n')
%% Op��o escolhida
op = input('Escolha uma op��o ou zero (0) para sair: ');
clc
switch op
    case 0 % Sair
        disp('GAMMA finalizado!')
    case 1 % Plotar dados
        fprintf('Plotar dados \n')
        fprintf('\n')
        xxx = input('Matriz com os dados (amostras x vari�veis): ');
        www = input('Faixa de aquisi��o das vari�veis (opcional): ');
        fprintf('\n')
        disp('Plotar')
        disp('  (0) Dados')
        disp('  (1) Vetor informativo')
        disp('  (2) Bandas selecionadas')
        op2 = input('Escolha uma op��o: ');
        fprintf('\n')
        switch op2
            case 0
                sss = input('C�lula contendo o nome de cada amostra (opcional): ');
                plot_espec(xxx,www,sss,'completo');
            case 1
                sss = input('Estrutura contendo o vetor informativo: ');
                plot_info_vec(xxx,www,sss);
            case 2
                sss = input('Vetor com as bandas selecionadas: ');
                plot_bandas(xxx,www,sss);
            otherwise
                disp('Op��o inv�lida!')
        end
        clear www sss op2
    case 2 % Apagar as amostras
        fprintf('Apagar amostras \n')
        fprintf('\n')
        xxx = input('Matriz X com os dados: ');
        sss = input('C�lula contendo o nome de cada amostra: ');
        y = input('Vetor/Matriz de respostas (para ignorar deixa em branco): ');
        fprintf('\n')
        idx = isempty(y);
        if idx == 1
            del_out = del_sample(xxx,sss);
        else
            del_out = del_sample(xxx,sss,y);
        end
        if idx == 0
            clear y
        end
        clear idx sss
    case 3 % Cortar espectros
        fprintf('Recortar espectros \n')
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        www = input('Vetor com a faixa de aquisi��o dos espectros: ');
        fprintf('\n')
        cut_out = cut_espec(xxx,www);
        clear www
    case 4 % Kenston
        fprintf('Sele��o de amostras \n')
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        pt = input('Percentual de amostras para treinamento (0 - 100): ');
        op = input('Fazer a sele��o entre: (0) todas as amostras (1) por classe ');
        op2 = input('Mostrar gr�ficos: (0) N�o (1) Sim ');
        if op == 0
            fprintf('\n')
            kenston_out = split_data(op2,xxx,pt);
        elseif op == 1
            sss = input('C�lula contendo o nome de cada amostra: ');
            fprintf('\n')
            kenston_out = split_data(op2,xxx,pt,sss);
            clear sss
        else
            disp('Op��o inv�lida!')
        end
        clear pt op2
    case 5 % Alisamento
        fprintf('Alisamento \n')
        fprintf('\n')
        xxx = input('Matriz com os espectros: ');
        fprintf('\n')
        alisa_out = alisa_espec(xxx);
    case 6 % corre��o de linha de base
        fprintf('Corre��o de linha base \n')
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        www = input('Vetor com a faixa de aquisi��o dos espectros: ');
        fprintf('\n')
        base_out = baseline_espec(xxx,www);
        clear www
    case 7 % Corre��o de sinal
        fprintf('Corre��o de sinal \n')
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        fprintf('\n')
        op = input('Escolha uma op��o: (1) MSC (2) SNV (3) OSC (4) OPLS ');
        fprintf('\n')
        if op == 3 || op == 4
            yyy = input('Vetor y: ');
            s_cal = input('Amostras de calibra��o: ');
            s_val = input('Amostras de previs�o: ');
        else
            yyy = [];
            s_cal = [];
            s_val = [];
        end
        cms_out = corr_multip_espec(op,xxx,yyy,s_cal,s_val);
        clear yyy s_cal s_val
    case 8 % normaliza��o das amostras
        fprintf('Normaliza��o das amostras \n')
        fprintf('\n')
        yyy = input('Matriz com os dados: ');
        fprintf('\n')
        op2 = input('Escolha uma op��o: (0) norma infinita (1) norma um (2) norma dois (3) �rea unit�ria ');
        fprintf('\n')
        if op2 == 3
            xxx = input('Vetor com a faixa de aquisi��o do sinal (opcional): ');
            fprintf('\n')
        else
            xxx = 0;
        end
        normaams_out = normal_espec(op2,yyy,xxx);
        clear op2 yyy
    case 9
        disp('Em desenvolvimento!')
    case 10 % Normaliza��o das vari�veis
        fprintf('Normaliza��o das vari�veis \n');
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        fprintf('\n')
        normavar_out = normal_var(xxx);
    case 11 % Estat�sticas descritivas por grupo
        fprintf('Estat�sticas descritivas por grupo \n')
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        sss = input('C�lula contendo o grupo de cada amostra: ');
        www = input('C�lula contendo o nome das vari�veis (opcional): ');
        fprintf('\n')
        stat_out = estatistica_grupo(xxx,sss,www);
        clear sss www
    case 12 % PCA
        fprintf('An�lise de componentes principais (PCA) \n')
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        www = input('Faixa de aquisi��o do espectro ou nome das vari�veis (opcional): ');
        sss = input('Nome de cada amostra (opcional): ');
        fprintf('\n')
        pca_out = pca_espec(xxx,www,sss);
        clear www sss
    case 13 % HCA
        fprintf('An�lise hier�rquica (HCA) \n')
        fprintf('\n')
        xxx = input('Matriz com os dados: ');
        sss = input('C�lula contendo o nome de cada amostra (opcional): ');
        fprintf('\n')
        hca_out = hca_data(xxx,sss);
        clear sss
    case 14 % ComDim
        fprintf('An�lise de dimens�es comuns (ComDim) \n')
        fprintf('\n')
        fprintf('Para iniciar escolha: \n')
        fprintf('  (0) Criar uma estrutura de dados e analisar \n')
        fprintf('  (1) Executar a an�lise \n')
        fprintf('  (2) Gr�ficos dos resultados \n')
        op = input('Op��o escolhida: ');
        fprintf('\n')
        switch op
            case 0
                tab = input('Quantidade de tabelas: ');
                fprintf('\n')
                ams = input('Vetor com o nome das amostras (opcional): ');
                fprintf('\n')
                ddd = cell(tab,1);
                var_name = cell(tab,1);
                tab_name = cell(tab,1);
                for ii = 1:tab
                    fprintf('Tabela %3d \n',ii)
                    tab_name{ii} = input('Nome da tabela (opcional): ','s');
                    var_name{ii} = input('Nome das vari�veis (opcional): ');
                    ddd{ii} = input('Dados: ');
                    fprintf('\n')
                end
                data_comdim = str_table(tab,ams,ddd,var_name,tab_name,[]);
                ccs = input('Quantidade de dimens�es comuns: ');
                fprintf('\n')
                comdim_out = ccswa(data_comdim,ccs);
                clear tab ams ddd var_name tab_name ii ccs
            case 1
                xxx = input('Estrutura de dados: ');
                fprintf('\n')
                ccs = input('Quantidade de dimens�es comuns: ');
                fprintf('\n')
                comdim_out = ccswa(xxx,ccs);
                clear ccs
            case 2
                xxx = input('Estrutura com os resultados: ');
                fprintf('\n')
                plot_comdim_out(xxx)
            otherwise
                disp('Op��o inv�lida!')
        end
    case 15 % Path-ComDim
        fprintf('Path-ComDim \n')
        fprintf('\n')
        fprintf('Para iniciar escolha: \n')
        fprintf('  (0) Criar uma estrutura de dados e analisar \n')
        fprintf('  (1) Executar a an�lise \n')
        fprintf('  (2) Gr�ficos dos resultados \n')
        op = input('Op��o escolhida: ');
        fprintf('\n')
        switch op
            case 0 % Montar a estrutura de dados
                tab = input('Quantidade de tabelas: ');
                fprintf('\n')
                ams = input('Vetor com o nome das amostras (opcional): ');
                fprintf('\n')
                ddd = cell(tab,1);
                var_name = cell(tab,1);
                tab_name = cell(tab,1);
                lks = cell(tab,1);
                for ii = 1:tab
                    fprintf('Tabela %3d \n',ii)
                    tab_name{ii} = input('Nome da tabela (opcional): ','s');
                    var_name{ii} = input('Nome das vari�veis (opcional): ');
                    ddd{ii} = input('Dados: ');
                    lks{ii} = input('Liga��es com as outras tabelas (usar nota��o vetorial se necess�rio): ');
                    fprintf('\n')
                end
                data_pathcomdim = str_table(tab,ams,ddd,var_name,tab_name,lks);
                ccs = input('Quantidade de dimens�es comuns: ');
                fprintf('\n')
                pathcomdim_out = pathcomdim(data_pathcomdim,ccs);
                clear tab ams ddd var_name tab_name ii ccs lks
            case 1
                xxx = input('Estrutura de dados: ');
                fprintf('\n')
                ccs = input('Quantidade de dimens�es comuns: ');
                fprintf('\n')
                pathcomdim_out = pathcomdim(xxx,ccs);
                clear ccs
            case 2
                xxx = input('Estrutura com os resultados: ');
                fprintf('\n')
                plot_pathcomdim_out(xxx)
            otherwise
                disp('Op��o inv�lida!')
        end
     case 16 % SOM
        fprintf('Para iniciar escolha: \n')
        fprintf('  (1) Executar a an�lise \n')
        fprintf('  (2) Plotar mapa de pesos \n')
        op = input('Op��o escolhida: ');
        fprintf('\n')
        switch op
            case 1 % Executar a an�lise
                xxx = input('Matriz com os dados: ');
                fprintf('\n')
                som_out = som(xxx);
            case 2 % Plotar mapa de pesos
                xxx = input('Modelo SOM: ');
                sss = input('Identifica��o das amostras (opcional): ');
                vvv = input('Identifica��o das vari�veis (opcional): ');
                fprintf('\n')
                weight_map(xxx,sss,vvv)
                clear sss vvv
            otherwise
                disp('Op��o inv�lida!')
        end
    case 17 % MLR
        xxx = input('Matriz X: ');
        yyy = input('Vetor y: ');
        mlr_out = mlr(xxx,yyy);
        clear yyy
    case 18 % PLSR
        fprintf('Regress�o por quadrados m�nimos parciais (PLSR) \n')
        fprintf('\n')
        xxx = input('Matriz X (centrada e/ou normalizada): ');
        yyy = input('Vetor y: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        fprintf('\n')
        op = input('Deseja fazer sele��o de vari�veis? (0) N�o (1) Sim ');
        switch op
            case 0
                lv_max = input('Quantidade m�xima de vari�veis latentes: ');
                fprintf('\n')
                pls_out = pls(xxx,yyy,s_cal,s_val,lv_max);
            case 1
                lv_max = input('Quantidade de vari�veis latentes: ');
                fprintf('\n')
                pls_out = pls_feature(xxx,yyy,s_cal,s_val,lv_max);
            otherwise
                disp('Op��o inv�lida!')
        end
        clear yyy s_cal s_val lv_max
    case 19 % epsilon-SVR
        fprintf('Regress�o por vetores suporte (\x03B5-SVR) \n')
        fprintf('\n')
        opt = '-s 3';
        xxx = input('Matriz X (deve estar normalizada): ');
        yyy = input('Vetor y: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        fprintf('\n')
        fprintf('Fun��o kernel: \n')
        fprintf('  (0) Linear \n')
        fprintf('  (1) Polinomial \n')
        fprintf('  (2) Fun��o de base radial \n')
        fprintf('  (3) Sigm�ide \n')
        s_kernel = input('Escolha uma op��o: ');
        fprintf('\n')
        switch s_kernel
            case 0 
                opt = [opt ' -t 0'];
                svr_out.kernel = 'Linear';
            case 1
                s_degree = input('Ordem do polin�mio: ');
                fprintf('\n')
                opt = [opt ' -t 1 -d ' num2str(s_degree)];
                svr_out.kernel = 'Polinomial';
                svr_out.ordem = s_degree;
                clear s_degree
            case 2
                opt = [opt ' -t 2'];
                svr_out.kernel = 'Fun��o de base radial';
            case 3
                opt = [opt ' -t 3'];
                svr_out.kernel = 'Sigm�ide';
            otherwise
                disp('Op��o inv�lida!')
        end
        op = input('Deseja fazer a otimiza��o dos par�metros? (0) N�o (1) Sim ');
        fprintf('\n')
        switch op
            case 0
                s_C = input('C: ');
                fprintf('\x03B3')
                s_gamma = input(': ');
                fprintf('\x03B5')
                s_epsilon = input(': ');
                fprintf('\n')
                opt = [opt ' -g ' num2str(s_gamma) ' -c ' num2str(s_C) ' -p ' num2str(s_epsilon)];
                svr_out.C = s_C;
                svr_out.gamma = s_gamma;
                svr_out.epsilon = s_epsilon;
                tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
                if tipo_vc == 1
                    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
                    svr_out.tipo_vc = 'k-fold';
                else
                    kfold = length(s_cal);
                    svr_out.tipo_vc = 'leave-one-out';
                end
                fprintf('\n')
                op = input('Deseja fazer sele��o de vari�veis? (0) N�o (1) Sim ');
                fprintf('\n')
                switch op
                    case 0
                        model = epsilon_svr(xxx,yyy,s_cal,s_val,opt,kfold);
                        svr_out.model = model;
                        clear model
                    case 1
                        model = epsilon_svr_feature(xxx,yyy,s_cal,s_val,opt); %%% Corrigir para sele��o de vari�veis
                        svr_out.model = model;
                    otherwise
                        disp('Op��o inv�lida!')
                end
                clear model
            case 1
                %opt2 = [opt ' -q'];
                opt2 = opt;
                s_C = input('Intervalo para C [min max] (opcional): ');
                if isempty(s_C)
                    s_C = [1 4];
                end
                fprintf('Intervalo para \x03B3 [min max] (opcional)')
                s_gamma = input(': ');
                if isempty(s_gamma)
                    s_gamma = [-5 1];
                end
                fprintf('Intervalo para \x03B5 [min max] (opcional)')
                s_epsilon = input(': ');
                if isempty(s_epsilon)
                    s_epsilon = [-2 1];
                end
                fprintf('\n')
                tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
                if tipo_vc == 1
                    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
                    svr_out.tipo_vc = 'k-fold';
                else
                    kfold = length(s_cal);
                    svr_out.tipo_vc = 'leave-one-out';
                end
                fprintf('\n')
                tipo_otm = input('Algoritmo de otimiza��o: (0) Simplex Sequencial (1) Particle Swarm ');
                svr_out.Cint = s_C;
                svr_out.GAMMAint = s_gamma;
                svr_out.EPSILONint = s_epsilon;
                svr_out.kfold = kfold;
                L = [s_C(1) s_gamma(1) s_epsilon(1)];
                U = [s_C(2) s_gamma(2) s_epsilon(2)];
                if tipo_otm == 0
                    svr_out.tipo_otm = 'Simplex Sequencial';
                    otm_svr = simplex_gamma(1,0,'f_epsilon_svr',L,U,[],xxx(s_cal,:),yyy(s_cal),opt2,'SVR',kfold);
                else
                    svr_out.tipo_otm = 'Particle Swarm'; %% corrigir
                    otm_svr = pswarm_gamma('fps_epsilon_svr',1,L,U,[],xxx(s_cal,:),yyy(s_cal),opt2,kfold);
                end
                clc
                svr_out.otm = otm_svr;
                fprintf('\n')
                op = input('Deseja testar o ponto �timo? (0) N�o (1) Sim ');
                fprintf('\n')
                if op == 1
                    if tipo_otm == 0
                        s_C = svr_out.otm.potm.C;
                        s_gamma = svr_out.otm.potm.gamma;
                        s_epsilon = svr_out.otm.potm.epsilon;
                    else
                        s_C = 10^(otm_svr.potm(1));
                        s_gamma = 10^(otm_svr.potm(2));
                        s_epsilon = 10^(otm_svr.potm(3));
                    end
                    opt = [opt ' -g ' num2str(s_gamma) ' -c ' num2str(s_C) ' -p ' num2str(s_epsilon) ' -q'];
                    svr_out.C = s_C;
                    svr_out.gamma = s_gamma;
                    svr_out.epsilon = s_epsilon;
                    model = epsilon_svr(xxx,yyy,s_cal,s_val,opt,kfold);
                    svr_out.model = model;
                    clear model
                end
                clear otm_svr L U opt2 tipo_otm tipo_vc
            otherwise
                disp('Op��o inv�lida!')
        end
        clear yyy s_cal s_val s_kernel s_C s_gamma s_epsilon opt
    case 20 % ELR
        fprintf('Extreme Learning Regression (ELR) \n')
        fprintf('\n')
        fprintf('Em desenvolvimento! \n');
%         xxx = input('Matriz X (centrada e/ou normalizada): ');
%         yyy = input('Vetor y: ');
%         s_cal = input('Amostras de calibra��o (opcional): ');
%         if isempty(s_cal)
%             s_cal = 1:size(xxx,1);
%         end
%         s_val = input('Amostras de previs�o (opcional): ');
%         elr_out = elm_regression(xxx,yyy,s_cal,s_val);
%         clear yyy s_cal s_val
    case 21 % PLSDA
        fprintf('An�lise discriminante pelo m�todo PLS (PLSDA) \n')
        fprintf('\n')
        xxx = input('Matriz X (centrada e/ou normalizada): ');
        yyy = input('Vetor das classes: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        lv_max = input('Quantidade m�xima de vari�veis latentes: ');
        tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
        if tipo_vc == 1
            kfold = input('Quantidade de grupos para a valida��o cruzada: ');
        else
            kfold = length(s_cal);
        end
        plsda_out = plsda(xxx,yyy,s_cal,s_val,lv_max,kfold);
        if tipo_vc == 1
            plsda_out(1).tipo_vc = 'k-fold';
        else
            plsda_out(1).tipo_vc = 'leave-one-out';
        end
        plsda_out(1).kfold = kfold;
        clear yyy s_cal s_val lv_max tipo_vc kfold
    case 22 % C-SVC
        fprintf('M�quina de vetor suporte (C-SVC) \n')
        fprintf('\n')
        opt = '-s 0';   
        xxx = input('Matriz X (centrada e/ou normalizada): ');
        yyy = input('Vetor das classes: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        fprintf('\n')
        fprintf('Fun��o kernel: \n')
        fprintf('  (0) Linear \n')
        fprintf('  (1) Polinomial \n')
        fprintf('  (2) Fun��o de base radial \n')
        fprintf('  (3) Sigmoide \n')
        s_kernel = input('Escolha uma op��o: ');
        fprintf('\n')
        switch s_kernel
            case 0 
                opt = [opt ' -t 0'];
                svc_out.kernel = 'Linear';
            case 1
                s_degree = input('Ordem do polin�mio: ');
                fprintf('\n')
                opt = [opt ' -t 1 -d ' num2str(s_degree)];
                svc_out.kernel = 'Polinomial';
                svc_out.ordem = s_degree;
                clear s_degree
            case 2
                opt = [opt ' -t 2'];
                svc_out.kernel = 'Fun��o de base radial';
            case 3
                opt = [opt ' -t 3'];
                svc_out.kernel = 'Sigmoide';
            otherwise
                disp('Op��o inv�lida!')
        end
        op = input('Deseja fazer a otimiza��o dos par�metros? (0) N�o (1) Sim ');
        fprintf('\n')
        switch op
            case 0
                s_C = input('C: ');
                fprintf('\x03B3')
                s_gamma = input(': ');
                fprintf('\n')
                opt = [opt ' -g ' num2str(s_gamma) ' -c ' num2str(s_C)];
                svc_out.C = s_C;
                svc_out.gamma = s_gamma;
                model = c_svc(xxx,yyy,s_cal,s_val,opt);
                svc_out.model = model;
                clear model
            case 1
                opt2 = [opt ' -q'];
                s_C = input('Intervalo para C [min max] (opcional): ');
                if isempty(s_C)
                    s_C = [0 3];
                end
                fprintf('Intervalo para \x03B3 [min max] (opcional)')
                s_gamma = input(': ');
                if isempty(s_gamma)
                    s_gamma = [-3 0];
                end
                tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
                if tipo_vc == 1
                    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
                    svc_out.tipo_vc = 'k-fold';
                else
                    kfold = length(s_cal);
                    svc_out.tipo_vc = 'leave-one-out';
                end
                fprintf('\n')
                tipo_otm = input('Algoritmo de otimiza��o: (0) Simplex Sequencial (1) Particle Swarm ');
                svc_out.Cint = s_C;
                svc_out.GAMMAint = s_gamma;
                svc_out.kfold = kfold;
                L = [s_C(1) s_gamma(1)];
                U = [s_C(2) s_gamma(2)];
                if tipo_otm == 0
                    svc_out.tipo_otm = 'Simplex Sequencial';
                    otm_svc = simplex_gamma(-1,0,'f_c_svc',L,U,[],xxx(s_cal,:),yyy(s_cal),opt2,'SVC',kfold);
                else
                    svc_out.tipo_otm = 'Particle Swarm';
                    otm_svc = pswarm_gamma('fps_c_svc',-1,L,U,[],xxx(s_cal,:),yyy(s_cal),opt2,kfold);
                end
                clc
                svc_out.otm = otm_svc;
                fprintf('\n')
                op = input('Deseja testar o ponto �timo? (0) N�o (1) Sim ');
                fprintf('\n')
                if op == 1
                    if tipo_otm == 0
                        s_C = svc_out.otm.potm.C;
                        s_gamma = svc_out.otm.potm.gamma;
                    else
                        s_C = 10^(otm_svc.potm(1));
                        s_gamma = 10^(otm_svc.potm(2));
                    end
                    opt = [opt ' -g ' num2str(s_gamma) ' -c ' num2str(s_C)];
                    svc_out.C = s_C;
                    svc_out.gamma = s_gamma;
                    model = c_svc(xxx,yyy,s_cal,s_val,opt);
                    svc_out.model = model;
                    clear model
                end
                clear otm_svc L U opt2 tipo_vc kfold tipo_otm
            otherwise
                disp('Op��o inv�lida!')
        end
        clear yyy s_cal s_val s_kernel s_C s_gamma opt
    case 23 % GMM
        fprintf('Mistura de gaussianas (GMM) \n')
        fprintf('\n')
        xxx = input('Matriz X: ');
        yyy = input('Vetor das classes: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
        if tipo_vc == 1
            kfold = input('Quantidade de grupos para a valida��o cruzada: ');
            gmm_out.tipo_vc = 'k-fold';
        else
            kfold = length(s_cal);
            gmm_out.tipo_vc = 'leave-one-out';
        end
        tipo_cova = input('Tipo de matriz de covari�ncia: (0) diagonal (1) completa ');
        if tipo_cova == 0
            cova = 'diagonal';
        else
            cova = 'full';
        end
        fprintf('\n')
        modelos = gmm(xxx,yyy,cova,s_cal',s_val,kfold);
        gmm_out.resultado = modelos;
        clear yyy s_cal s_val tipo_vc kfold modelos tipo_cova cova
    case 24 % LR
        fprintf('Regress�o log�stica (LR) \n')
        fprintf('\n')
        xxx = input('Matriz X (autoescalada): ');
        yyy = input('Vetor das classes: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        lr_out = logreg(xxx,yyy,s_cal,s_val);
        clear yyy s_cal s_val
    case 25 % LDA
        fprintf('An�lise discriminante linear (LDA) \n')
        fprintf('\n')
        xxx = input('Matriz X (autoescalada): ');
        yyy = input('Vetor das classes: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        lda_out = lda(xxx,yyy,s_cal,s_val);
        clear yyy s_cal s_val
    case 26 % ELC
        fprintf('Extreme Learning Machine (ELM) \n')
        fprintf('\n')
        xxx = input('Matriz X (autoescalada): ');
        yyy = input('Vetor das classes: ');
        s_cal = input('Amostras de calibra��o (opcional): ');
        if isempty(s_cal)
            s_cal = 1:size(xxx,1);
        end
        s_val = input('Amostras de previs�o (opcional): ');
        elc_out = elm_classification(xxx,yyy,s_cal,s_val);
        clear yyy s_cal s_val
    otherwise
        disp('Op��o inv�lida!')
end
%% Limpeza de vari�veis
clear op xxx