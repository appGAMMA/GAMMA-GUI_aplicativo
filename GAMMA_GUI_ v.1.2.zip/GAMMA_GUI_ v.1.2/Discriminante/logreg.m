function saida = logreg(dados,classe,amcal,amprev)
%% Fun��o Log�stica
%% Vers�o: 22/06/2017
saida.X = dados;
saida.Y = classe;
saida.acal = amcal;
saida.aprev = amprev;
%% Valida��o cruzada
tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
if tipo_vc == 1
    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
    saida.tipo_vc = 'k-fold';
    cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
else
    kfold = length(amcal);
    saida.tipo_vc = 'leave-one-out';
    cvidx = 1:kfold;
end
%% Prepara��o dos dados
xcal = dados(amcal,:); % x de calibra��o
ncal = length(amcal); % quantidade de amostras de calibra��o
[y,gn] = grp2idx(classe); 
saida.classes = gn;
ycal = y(amcal); % y de calibra��o
ngrp = length(gn); % quantidade de grupos
thrs = 0.5*ones(ngrp,1); % Limiar de classifica��o
if ~isempty(amprev)
    xprev = dados(amprev,:); % x de previs�o   
    yprev = y(amprev); % y de previs�o
end
%% Constru��o do modelo
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
cont = 0;
ypcv = zeros(ncal,ngrp);
dlow = zeros(ncal,ngrp);
dhi = zeros(ncal,ngrp);
for kk = 1:kfold  % Loop da valida��o cruzada
    % Separa��o das amostras
    idx = cvidx ~= kk;
    xcv_cal = xcal(idx,:);
    ycv_cal = ycal(idx,:);
    idx = cvidx == kk;
    xcv_val = xcal(idx,:);
    [B,~,stats] = mnrfit(xcv_cal,ycv_cal);
    [ypcv(idx,:),dlow(idx,:),dhi(idx,:)] = mnrval(B,xcv_val,stats);
    % Atualiza��o da barra de execu��o
    cont = cont + 1;
    waitbar(cont/kfold);
end
close(wb);
% Calibra��o
[B,dev,stats] = mnrfit(xcal,ycal);
[ypcal,dlow,dhi] = mnrval(B,xcal,stats);
saida.B = B;
saida.dev = dev;
saida.stats = stats;
saida.ypcal = ypcal;
saida.ylow_cal = dlow;
saida.yhi_cal = dhi;
% FOM
[PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(ycal')',ypcal,0);
saida.PCCcal = PCC;
saida.AUCcal = AUC;
saida.RMSEcal = RMSE;
fprintf('\n')
fprintf('Calibra��o \n')
fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
temp = sens_selet(ind2vec(ycal')',ypcal,thrs,gn);
saida.SENScal = temp;
% FOM - Valida��o cruzada
[PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(ycal')',ypcv,0);
saida.ypcv = ypcv;
saida.ylow_cv = dlow;
saida.yhi_cv = dhi;
saida.PCCcv = PCC;
saida.AUCcv = AUC;
saida.RMSEcv = RMSE;
fprintf('\n')
fprintf('Valida��o Cruzada \n')
fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
temp = sens_selet(ind2vec(ycal')',ypcv,thrs,gn);
saida.SENScv = temp;
% Previs�o
if ~isempty(amprev)
    [ypprev,dlow,dhi] = mnrval(B,xprev,stats);
    saida.ypprev = ypprev;
    saida.ylow_prev = dlow;
    saida.yhi_prev = dhi;
    % FOM
    [PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(yprev')',ypprev,0);
    saida.PCCprev = PCC;
    saida.AUCprev = AUC;
    saida.RMSEprev = RMSE;
    fprintf('\n')
    fprintf('Previs�o \n')
    fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
    temp = sens_selet(ind2vec(yprev')',ypprev,thrs,gn);
    saida.SENSprev = temp;
end
