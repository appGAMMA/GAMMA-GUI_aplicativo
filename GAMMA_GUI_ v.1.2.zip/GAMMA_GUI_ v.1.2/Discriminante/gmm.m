function saida = gmm(dados,classe,Sigma,acal,aprev,kfold)
%% Classifica��o usando Gaussian Mixture Models
%% Vers�o: 17/06/2017
%% Par�metros
RegularizationValue = 0.0001; % fator de regulariza��o para garantir que a matriz na seja mal condicionada
SharedCovariance = false; % indica se a matriz de covari�ncia � compartilhada entre os grupos
options = statset('MaxIter',10000); % quantidade m�xima de itera��es do algoritmo EM
% Inicializa��o
%str = 'randSample'; % inicializa��o aleat�ria
str = 'plus';  % inicializa��o usando o knn
%str = grp2idx(classe); % inicializa��o usando as classes pr�-definidas
saida.inicializa = str;
%% Prepara��o dos dados
xcal = dados(acal,:); % x de calibra��o
ncal = length(acal); % quantidade de amostras de calibra��o
[y,gn] = grp2idx(classe); 
saida.classes = gn;
ycal = y(acal); % y de calibra��o
ngrp = length(gn); % quantidade de grupos
thrs = 0.5*ones(ngrp,1); % Limiar de classifica��o
pap = zeros(ngrp,1); % probabilidade a priori de cada classe
for ii = 1:ngrp
    idx = ycal == ii;
    pap(ii) = sum(idx)/length(ycal);
end
saida.papriori = pap;
if ~isempty(aprev)
    xprev = dados(aprev,:); % x de previs�o
    nprev = length(aprev);  % quantidade de amostras de previs�o
    yprev = y(aprev); % y de previs�o
    ppprev = zeros(nprev,ngrp); % probabilidade a posteriori de previs�o
end
%% Defini��o do n�mero de componentes para cada classe
op = input('Deseja definir a quantidade de componentes? (0) N�o (1) Sim ');
fprintf('\n')
if op == 1
    cmax = input('Quantidade m�xima de componentes: ');
    fprintf('\n')
    CVresult = struct;
    CVresult.cmax = cmax;
    aic = zeros(cmax,ngrp);
    bic = zeros(cmax,ngrp);
    CH = zeros(cmax,ngrp);
    DB = zeros(cmax,ngrp);
    Si = zeros(cmax,ngrp);
    wb=waitbar(0,'Defini��o da quantidade de componentes por classe...','Name','Defini��o dos componentes');
    cont = 0;
    for kk = 1:ngrp % Loop das classes
        % Valida��o cruzada 
        if kfold < ncal
            cvidx = crossvalind('Kfold',ncal,kfold); % K-fold
        else
            cvidx = 1:ncal; % Leave-one-out
        end
        for jj = 1:kfold % Loop da valida��o cruzada
            % Separa��o das amostras
            idx = cvidx ~= jj;
            xtreina = xcal(idx,:);
            ytreina = ycal(idx,:);
            % Sele��o das amostras por classe
            idx_classe = ytreina == kk;
            xclasse = xtreina(idx_classe,:);
            clt = zeros(size(xclasse,1),cmax);
            for ii = 1:cmax % Loop dos componentes
                cont = cont + 1;
                waitbar(cont/(ngrp*kfold*cmax));
                gmc = fitgmdist(xclasse,ii,...
                            'CovarianceType',Sigma,...
                            'SharedCovariance',SharedCovariance,...
                            'RegularizationValue',RegularizationValue,...
                            'Replicates',10,...
                            'Start',str,...
                            'Options',options);
                aic(ii,kk) = aic(ii,kk) + gmc.AIC;
                bic(ii,kk) = bic(ii,kk) + gmc.BIC;
                clt(:,ii) = cluster(gmc,xclasse);
            end
            temp = evalclusters(xclasse,clt,'CalinskiHarabasz');
            CH(:,kk) = CH(:,kk) + temp.CriterionValues';
            temp = evalclusters(xclasse,clt,'DaviesBouldin');
            DB(:,kk) = DB(:,kk) + temp.CriterionValues';
            temp = evalclusters(xclasse,clt,'Silhouette');
            Si(:,kk) = Si(:,kk) + temp.CriterionValues';
        end
    end
    aic = aic/kfold;
    bic = bic/kfold;
    CH = CH/kfold;
    DB = DB/kfold;
    Si = Si/kfold;
    CVresult.AIC = aic;
    CVresult.BIC = bic;
    CVresult.CH = CH;
    CVresult.DB = DB;
    CVresult.Si = Si;
    saida.CVresult = CVresult;
    close(wb)
    % Sa�da dos resultados da defini��o de componentes
    for ii = 1:ngrp
        texto = ['Classe: ' gn{ii}];
        disp(texto)
        fprintf('\n')
        T = table(temp.InspectedK',aic(:,ii),bic(:,ii),CH(:,ii),DB(:,ii),Si(:,ii),'VariableNames',{'Componentes' 'AIC' 'BIC' 'CH' 'DB' 'Si'});
        disp(T)
        fprintf('Obs: A melhor quantidade de componentes maximiza (CH e Si) e minimiza (AIC, BIC e DB) \n')
        fprintf('\n')
    end
end
%% Ajuste dos modelos por classe
cont = 1;
op = 1;
while op == 1
    gmm = cell(ngrp,1);
    ppcal = zeros(ncal,ngrp); % probabilidade a posteriori de calibra��o
    ppvc = zeros(ncal,ngrp);  % probabilidade a posteriori de valida��o cruzada
    comp = zeros(ngrp,1); % quantidade de componentes em cada gmm
    for ii = 1:ngrp
        texto = ['Quantidade de componentes para a classe ' gn{ii} ': '];
        comp(ii) = input(texto);
    end
    wb=waitbar(0,'Ajustando os modelos...','Name','Calibra��o');
    cwb = 0;
    for ii = 1:ngrp
        % Sele��o das amostras por classe
        idx_classe = ycal == ii;
        xclasse = xcal(idx_classe,:);
        gmm{ii} = fitgmdist(xclasse,comp(ii),...
                            'CovarianceType',Sigma,...
                            'SharedCovariance',SharedCovariance,...
                            'RegularizationValue',RegularizationValue,...
                            'Start',str,...
                            'Replicates',100,...
                            'Options',options);
        % Densidade de probabilidade
        ppcal(:,ii) = pdf(gmm{ii},xcal)*pap(ii);
        if ~isempty(aprev)
            ppprev(:,ii) = pdf(gmm{ii},xprev)*pap(ii);
        end
        % Valida��o cruzada 
        if kfold < ncal
            cvidx = crossvalind('Kfold',ncal,kfold); % K-fold
        else
            cvidx = 1:ncal; % Leave-one-out
        end
        for jj = 1:kfold
            cwb = cwb + 1;
            waitbar(cwb/(ngrp*kfold));
            % Separa��o das amostras
            idx = cvidx ~= jj;
            xtreina = xcal(idx,:);
            ytreina = ycal(idx,:);
            idx = cvidx == jj;
            xval = xcal(idx,:);
            % Sele��o das amostras por classe
            idx_classe = ytreina == ii;
            xclasse = xtreina(idx_classe,:);
            gmc = fitgmdist(xclasse,comp(ii),...
                            'CovarianceType',Sigma,...
                            'SharedCovariance',SharedCovariance,...
                            'RegularizationValue',RegularizationValue,...
                            'Start',str,...
                            'Replicates',100,...
                            'Options',options);
            % Probabilidade a posteriori de valida��o cruzada
            ppvc(idx,ii) = pdf(gmc,xval)*pap(ii);
        end
    end
    % Teorema de Bayes
    scal = sum(ppcal,2);
    svc = sum(ppvc,2);
    if ~isempty(aprev)
        sprev = sum(ppprev,2);
    end
    for kk = 1:ngrp
        ppcal(:,kk) = ppcal(:,kk)./scal;
        ppvc(:,kk) = ppvc(:,kk)./svc;
        if ~isempty(aprev)
            ppprev(:,kk) = ppprev(:,kk)./sprev;
        end
    end
    close(wb)
    % FOM Calibra��o
    [PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(ycal')',ppcal,0);
    FOMcal.PCC = PCC;
    FOMcal.AUC = AUC;
    FOMcal.RMSE = RMSE;
    fprintf('\n')
    fprintf('Calibra��o \n')
    fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
    temp = sens_selet(ind2vec(ycal')',ppcal,thrs,gn);
    FOMcal.SENS = temp;
    % FOM Valida��o cruzada
    [PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(ycal')',ppvc,0);
    FOMcv.PCC = PCC;
    FOMcv.AUC = AUC;
    FOMcv.RMSE = RMSE;
    fprintf('\n')
    fprintf('Valida��o Cruzada \n')
    fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
    temp = sens_selet(ind2vec(ycal')',ppvc,thrs,gn);
    FOMcv.SENS = temp;
    % FOM Previs�o
    if ~isempty(aprev)
        [PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(yprev')',ppprev,0);
        FOMprev.PCC = PCC;
        FOMprev.AUC = AUC;
        FOMprev.RMSE = RMSE;
        fprintf('\n')
        fprintf('Previs�o \n')
        fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
        temp = sens_selet(ind2vec(yprev')',ppprev,thrs,gn);
        FOMprev.SENS = temp;
    end
    %% Sa�da dos resultados
    saida.modelo(cont).comp = comp;
    saida.modelo(cont).gmm = gmm;
    saida.modelo(cont).ppcal = ppcal;
    saida.modelo(cont).FOMcal = FOMcal;
    saida.modelo(cont).ppcv = ppvc;
    saida.modelo(cont).FOMcv = FOMcv;
    if ~isempty(aprev)
        saida.modelo(cont).ppprev = ppprev;
        saida.modelo(cont).FOMprev = FOMprev;
    end
    fprintf('\n')
    op = input('Deseja ajustar outro modelo? (0) N�o (1) Sim ');
    cont = cont + 1;
    fprintf('\n')
end