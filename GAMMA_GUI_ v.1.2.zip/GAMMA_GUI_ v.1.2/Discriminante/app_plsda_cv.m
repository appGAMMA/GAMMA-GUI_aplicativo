function model = app_plsda_cv(x,samples,normaliza,am_treina,nvl,kfold)
%% PLSDA usando as rotinas do MATLAB - appGAMMA
%% Vers�o: 21/09/2020
% Valida��o cruzada: leave-one-out ou k-fold
%% Par�metros do algoritmo
codifica = '1deN';  % codifica��o da matriz Y
ntreina = size(x,1); % quantidade de amostras de calibra��o
model = struct;
%% Dados
% Calibra��o
x_treina = x(am_treina,:);
[y,nclass,gn] = cod(codifica,samples,0);
y_treina = y(am_treina,:);
model.classes = gn(1:nclass);
model.ycod = y;
%% Normaliza��o
switch normaliza
    case 'Autoescalamento'
        x_treina = zscore(x_treina);
    case 'Pareto'
        [x_treina,~,sigma] = zscore(x);
        x_treina = x_treina.*(ones(ntreina,1)*sqrt(sigma));
end
model.Xcal = x_treina;
model.normaliza = normaliza;
%% Defini��o da quantidade de VL
AUCCV = zeros(nvl,1);
RMSECV = zeros(nvl,1);
PCCCV = zeros(nvl,1);
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
cont = 0;
[ll,cc] = size(y_treina);
saidaCV = zeros(ll,cc,nvl);
% Valida��o cruzada (mesma amostragem para cada LV testada)
if kfold < ntreina
    % K-fold
    cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
else
    % Leave-one-out
    cvidx = 1:ntreina;
end
for jj = 1:nvl % Loop das vari�veis latentes
    ycv = zeros(size(y_treina));
%     % Valida��o cruzada (amostragem diferente para cada LV testada)
%     if kfold < ntreina
%         % K-fold
%         cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
%     else
%         % Leave-one-out
%         cvidx = 1:ntreina;
%     end
    for kk = 1:kfold  % Loop da valida��o cruzada
        % Separa��o das amostras
        idx = cvidx ~= kk;
        xcv_treina = x_treina(idx,:);
        ycv_treina = y_treina(idx,:);
        idx = cvidx == kk;
        xcv_teste = x_treina(idx,:);
        [~,~,~,~,beta] = plsregress(xcv_treina,ycv_treina,jj);
        ycv(idx,:) = [ones(size(xcv_teste,1),1) xcv_teste]*beta;
        % Atualiza��o da barra de execu��o
        cont = cont + 1;
        waitbar(cont/(nvl*kfold));
    end
    % FOM
    [PCCCV(jj),AUCCV(jj),RMSECV(jj)] = fom_da(nclass,codifica,gn,y_treina,ycv,0);
    saidaCV(:,:,jj) = ycv;
end
model.NVLS = 1:nvl;
model.AUCCV = AUCCV;
model.RMSECV = RMSECV;
model.PCCV = PCCCV;
close(wb)
%% Gr�ficos para RMSECV e AUC
figure
plot(1:nvl,PCCCV./100,'-k')
hold on
hAx = plotyy(1:nvl,AUCCV,1:nvl,RMSECV);
ylabel(hAx(1),'PCCCV e AUCCV (m�dia)') % left y-axis
ylabel(hAx(2),'RMSECV') % right y-axis
legend('PCCCV','AUCCV (m�dia)','RMSECV','Location','best')
xlabel('Vari�veis Latentes')
hold off
