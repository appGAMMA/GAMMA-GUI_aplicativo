function model = app_plsda(x,samples,normaliza,am_treina,am_teste,nvl,op_model,op_graf)
%% PLSDA usando as rotinas do MATLAB - appGAMMA
%% Vers�o: 29/07/2020
% Detec��o de outliers - gr�fico T2 vs Q
% Porcentagem de classifica��o correta: Winner's takes all
% Probabilidades bayesianas
%% Par�metros do algoritmo
codifica = '1deN';  % codifica��o da matriz Y
model = struct;
model.Cal = am_treina;
model.Pred = am_teste;
%% Dados
% Calibra��o
x_treina = x(am_treina,:);
ntreina = size(x_treina,1); % quantidade de amostras de calibra��o
[y,nclass,gn] = cod(codifica,samples,0);
y_treina = y(am_treina,:);
model.classes = gn(1:nclass);
% Previs�o
if ~isempty(am_teste)
    x_teste = x(am_teste,:); % x de previs�o
    nteste = size(x_teste,1); % quantidade de amostras de previs�o
    y_teste = y(am_teste,:); % y de previs�o
else
    x_teste = [];
    y_teste = [];
end
%% Normaliza��o
model.normaliza = normaliza;
switch normaliza
    case 'Centrar na m�dia'
        mu = mean(x_treina);
        x_treina = x_treina - ones(ntreina,1)*mu;
        if ~isempty(am_teste)
            x_teste = x_teste - ones(nteste,1)*mu;
        end
    case 'Autoescalamento'
        [x_treina,mu,sigma] = zscore(x_treina);
        if ~isempty(am_teste)
            x_teste = (x_teste - ones(nteste,1)*mu)./(ones(nteste,1)*sigma);
        end
    case 'Pareto'
        [x_treina,mu,sigma] = zscore(x_treina);
        x_treina = x_treina.*(ones(ntreina,1)*sqrt(sigma));
        if ~isempty(am_teste)
            x_teste = (x_teste - ones(nteste,1)*mu)./(ones(nteste,1)*sqrt(sigma));
        end
end
model.Xcal = x_treina;
model.Ycal = y_treina;
model.Xpred = x_teste;
model.Ypred = y_teste;
%% Detec��o de outliers
if op_model(1) == 1
    outliers = app_plsda_outliers(x_treina,x_teste,y_treina,y_teste,nvl,gn);
    % corre��o dos outliers para a numera��o geral das amostras
    outliers.outliers_cal = am_treina(outliers.outliers_cal);
    if ~isempty(am_teste)
        outliers.outliers_pred = am_teste(outliers.outliers_pred);
    end
    model.outliers = outliers;
end
%% Constru��o dos modelos
model.LVs = nvl;
% Modelo
[xl,yl,xs,ys,beta,pctvar,~,stats] = plsregress(x_treina,y_treina,nvl);
% Previs�o
yp = zeros(size(y));
yp_treina = [ones(size(x_treina,1),1) x_treina]*beta;
yp(am_treina,:) = yp_treina;
if ~isempty(am_teste)
    yp_teste = [ones(size(x_teste,1),1) x_teste]*beta;
    yp(am_teste,:) = yp_teste;
end
% Vari�ncia acumulada
temp = sum(pctvar,2);
varx = temp(1);
vary = temp(2);
%% Figuras de m�rito
% Calibra��o
[PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,y_treina,yp_treina,op_graf(1));
model.RMSEC = RMSE;
model.PCCC = PCC;
model.AUCC = MAUC;
model.ROCcal = ROC;
if op_graf(1) == 1
    title(['ROC - Calibra��o - ' num2str(nvl) ' LVs'])
end
% Previs�o
if ~isempty(am_teste)
    [PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,y_teste,yp_teste,op_graf(1));
    model.RMSEP = RMSE;
    model.PCCP = PCC;
    model.AUCP = MAUC;
    model.ROCpred = ROC;
    if op_graf(1) == 1
        title(['ROC - Previs�o - ' num2str(nvl) ' LVs'])
    end
end
%% Armazenamento do modelo
model.xl = xl;
model.yl = yl;
model.xs = xs;
model.ys = ys;
model.beta = beta;
model.pctvar = pctvar;
model.varX = varx;
model.varY = vary;
model.stats = stats;
model.yp = yp;
%% Probabilidades Bayesianas
% Sa�da em uma linha para cada classe
 if op_model(2) == 1
     if ~isempty(am_teste)
         ygraf = [y_treina;y_teste];
         ypgraf = [yp_treina;yp_teste];
     else
         ygraf = y_treina;
         ypgraf = yp;
     end
     bayes_prob = dens_prob(ygraf,ypgraf);
     model.bayes_prob = bayes_prob;
     % Gr�fico das probabilidades
     if op_graf(3) == 1
         plot_post_plsda(ygraf,ypgraf,gn(1:nclass),bayes_prob)
     end
 end
%% Sensibilidade e Seletividade
thrs = zeros(nclass,1);
for ii = 1:nclass
    if op_model(2) == 1
        thrs(ii) = bayes_prob(ii).threshold;
    else
        thrs(ii) = 0.5;
    end
end
% Calibra��o
saida = app_sens_selet(y_treina,yp_treina,thrs,gn(1:nclass));
model.SENScal = saida;
% Previs�o
if ~isempty(am_teste)
    saida = app_sens_selet(y_teste,yp_teste,thrs,gn(1:nclass));
    model.SENSpred = saida;
end
%% Plotar a sa�da do classificador
 if op_graf(2) == 1
     if ~isempty(am_teste)
         plot_output_da([y_treina;y_teste],[yp_treina;yp_teste],gn(1:nclass),thrs,ntreina,'PLSDA')
     else
         plot_output_da(y_treina,yp_treina,gn(1:nclass),thrs,0,'PLSDA')
     end
 end