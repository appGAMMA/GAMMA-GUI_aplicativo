function dprob = dens_prob(y,yp)
%% Transforma as sa�das em probabilidades usando o teorema de Bayes
%% Vers�o: 01/02/2017
% Sa�da em uma linha para cada classe
%% Par�metros
prec = 0.0001;      % Precis�o para simular os dados
%%
[ams,nclass] = size(y); % Quantidade de amostras e classes
dprob = struct;
for ii = 1:nclass
    idx = full(y(:,ii)) == 1; % amostras pertencentes a classe = 1 - n�o classe = 0
    c = sum(idx); % quantidade de amostras que pertencem a classe
    nc = ams - c; % quantidade de amostras que n�o pertencem a classe
    ypc = yp(idx,ii);
    ypnc = yp(~idx,ii);
    % Probabilidade a priori
    pc = c/ams;
    pnc = nc/ams;
    % M�dias dos valores previstos
    mc = mean(ypc);
    mnc = mean(ypnc);
    % Desvios padr�es
    sc = std(ypc);
    snc = std(ypnc);
    % Fun��es de densidade de probabilidade normal * probabilidade a priori
    fdpc = (1/(sc*sqrt(2*pi)))*exp(-0.5*((yp(:,ii) - mc)./sc).^2)*pc;
    fdpnc = (1/(snc*sqrt(2*pi)))*exp(-0.5*((yp(:,ii) - mnc)./snc).^2)*pnc;
    % Fator de normaliza��o
    norma = fdpc+fdpnc;
    % Probabilidade a posteriori
    probc = fdpc./norma;
    probnc = fdpnc./norma;
    % Simula��o das curvas de densidade de probabilidade
    minyp = min([min(yp(:,ii)) 0]);
    maxyp = max([max(yp(:,ii)) 1]);
    yps = ((minyp - 0.1*minyp):prec:(maxyp + 0.1*maxyp))';
    fdpcs = (1/(sc*sqrt(2*pi)))*exp(-0.5*((yps - mc)./sc).^2)*pc;
    fdpncs = (1/(snc*sqrt(2*pi)))*exp(-0.5*((yps - mnc)./snc).^2)*pnc;
    normas = fdpcs+fdpncs;
    probcs = fdpcs./normas;
    probncs = fdpncs./normas;
    % Localiza��o do threshold
    op = 1;
    while op == 1
        idx = find(abs(probcs-probncs) < prec);
        if isempty(idx) % Caso seja vazio a precis�o � reduzida
            prec = prec*10;
        elseif length(idx) > 1 % Caso sejam encontrados v�rios �ndices
            [~,temp] = sort(abs(probcs(idx) - probncs(idx))); % Escolha da menor diferen�a
            thres = yps(idx(temp(1)));
            op = 0;
        else
            thres = yps(idx);
            op = 0;
        end
    end
    % Sa�da dos resultados
    dprob(ii).priori_c = pc;
    dprob(ii).priori_nc = pnc;
    dprob(ii).m_c = mc;
    dprob(ii).m_nc = mnc;
    dprob(ii).s_c = sc;
    dprob(ii).s_nc = snc;
    dprob(ii).post_c = probc;
    dprob(ii).post_nc = probnc;
    dprob(ii).graf_post(:,1) = yps;
    dprob(ii).graf_post(:,2) = probcs;
    dprob(ii).graf_post(:,3) = probncs;
    dprob(ii).threshold = thres;
end
