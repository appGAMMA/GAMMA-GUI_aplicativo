function saida = app_sens_selet(y,yp,thrs,gn)
%% Fun��o para calcular figuras de m�rito para o app
%% Vers�o: 09/07/2020
% Exatid�o
% Sensibilidade
% Taxa de falsos positivos
% Seletividade
% Matriz de confus�o
% Sa�da em uma linha por classe
%% Prepara��o dos dados
nc = size(y,2);
saida = struct;
%% Loop das Classes
for ii = 1:nc
    conf = zeros(3); % Matriz de confus�o
    saida(ii).classe = gn{ii};
    saida(ii).threshold = thrs(ii); % Limiar
    idx = y(:,ii) == 1; % Amostras da classe
    FN = sum(yp(idx,ii) < thrs(ii)); % Falso negativo
    TP = sum(idx) - FN; % Verdadeiro positivo
    FP = sum(yp(~idx,ii) >= thrs(ii)); % Falso positivo
    TN = sum(~idx) - FP; % Verdadeiro negativo
    EXAT = 100*(TP + TN)/(TP + FN + FP + TN); % Exatid�o
    SEN = 100*TP/(TP + FN); % Sensibilidade
    SEL = 100*TN/(FP + TN); % Seletividade
    TFP = 100*FP/(FP + TN); % Taxa de falso positivo
    % Matriz de confus�o - Coluna = classe verdadeira - Linha = Classe Prevista
    conf(1,1) = TP;
    conf(2,1) = FN;
    conf(3,1) = TP + FN;
    conf(1,2) = FP;
    conf(2,2) = TN;
    conf(3,2) = FP + TN;
    conf(1,3) = TP + FP;
    conf(2,3) = FN + TN;
    conf(3,3) = conf(3,1) + conf(3,2);
    T = array2table(conf,'VariableNames',{'Classe_1','Classe_0','Total'});
    T.Properties.RowNames = {'Classe_1','Classe_0','Total'};
    % Saida
    saida(ii).FN = FN;
    saida(ii).TP = TP;
    saida(ii).FP = FP;
    saida(ii).TN = TN;
    saida(ii).EXAT = EXAT;
    saida(ii).SEN = SEN;
    saida(ii).SEL = SEL;
    saida(ii).TFP = TFP;
    saida(ii).confusion = T;
end
