function saida = c_svc(x,samples,am_treina,am_teste,opt)
%% M�quina de vetor suporte para classifica��o
%% Vers�o: 15/05/2017
% Rotinas do pacote libsvm 3.2
% Multiclasses: one-against-all
% Pesos por classe: Luts et al. (2010)
%% Prepara��o dos dados
opt1 = [opt ' -b 1 -q']; % Sa�da como probabilidade
codifica = '1deN';  % codifica��o da matriz Y
% X
x = sparse(x);
ntreina = length(am_treina); % quantidade de amostras de calibra��o
% Y
[G,GN] = grp2idx(samples);
nclass = size(GN,1);
y = G;
saida.classes = GN(1:nclass);
saida.amcal = am_treina;
saida.amprev = am_teste;
%% Loop para a constru��o de k-SVC
kSVC = cell(1,nclass);
svi = cell(1,nclass);
kyb = zeros(size(y,1),nclass);
kyo = zeros(size(y,1),nclass); % Probabilidades
kyp = zeros(size(y,1),nclass); % sa�da prevista
for ii = 1:nclass
    % Classe ii = +1 e as outras = -1
    kSVC{ii}.yb = zeros(size(y,1),1);
    kSVC{ii}.yp = zeros(size(y,1),1);
    kSVC{ii}.yo = zeros(size(y,1),1);
    idx = y == ii;
    yb = -1*ones(size(y));
    yb(idx) = 1;
    kSVC{ii}.yb = yb;
    kyb(:,ii) = yb;
    % Pesos para as classes desbalanceadas
    % amostras 1
    cont = sum(yb(am_treina) == 1);
    wp = length(am_treina)/(2*cont);
    % amostras -1
    cont = sum(yb(am_treina) == -1);
    wn = length(am_treina)/(2*cont);
    opt2 = [opt1 ' -w1 ' num2str(wp) ' -w-1 ' num2str(wn)];
    % Treinamento da SVM ii
    model = svmtrain(yb(am_treina),x(am_treina,:),opt2);
    kSVC{ii}.model = model;
    % Previs�o num�rica
    [~,~,out_treina] = svmpredict(yb(am_treina),x(am_treina,:),model);
    kyp(am_treina,ii) = out_treina;
    % Previs�o como probabilidade
    [yp_treina,acc_treina,out_treina] = svmpredict(yb(am_treina),x(am_treina,:),model,'-b 1');
    kSVC{ii}.yp(am_treina) = yp_treina;
    kSVC{ii}.acc_treina = acc_treina;
    kSVC{ii}.yo(am_treina) = out_treina(:,1);
    kyo(am_treina,ii) = out_treina(:,1);
    svi{ii} = model.sv_indices;
    % Teste da SVM ii
    % Previs�o num�rica
    [~,~,out_teste] = svmpredict(yb(am_teste),x(am_teste,:),model);
    kyp(am_teste,ii) = out_teste;
    % Previs�o como probabilidade
    [yp_teste,acc_teste,out_teste] = svmpredict(yb(am_teste),x(am_teste,:),model,'-b 1');
    kSVC{ii}.yp(am_teste) = yp_teste;
    kSVC{ii}.acc_teste = acc_teste;
    kSVC{ii}.yo(am_teste) = out_teste(:,1);
    kyo(am_teste,ii) = out_teste(:,1);
end
%% Armazenamento
saida.kSVC = kSVC;
saida.svi = svi;
saida.kyb = kyb;
saida.kyo = kyo;
saida.kyp = kyp;
%% Gr�fico das probabilidades
clc % para apagar sa�da do pacote libsvm
% Nova codifica��o de y para aproveitar a fun��o fom_da
[y,nclass,gn] = cod(codifica,samples,0);
y_treina = y(am_treina,:);
y_teste = y(am_teste,:);
fprintf('\n')
op = input('Deseja plotar as probabilidades? (0) N�o (1) Sim ');
limiar = plot_post_svc(gn(1:nclass),kSVC,op);
% Resumo na tela
fprintf('\n')
fprintf('Limiar para classifica��o em cada classe \n')
for ii = 1:nclass
    fprintf('%s = %8.4f \n',gn{ii},limiar(ii))
end
fprintf('\n')
tiposaida = input('Deseja utilizar: (0) Probabilidades (1) Sa�da padr�o? ');
if tiposaida == 1
    saida.tipo = 'Sa�da padr�o';
    limiar = zeros(nclass,1);
else
    saida.tipo = 'Probabilidades';
end
saida.threshold = limiar;
%% Figuras de m�rito
fprintf('\n')
op = input('Deseja plotar as curvas ROC? (0) N�o (1) Sim ');
% Calibra��o
if tiposaida == 0
    [PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,y_treina,kyo(am_treina,:),op);
else
    [PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,kyb(am_treina,:),kyp(am_treina,:),op);
end
saida.RMSEC = RMSE;
saida.PCCC = PCC;
saida.AUCC = MAUC;
saida.ROCtreina = ROC;
if op == 1
    title('ROC - Calibra��o')
end
% Previs�o
if tiposaida == 0
    [PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,y_teste,kyo(am_teste,:),op);
else
    [PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,kyb(am_teste,:),kyp(am_teste,:),op);
end
saida.RMSEP = RMSE;
saida.PCCP = PCC;
saida.AUCP = MAUC;
saida.ROCteste = ROC;
if op == 1
    title('ROC - Previs�o')
end
% Resumo na tela
fprintf('\n')
fprintf('RMSEC  = %8.4f \t AUCC  = %8.4f \t PCCC  = %8.2f %% \n',saida.RMSEC,saida.AUCC,saida.PCCC)
fprintf('RMSEP  = %8.4f \t AUCP  = %8.4f \t PCCP  = %8.2f %% \n',saida.RMSEP,saida.AUCP,saida.PCCP)
%% Sensibilidade e Seletividade
% Treinamento
fprintf('\n')
fprintf('Exatid�o, Sensibilidade e Seletividade - Calibra��o \n')
if tiposaida == 1
    sens_out = sens_selet(y_treina,kyp(am_treina,:),limiar,gn(1:nclass));
else
    sens_out = sens_selet(y_treina,kyo(am_treina,:),ones(nclass,1)*0.5,gn(1:nclass));
end
saida.SENScal = sens_out;
% Teste
fprintf('\n')
fprintf('Exatid�o, Sensibilidade e Seletividade - Previs�o \n')
if tiposaida == 1
    sens_out = sens_selet(y_teste,kyp(am_teste,:),limiar,gn(1:nclass));
else
    sens_out = sens_selet(y_teste,kyo(am_teste,:),ones(nclass,1)*0.5,gn(1:nclass));
end
saida.SENSprev = sens_out;
%% Plotar a sa�da do classificador
fprintf('\n')
op = input('Deseja plotar as respostas do SVC? (0) N�o (1) Sim ');
if op == 1
    plot_output_da([y_treina;y_teste],[kyp(am_treina,:);kyp(am_teste,:)],gn(1:nclass),limiar,ntreina,'SVC')
end