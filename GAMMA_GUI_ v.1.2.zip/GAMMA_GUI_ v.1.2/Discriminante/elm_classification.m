function saida = elm_classification(dados,classe,amcal,amprev)
%% Extreme Learning Machine - Classifica��o
%% Vers�o: 01/08/2017
saida.X = dados;
saida.Y = classe;
saida.acal = amcal;
saida.aprev = amprev;
%% Par�metros
codifica = '1deN';  % codifica��o da matriz Y
opt.type = 'classification';
opt.inputsize = size(dados,2);
opt.orthogonal = false; % Verificar essa op��o
% Fun��o de ativa��o
fprintf('\n')
op = input('Fun��o de ativa��o: (0) sigmoide (1) tangente hiperb�lica ');
switch op
    case 0
        opt.activefunction = 'sigmoid';
    case 1
        opt.activefunction = 'tanh';
    otherwise
        disp('Op��o inv�lida!')
end
% Algoritmo
fprintf('\n')
fprintf('Algoritmo de treinamento: \n')
fprintf('\t (0) ELM \n')
fprintf('\t (1) RELM \n')
%fprintf('\t (2) WRELM \n')
%fprintf('\t (3) ORELM \n')
op = input('Escolha uma op��o: ');
switch op
    case 0
        opt.method = 'ELM';
    case 1
        opt.method = 'RELM';
        opt.C = 0.0001;
    case 2
        opt.method = 'WRELM';
        opt.wfun = '1';
        opt.scale_method = 1;
        opt.C = 2^(-20);
    case 3
        opt.method = 'ORELM';
        opt.C = 2^(-40);
    otherwise
        disp('Op��o inv�lida!')
end
% Neur�nios ocultos
fprintf('\n')
hn = input('Quantidade m�xima de neur�nios ocultos = ');
opt.max_hn = hn;
% Salva as op��es
saida.opt = opt;
% Valida��o cruzada
fprintf('\n')
tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
if tipo_vc == 1
    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
    saida.tipo_vc = 'k-fold';
    cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
else
    kfold = length(amcal);
    saida.tipo_vc = 'leave-one-out';
    cvidx = 1:kfold;
end
%% Prepara��o dos dados
xcal = dados(amcal,:); % x de calibra��o
ncal = length(amcal); % quantidade de amostras de calibra��o
%[y,ngrp,gn] = cod(codifica,classe,0);
[y,gn] = grp2idx(classe); 

%%%
idx = y == 1;
y(idx) = -1;
y(~idx) = +1;
%%%

saida.classes = gn;
ycal = y(amcal,:); % y de calibra��o
ngrp = length(gn); % quantidade de grupos
%thrs = 0.5*ones(ngrp,1); % Limiar de classifica��o
if ~isempty(amprev)
    xprev = dados(amprev,:); % x de previs�o   
    yprev = y(amprev,:); % y de previs�o
end
%% Valida��o cruzada - defini��o da quantidade de neur�nios ocultos
AUCCV = zeros(hn,1);
RMSECV = zeros(hn,1);
PCCCV = zeros(hn,1);
cont = 0;
ypcv = zeros(ncal,ngrp);
%cost = zeros(ncal,ngrp);
[ll,cc] = size(ycal);
saidaCV = zeros(ll,cc,hn);
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
for ii = 1:hn % loop dos neur�nios ocultos
    opt.hiddensize = ii;
    for kk = 1:kfold  % Loop da valida��o cruzada
        % Separa��o das amostras
        idx = cvidx ~= kk;
        xcv_cal = xcal(idx,:);
        ycv_cal = ycal(idx,:);
        idx = cvidx == kk;
        xcv_val = xcal(idx,:);
        ycv_val = ycal(idx,:);
        % Inicializa��o
        opt = elm_initialization(opt);
        % Calibra��o
        [model,~] = elm_train(xcv_cal',ycv_cal',opt);
        % Previs�o
        [nn,~] = elm_test(xcv_val',ycv_val',model);
        ypcv(idx,:) = nn.testlabel';
        % Atualiza��o da barra de execu��o
        cont = cont + 1;
        waitbar(cont/(kfold*hn));
    end
    
    [~,label_actual]  = max(ypcv',[],1);
    [~,label_desired] = max(y',[],1);
    acc_test = sum(label_actual==label_desired)/ncal;
    
    % FOM
    [PCCCV(ii),AUCCV(ii),RMSECV(ii)] = fom_da(ngrp,codifica,gn,ycal,ypcv,0);
    saidaCV(:,:,ii) = ypcv;
end
saida.hn = 1:hn;
saida.AUCCV = AUCCV;
saida.RMSECV = RMSECV;
saida.PCCV = PCCCV;
close(wb);
% Gr�ficos para RMSECV e AUC
figure
plot(1:hn,PCCCV./100,'-k')
hold on
hAx = plotyy(1:hn,AUCCV,1:hn,RMSECV);
ylabel(hAx(1),'PCCCV e AUCCV (m�dia)') % left y-axis
ylabel(hAx(2),'RMSECV') % right y-axis
legend('PCCCV','AUCCV (m�dia)','RMSECV','Location','best')
xlabel('Neur�nios ocultos')
hold off
%% Calibra��o
op = 1;
cont = 1;
model = struct;
while op == 1
    fprintf('\n')
    hn = input('Neur�nios ocultos: ');
    ypcv = saidaCV(:,:,hn);
    model(cont).hn = hn;
    model(cont).rmsecv = RMSECV(hn);
    model(cont).auccv = AUCCV(hn);
    model(cont).pcccv = PCCCV(hn);
    model(cont).ypcv = ypcv;
    % Calibra��o
    opt.hiddensize = hn;
    opt = elm_initialization(opt);
    [elm,~] = elm_train(xcal',ycal',opt);
    model(cont).elm = elm;
    % Previs�o
    yp = zeros(size(y));
    yp(amcal,:) = elm.trainlabel';
    if ~isempty(amprev)
        [temp,~] = elm_test(xprev',yprev',elm);
        yp(amprev,:) = temp.testlabel';
    end
    model(cont).yp = yp;
    %% Figuras de m�rito
    fprintf('\n')
    op = input('Deseja plotar as curvas ROC? (0) N�o (1) Sim ');
    % Calibra��o
    [PCC,MAUC,RMSE,ROC] = fom_da(ngrp,codifica,gn,ycal,yp(amcal,:),op);
    model(cont).RMSEC = RMSE;
    model(cont).PCCC = PCC;
    model(cont).AUCC = MAUC;
    model(cont).ROCtreina = ROC;
    if op == 1
        title(['ROC - Calibra��o - ' num2str(hn) ' hn'])
    end
    % Valida��o cruzada
    [~,~,~,~] = fom_da(ngrp,codifica,gn,ycal,ypcv,op);
    if op == 1
        title(['ROC - Valida��o Cruzada - ' num2str(hn) ' hn'])
    end
    % Previs�o
    if ~isempty(amprev)
        [PCC,MAUC,RMSE,ROC] = fom_da(ngrp,codifica,gn,yprev,yp(amprev,:),op);
        model(cont).RMSEP = RMSE;
        model(cont).PCCP = PCC;
        model(cont).AUCP = MAUC;
        model(cont).ROCteste = ROC;
        if op == 1
            title(['ROC - Previs�o - ' num2str(hn) ' hn'])
        end
    end
    %% Resumo na tela
    fprintf('\n')
    fprintf('RMSEC  = %8.4f \t AUCC  = %8.4f \t PCCC  = %8.2f %% \n',model(cont).RMSEC,model(cont).AUCC,model(cont).PCCC)
    fprintf('RMSECV = %8.4f \t AUCCV = %8.4f \t PCCCV = %8.2f %% \n',model(cont).rmsecv,model(cont).auccv,model(cont).pcccv)
    if ~isempty(amprev)
        fprintf('RMSEP  = %8.4f \t AUCP  = %8.4f \t PCCP  = %8.2f %% \n',model(cont).RMSEP,model(cont).AUCP,model(cont).PCCP)
    end
    %% Retorno
    fprintf('\n')
    op = input('Deseja construir outro modelo? (0) N�o (1) Sim ');
    cont = cont + 1;
end
