function [PCC,MAUC,RMSE,ROC] = fom_da(nc,codifica,gn,y,yp,graf)
%% Vers�o: 29/05/2017
%% Figuras de m�rito para an�lise discriminante usando PLS
% ROC
% RMSE
% PCC
% Para plotar os gr�ficos graf = 1
% Sa�da da ROC em uma coluna para cada classe
%% �rea m�dia abaixo da curva ROC
MAUC = 0;
% Plotar gr�ficos
if graf == 1
    figure
    hold on
end
for ii = 1:nc
    [X,Y,T,AUC,OPTROCPT] = perfcurve(y(:,ii),yp(:,ii),1);
    MAUC = MAUC + AUC/nc;
    ROC.X{ii} = X;
    ROC.Y{ii} = Y;
    ROC.AUC{ii} = AUC;
    ROC.T{ii} = T;
    ROC.OPTROC{ii} = OPTROCPT;
    if graf == 1
        plot(X,Y)
    end
end
if graf == 1
    xlabel('False positive rate')
    ylabel('True positive rate')
    legend(gn(1:nc),'Location','best')
    hold off
end
%% RMSE
RMSE = sqrt(mse(y,yp));
%% PCC
[class] = descod(codifica,y,gn);
[classp] = descod(codifica,yp,gn);
temp = strcmp(class,classp);
PCC = 100*sum(temp)/size(yp,1);
