function [y,nclass,gn,classes,g] = cod(codifica,sample,bits)
%% Rotina de codifica��o das classes no vetor de sa�da
%% Vers�o: 05/01/2017
%% Codifica��o inicial
classes = cellstr(sample);
[g,gn] = grp2idx(classes);
nclass = size(gn,1); % Quantidade de classes
gn{nclass+1} = 'DSC'; % amostra desconhecida
%% Codifica��o final
switch codifica
    %% Bin�ria
    case 'bin'  
        class_bin = dec2bin(g,bits); %Transforma as classes em strings bin�rios
        y = zeros(size(g,1),bits);
        for ii = 1:size(g,1)
            for jj = 1:bits
                y(ii,jj) = str2num(class_bin(ii,jj));
            end
        end 
    %% N�meros inteiros
    case 'int'
        y = g;
    %% 1 de N
    case '1deN'
        y = ind2vec(g')';     % Transforma os �ndices em uma matriz esparsa com 0 e 1
end
end