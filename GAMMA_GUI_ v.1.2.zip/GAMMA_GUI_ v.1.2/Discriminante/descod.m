function [classes] = descod(codifica,y_net,gn)
%% Descodifica��o do vetor de sa�da para as classes
%% Vers�o: 16/01/2017
switch codifica
    %% Bin�ria
    case 'bin'  
        % Arredondamento das respostas
        y_net = round(y_net);
        % Corre��o de valores negativos
        temp = (y_net < 0);
        y_net(temp) = 0;
        % Corre��o de valores maiores que 1
        temp = (y_net > 1);
        y_net(temp) = 1;
        % �ndice das classes
        imax = bin2dec(num2str(y_net));
        % Amostras desconhecidas
        nclass = size(gn,1);
        temp = (imax < 1);
        imax(temp) = nclass;
        temp = (imax > nclass);
        imax(temp) = nclass;
        % Classifica��o
        classes = gn(imax);
    %% N�meros inteiros
    case 'int'
        % Arredondamento das respostas
        y_net = round(y_net);
        % Amostras desconhecidas
        nclass = size(gn,1);
        temp = (y_net < 1);
        y_net(temp) = nclass;
        temp = (y_net > nclass);
        y_net(temp) = nclass;
        classes = gn(y_net);
    %% 1 de N
    case '1deN'
        %[~,imax] = max(y_net,[],2);
        [N,imax] = max(y_net,[],2);
        classes = gn(imax);
end
end

