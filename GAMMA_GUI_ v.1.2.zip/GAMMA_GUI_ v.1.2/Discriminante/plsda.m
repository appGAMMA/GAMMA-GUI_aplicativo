function model = plsda(x,samples,am_treina,am_teste,nvl,kfold)
%% PLSDA usando as rotinas do MATLAB
%% Vers�o: 19/06/2017
% Porcentagem de classifica��o correta: Winner's takes all
% Probabilidades bayesianas
% Valida��o cruzada: leave-one-out ou k-fold
%% Par�metros do algoritmo
codifica = '1deN';  % codifica��o da matriz Y
%% Dados
model = struct;
% Calibra��o
x_treina = x(am_treina,:);
ntreina = size(x_treina,1); % quantidade de amostras de calibra��o
[y,nclass,gn] = cod(codifica,samples,0);
y_treina = y(am_treina,:);
model.classes = gn(1:nclass);
model.ycod = y;
% Previs�o
if ~isempty(am_teste)
    x_teste = x(am_teste,:); % x de previs�o
    y_teste = y(am_teste,:); % y de previs�o
end
%% Defini��o da quantidade de VL
AUCCV = zeros(nvl,1);
RMSECV = zeros(nvl,1);
PCCCV = zeros(nvl,1);
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
cont = 0;
[ll,cc] = size(y_treina);
saidaCV = zeros(ll,cc,nvl);
for jj = 1:nvl % Loop das vari�veis latentes
    ycv = zeros(size(y_treina));
    % Valida��o cruzada
    if kfold < ntreina
        % K-fold
        cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
    else
        % Leave-one-out
        cvidx = 1:ntreina;
    end
    for kk = 1:kfold  % Loop da valida��o cruzada
        % Separa��o das amostras
        idx = cvidx ~= kk;
        xcv_treina = x_treina(idx,:);
        ycv_treina = y_treina(idx,:);
        idx = cvidx == kk;
        xcv_teste = x_treina(idx,:);
        [~,~,~,~,beta] = plsregress(xcv_treina,ycv_treina,jj);
        ycv(idx,:) = [ones(size(xcv_teste,1),1) xcv_teste]*beta;
        % Atualiza��o da barra de execu��o
        cont = cont + 1;
        waitbar(cont/(nvl*kfold));
    end
    % FOM
    [PCCCV(jj),AUCCV(jj),RMSECV(jj)] = fom_da(nclass,codifica,gn,y_treina,ycv,0);
    saidaCV(:,:,jj) = ycv;
end
model.NVLS = 1:nvl;
model.AUCCV = AUCCV;
model.RMSECV = RMSECV;
model.PCCV = PCCCV;
close(wb)
% Gr�ficos para RMSECV e AUC
figure
plot(1:nvl,PCCCV./100,'-k')
hold on
hAx = plotyy(1:nvl,AUCCV,1:nvl,RMSECV);
ylabel(hAx(1),'PCCCV e AUCCV (m�dia)') % left y-axis
ylabel(hAx(2),'RMSECV') % right y-axis
legend('PCCCV','AUCCV (m�dia)','RMSECV','Location','best')
xlabel('Vari�veis Latentes')
hold off
%% Constru��o dos modelos
op = 1;
cont = 1;
while op == 1
    fprintf('\n')
    VL = input('Vari�veis Latentes: ');
    ypcv = saidaCV(:,:,VL);
    model(cont).VL = VL;
    model(cont).rmsecv = RMSECV(VL);
    model(cont).auccv = AUCCV(VL);
    model(cont).pcccv = PCCCV(VL);
    model(cont).ypcv = ypcv;
    % Modelo
    [xl,yl,xs,ys,beta,pctvar,~,stats] = plsregress(x_treina,y_treina,VL);
    % Previs�o
    yp = zeros(size(y));
    yp_treina = [ones(size(x_treina,1),1) x_treina]*beta;
    yp(am_treina,:) = yp_treina;
    if ~isempty(am_teste)
        yp_teste = [ones(size(x_teste,1),1) x_teste]*beta;
        yp(am_teste,:) = yp_teste;
    end
    % Vari�ncia acumulada
    temp = sum(pctvar,2);
    varx = temp(1);
    vary = temp(2);
    %% Figuras de m�rito
    fprintf('\n')
    op = input('Deseja plotar as curvas ROC? (0) N�o (1) Sim ');
    % Calibra��o
    [PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,y_treina,yp_treina,op);
    model(cont).RMSEC = RMSE;
    model(cont).PCCC = PCC;
    model(cont).AUCC = MAUC;
    model(cont).ROCtreina = ROC;
    if op == 1
        title(['ROC - Calibra��o - ' num2str(VL) ' VLs'])
    end
    % Valida��o cruzada
    [~,~,~,~] = fom_da(nclass,codifica,gn,y_treina,ypcv,op);
    if op == 1
        title(['ROC - Valida��o Cruzada - ' num2str(VL) ' VLs'])
    end
    % Previs�o
    if ~isempty(am_teste)
        [PCC,MAUC,RMSE,ROC] = fom_da(nclass,codifica,gn,y_teste,yp_teste,op);
        model(cont).RMSEP = RMSE;
        model(cont).PCCP = PCC;
        model(cont).AUCP = MAUC;
        model(cont).ROCteste = ROC;
        if op == 1
            title(['ROC - Previs�o - ' num2str(VL) ' VLs'])
        end
    end
    %% Armazenamento do modelo
    model(cont).xl = xl;
    model(cont).yl = yl;
    model(cont).xs = xs;
    model(cont).ys = ys;
    model(cont).beta = beta;
    model(cont).pctvar = pctvar;
    model(cont).varX = varx;
    model(cont).varY = vary;
    model(cont).stats = stats;
    model(cont).yp = yp;
    %% Resumo na tela
    fprintf('\n')
    fprintf('RMSEC  = %8.4f \t AUCC  = %8.4f \t PCCC  = %8.2f %% \n',model(cont).RMSEC,model(cont).AUCC,model(cont).PCCC)
    fprintf('RMSECV = %8.4f \t AUCCV = %8.4f \t PCCCV = %8.2f %% \n',model(cont).rmsecv,model(cont).auccv,model(cont).pcccv)
    if ~isempty(am_teste)
        fprintf('RMSEP  = %8.4f \t AUCP  = %8.4f \t PCCP  = %8.2f %% \n',model(cont).RMSEP,model(cont).AUCP,model(cont).PCCP)
    end
    %% Probabilidades Bayesianas
    % Sa�da em uma linha para cada classe
    fprintf('\n')
    prob = input('Deseja transformar a sa�da em probabilidades? (0) N�o (1) Sim ');
    if prob == 1
        if ~isempty(am_teste)
            ygraf = [y_treina;y_teste];
            ypgraf = [yp_treina;yp_teste];
        else
            ygraf = y_treina;
            ypgraf = ypcv;
        end
        bayes_prob = dens_prob(ygraf,ypgraf);
        model(cont).bayes_prob = bayes_prob;
        % Gr�fico das probabilidades
        fprintf('\n')
        op = input('Deseja plotar as probabilidades? (0) N�o (1) Sim ');
        if op == 1
            plot_post_plsda(ygraf,ypgraf,gn(1:nclass),bayes_prob)
        end
    end
    %% Sensibilidade e Seletividade
    thrs = zeros(nclass,1);
    for ii = 1:nclass
        if prob == 1
            thrs(ii) = bayes_prob(ii).threshold;
        else
            thrs(ii) = 0.5;
        end
    end
    % Treinamento
    fprintf('\n')
    fprintf('Exatid�o, Sensibilidade e Seletividade - Calibra��o \n')
    saida = sens_selet(y_treina,yp_treina,thrs,gn(1:nclass));
    model(cont).SENScal = saida;
    % Valida��o cruzada
    fprintf('\n')
    fprintf('Exatid�o, Sensibilidade e Seletividade - Valida��o cruzada \n')
    saida = sens_selet(y_treina,ypcv,thrs,gn(1:nclass));
    model(cont).SENScv = saida;
    % Previs�o
    if ~isempty(am_teste)
        fprintf('\n')
        fprintf('Exatid�o, Sensibilidade e Seletividade - Previs�o \n')
        saida = sens_selet(y_teste,yp_teste,thrs,gn(1:nclass));
        model(cont).SENSprev = saida;
    end
    %% Plotar a sa�da do classificador
    fprintf('\n')
    op = input('Deseja plotar as respostas do PLSDA? (0) N�o (1) Sim ');
    if op == 1
        if ~isempty(am_teste)
            plot_output_da([y_treina;y_teste],[yp_treina;yp_teste],gn(1:nclass),thrs,ntreina,'PLSDA')
        else
            plot_output_da(y_treina,ypcv,gn(1:nclass),thrs,0,'PLSDA')
        end
    end
    %% Retorno
    fprintf('\n')
    op = input('Deseja construir outro modelo? (0) N�o (1) Sim ');
    cont = cont + 1;
end
