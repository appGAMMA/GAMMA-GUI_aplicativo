function saida = lda(dados,classe,amcal,amprev)
%% An�lise discriminante linear
%% Vers�o: 23/06/2017
% Verificar a possibilidade de altera��o do custo da classifica��o errada
% ou pesos para classes desbalanceadas
saida.X = dados;
saida.Y = classe;
saida.acal = amcal;
saida.aprev = amprev;
%% Par�metros
% Tipo de fun��o discriminante
fprintf('\n')
fprintf('Tipo de fun��o discriminante: \n')
fprintf('\t (0) Linear \n')
fprintf('\t (1) Quadr�tica \n')
fprintf('\t (2) Linear diagonal \n')
fprintf('\t (3) Quadr�tica diagonal \n')
fprintf('\t (4) Pseudo linear \n')
fprintf('\t (5) Pseudo quadr�tica \n')
op = input('Escolha uma op��o: ');
switch op
    case 0
        fdsc = 'linear';
        saida.fdiscriminante = 'Linear';
    case 1
        fdsc = 'quadratic';
        saida.fdiscriminante = 'Quadr�tica';
    case 2
        fdsc = 'diagLinear';
        saida.fdiscriminante = 'Linear diagonal';    
    case 3
        fdsc = 'diagQuadratic';
        saida.fdiscriminante = 'Quadr�tica diagonal';
    case 4
        fdsc = 'pseudoLinear';
        saida.fdiscriminante = 'Pseudo linear';
    case 5
        fdsc = 'pseudoQuadratic';
        saida.fdiscriminante = 'Pseudo quadr�tica';
    otherwise
        disp('Op��o inv�lida!')
end
% Valida��o cruzada
tipo_vc = input('Tipo de valida��o cruzada: (0) leave-one-out (1) k-fold ');
if tipo_vc == 1
    kfold = input('Quantidade de grupos para a valida��o cruzada: ');
    saida.tipo_vc = 'k-fold';
    cvidx = crossvalind('Kfold',size(y_treina,1),kfold);
else
    kfold = length(amcal);
    saida.tipo_vc = 'leave-one-out';
    cvidx = 1:kfold;
end
%% Prepara��o dos dados
xcal = dados(amcal,:); % x de calibra��o
ncal = length(amcal); % quantidade de amostras de calibra��o
[y,gn] = grp2idx(classe); 
saida.classes = gn;
ycal = y(amcal); % y de calibra��o
ngrp = length(gn); % quantidade de grupos
thrs = 0.5*ones(ngrp,1); % Limiar de classifica��o
if ~isempty(amprev)
    xprev = dados(amprev,:); % x de previs�o   
    yprev = y(amprev); % y de previs�o
end
%% Constru��o do modelo
wb=waitbar(0,'Construindo os modelos...','Name','Valida��o cruzada');
cont = 0;
ypcv = zeros(ncal,ngrp);
cost = zeros(ncal,ngrp);
for kk = 1:kfold  % Loop da valida��o cruzada
    % Separa��o das amostras
    idx = cvidx ~= kk;
    xcv_cal = xcal(idx,:);
    ycv_cal = ycal(idx,:);
    idx = cvidx == kk;
    xcv_val = xcal(idx,:);
    obj = fitcdiscr(xcv_cal,ycv_cal,'DiscrimType',fdsc);
    [~,ypcv(idx,:),cost(idx,:)] = predict(obj,xcv_val);
    % Atualiza��o da barra de execu��o
    cont = cont + 1;
    waitbar(cont/kfold);
end
close(wb);
% Calibra��o
obj = fitcdiscr(xcal,ycal,'DiscrimType',fdsc);
[~,ypcal,cost_cal] = predict(obj,xcal);
saida.modelo = obj;
saida.ypcal = ypcal;
saida.cost_cal = cost_cal;
% FOM
[PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(ycal')',ypcal,0);
saida.PCCcal = PCC;
saida.AUCcal = AUC;
saida.RMSEcal = RMSE;
fprintf('\n')
fprintf('Calibra��o \n')
fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
temp = sens_selet(ind2vec(ycal')',ypcal,thrs,gn);
saida.SENScal = temp;
% FOM - Valida��o cruzada
[PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(ycal')',ypcv,0);
saida.ypcv = ypcv;
saida.cost_cv = cost;
saida.PCCcv = PCC;
saida.AUCcv = AUC;
saida.RMSEcv = RMSE;
fprintf('\n')
fprintf('Valida��o Cruzada \n')
fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
temp = sens_selet(ind2vec(ycal')',ypcv,thrs,gn);
saida.SENScv = temp;
% Previs�o
if ~isempty(amprev)
    [~,ypprev,cost] = predict(obj,xprev);
    saida.ypprev = ypprev;
    saida.cost_prev = cost;
    % FOM
    [PCC,AUC,RMSE] = fom_da(ngrp,'1deN',gn,ind2vec(yprev')',ypprev,0);
    saida.PCCprev = PCC;
    saida.AUCprev = AUC;
    saida.RMSEprev = RMSE;
    fprintf('\n')
    fprintf('Previs�o \n')
    fprintf('RMSE = %8.4f \t AUC = %8.4f \t PCC = %8.2f %% \n',RMSE,AUC,PCC)
    temp = sens_selet(ind2vec(yprev')',ypprev,thrs,gn);
    saida.SENSprev = temp;
end
%% Plotar a sa�da do classificador
fprintf('\n')
op = input('Deseja plotar as respostas do LDA? (0) N�o (1) Sim ');
if op == 1
    if ~isempty(amprev)
        plot_output_da(ind2vec([ycal;yprev]')',[ypcal;ypprev],gn,thrs,ncal,'LDA')
    else
        plot_output_da(ind2vec(ycal')',ypcv,gn,thrs,0,'LDA')
    end
end